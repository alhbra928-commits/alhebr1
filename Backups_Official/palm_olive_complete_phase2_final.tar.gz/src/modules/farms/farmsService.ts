import { supabase } from '../../lib/supabase';
import type { Farm } from '../../types/database.types';

export class FarmsService {
  static async getAll() {
    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as Farm[];
  }

  static async getById(id: string) {
    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) throw error;
    return data as Farm | null;
  }

  static async getActive() {
    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .eq('status', 'active')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as Farm[];
  }

  static async create(farm: Omit<Farm, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('farms')
      .insert([farm])
      .select()
      .single();

    if (error) throw error;
    return data as Farm;
  }

  static async update(id: string, updates: Partial<Farm>) {
    const { data, error } = await supabase
      .from('farms')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .is('deleted_at', null)
      .select()
      .single();

    if (error) throw error;
    return data as Farm;
  }

  static async softDelete(id: string) {
    const { data, error } = await supabase.rpc('soft_delete_record', {
      p_table_name: 'farms',
      p_record_id: id
    });

    if (error) throw error;
    return data;
  }

  static async restore(id: string) {
    const { data, error } = await supabase.rpc('restore_soft_deleted', {
      table_name: 'farms',
      record_id: id
    });

    if (error) throw error;
    return data;
  }

  static async getStatistics() {
    const { data, error } = await supabase
      .from('farms')
      .select('status, tree_type, total_trees, available_trees')
      .is('deleted_at', null);

    if (error) throw error;

    const stats = {
      total: data.length,
      active: data.filter(f => f.status === 'active').length,
      inactive: data.filter(f => f.status === 'inactive').length,
      full: data.filter(f => f.status === 'full').length,
      totalTrees: data.reduce((sum, f) => sum + f.total_trees, 0),
      availableTrees: data.reduce((sum, f) => sum + f.available_trees, 0),
      palmFarms: data.filter(f => f.tree_type === 'palm').length,
      oliveFarms: data.filter(f => f.tree_type === 'olive').length,
    };

    return stats;
  }
}
