import React, { useEffect, useState } from 'react';
import { MapPin, Trees, DollarSign, TrendingUp, Plus, Edit, Trash2 } from 'lucide-react';
import { Card3D } from '../../../components/ui/Card3D';
import { FarmsService } from '../farmsService';
import type { Farm } from '../../../types/database.types';

export function FarmsView() {
  const [farms, setFarms] = useState<Farm[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadFarms();
  }, []);

  const loadFarms = async () => {
    try {
      setLoading(true);
      const [farmsData, statsData] = await Promise.all([
        FarmsService.getAll(),
        FarmsService.getStatistics()
      ]);
      setFarms(farmsData);
      setStats(statsData);
    } catch (err) {
      setError('فشل تحميل بيانات المزارع');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري تحميل المزارع...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <p className="text-red-600 text-lg mb-4">{error}</p>
          <button
            onClick={loadFarms}
            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8" dir="rtl">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">إدارة المزارع</h1>
            <p className="text-gray-600">إدارة ومراقبة جميع المزارع في المنصة</p>
          </div>
          <button className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-all shadow-lg hover:shadow-xl transform hover:scale-105">
            <Plus className="h-5 w-5" />
            <span>إضافة مزرعة جديدة</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <MapPin className="h-6 w-6 text-green-600" />
              </div>
              <span className="text-3xl font-bold text-gray-900">{stats?.total || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600 mb-1">إجمالي المزارع</h3>
            <p className="text-xs text-gray-500">جميع المزارع المسجلة</p>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                <Trees className="h-6 w-6 text-emerald-600" />
              </div>
              <span className="text-3xl font-bold text-emerald-600">{stats?.active || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600 mb-1">المزارع النشطة</h3>
            <p className="text-xs text-gray-500">جاهزة للاستثمار</p>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Trees className="h-6 w-6 text-blue-600" />
              </div>
              <span className="text-3xl font-bold text-blue-600">{stats?.totalTrees || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600 mb-1">إجمالي الأشجار</h3>
            <p className="text-xs text-gray-500">في جميع المزارع</p>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-orange-600" />
              </div>
              <span className="text-3xl font-bold text-orange-600">{stats?.availableTrees || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600 mb-1">أشجار متاحة</h3>
            <p className="text-xs text-gray-500">جاهزة للحجز</p>
          </div>
        </Card3D>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {farms.map((farm) => (
          <Card3D key={farm.id}>
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{farm.name_ar}</h3>
                  <p className="text-sm text-gray-600 mb-2">{farm.name_en}</p>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <MapPin className="h-4 w-4" />
                    <span>{farm.location}</span>
                  </div>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    farm.status === 'active'
                      ? 'bg-green-100 text-green-700'
                      : farm.status === 'full'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {farm.status === 'active' ? 'نشط' : farm.status === 'full' ? 'مكتمل' : 'غير نشط'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-600 mb-1">نوع الشجر</p>
                  <p className="text-sm font-semibold text-gray-900">
                    {farm.tree_type === 'palm' ? '🌴 نخيل' : '🫒 زيتون'}
                  </p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-600 mb-1">المساحة</p>
                  <p className="text-sm font-semibold text-gray-900">{farm.area_sqm.toLocaleString()} م²</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-600 mb-1">إجمالي الأشجار</p>
                  <p className="text-sm font-semibold text-gray-900">{farm.total_trees}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-600 mb-1">المتاح</p>
                  <p className="text-sm font-semibold text-green-600">{farm.available_trees}</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div>
                  <p className="text-xs text-gray-600 mb-1">سعر الشجرة</p>
                  <p className="text-lg font-bold text-gray-900">
                    {farm.price_per_tree.toLocaleString()} ريال
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors">
                    <Edit className="h-4 w-4" />
                  </button>
                  <button className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          </Card3D>
        ))}
      </div>

      {farms.length === 0 && (
        <div className="text-center py-12">
          <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد مزارع</h3>
          <p className="text-gray-600 mb-4">ابدأ بإضافة أول مزرعة للمنصة</p>
          <button className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            إضافة مزرعة
          </button>
        </div>
      )}
    </div>
  );
}
