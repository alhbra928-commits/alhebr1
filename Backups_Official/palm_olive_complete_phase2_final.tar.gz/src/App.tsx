import { useState } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './modules/dashboard/DashboardView';
import { FarmsView } from './modules/farms/components/FarmsView';
import { ReservationsView } from './modules/reservations/components/ReservationsView';
import { WalletsView } from './modules/wallets/components/WalletsView';

function App() {
  const [activeModule, setActiveModule] = useState('dashboard');

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <DashboardView />;
      case 'farms':
        return <FarmsView />;
      case 'reservations':
        return <ReservationsView />;
      case 'wallets':
        return <WalletsView />;
      default:
        return (
          <div className="flex items-center justify-center h-screen" dir="rtl">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">قريبًا</h2>
              <p className="text-gray-600">هذا القسم قيد التطوير</p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex" dir="rtl">
      <Sidebar activeModule={activeModule} onModuleChange={setActiveModule} />
      <div className="flex-1 mr-64">
        {renderModule()}
      </div>
    </div>
  );
}

export default App;
