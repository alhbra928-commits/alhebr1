import { useState, useEffect } from 'react';
import { ArrowRight, MapPin, Trees, TrendingUp, CheckCircle2 } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';
import { FarmDetailService, FarmDetail } from '../services/farmDetailService';
import { SimpleLoader } from '../../../components/common/SimpleLoader';

interface FarmDetailPageProps {
  farmId: string;
  onBack: () => void;
  onStartBooking: () => void;
}

export function FarmDetailPage({ farmId, onBack, onStartBooking }: FarmDetailPageProps) {
  const [farm, setFarm] = useState<FarmDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    loadFarmData();
  }, [farmId]);

  const loadFarmData = async () => {
    const pageStart = performance.now();
    console.log('[PERF] FarmDetailPage: Started loading, farmId:', farmId);

    try {
      setLoading(true);
      const farmDetail = await FarmDetailService.getFarmById(farmId);
      console.log('[PERF] FarmDetailPage: Received farm detail:', farmDetail ? { id: farmDetail.id, name: farmDetail.name_ar } : null);

      if (farmDetail) {
        const totalAvailable = farmDetail.varieties.reduce((sum, v) => sum + v.available_quantity, 0);
        const totalTrees = farmDetail.varieties.reduce((sum, v) => sum + v.total_trees, 0);

        console.log('[PERF] FarmDetailPage: Setting farm state with', { totalAvailable, totalTrees });

        setFarm({
          ...farmDetail,
          available_trees: totalAvailable,
          total_trees: totalTrees > 0 ? totalTrees : farmDetail.total_trees
        });
      } else {
        console.log('[PERF] FarmDetailPage: No farm detail received - will show not found');
      }
    } catch (error) {
      console.error('[ERROR] FarmDetailPage: Error loading farm:', error);
    } finally {
      setLoading(false);
      console.log(`[PERF] FarmDetailPage: TOTAL took ${(performance.now() - pageStart).toFixed(0)}ms`);
    }
  };

  const getTreeName = (type: string | null) => {
    if (!type) return 'شجرتك';
    const normalizedType = type.toLowerCase();
    if (normalizedType === 'نخيل' || normalizedType === 'palm') return 'نخلة';
    if (normalizedType === 'زيتون' || normalizedType === 'olive') return 'شجرة زيتون';
    return 'شجرة';
  };

  const getTreeEmoji = (type: string | null) => {
    if (!type) return '🌳';
    const normalizedType = type.toLowerCase();
    if (normalizedType === 'نخيل' || normalizedType === 'palm') return '🌴';
    if (normalizedType === 'زيتون' || normalizedType === 'olive') return '🫒';
    return '🌳';
  };

  const reservedTrees = farm ? farm.total_trees - farm.available_trees : 0;
  const reservationPercentage = farm ? Math.round((reservedTrees / farm.total_trees) * 100) : 0;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: brandGradients.beige }}>
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <SimpleLoader size="lg" color={brandColors.primary.gold} />
          </div>
          <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
            جاري التحميل...
          </p>
        </div>
      </div>
    );
  }

  if (!farm) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: brandGradients.beige }}>
        <div className="text-center">
          <p className="text-2xl font-bold mb-4" style={{ color: brandColors.text.primary }}>
            لم يتم العثور على المزرعة
          </p>
          <button
            onClick={onBack}
            className="px-8 py-3 rounded-xl font-bold text-white transition-all hover:scale-105"
            style={{ background: brandGradients.gold }}
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  const heroImage = farm.aerial_map_url ||
    (farm.images && farm.images.length > 0 ? farm.images[0] : null) ||
    (farm.tree_type === 'نخيل' || farm.tree_type === 'palm'
      ? 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=1920&q=80'
      : 'https://images.unsplash.com/photo-1474440692490-2e83ae13ba29?w=1920&q=80');

  return (
    <div className="min-h-screen" style={{ background: brandGradients.beige }} dir="rtl">
      {/* 🟩 الهيدر العلوي */}
      <div
        className="sticky top-0 z-50 backdrop-blur-md border-b"
        style={{
          background: 'rgba(255, 250, 240, 0.95)',
          borderColor: brandColors.border.light
        }}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-3 sm:py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition-all active:scale-95 sm:hover:scale-105 touch-manipulation"
            style={{
              background: 'white',
              color: brandColors.primary.gold,
              boxShadow: '0 4px 12px rgba(212, 175, 55, 0.2)'
            }}
          >
            <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-sm sm:text-base">العودة</span>
          </button>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <div
              className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full animate-pulse"
              style={{ background: brandGradients.gold }}
            />
            <span className="font-bold text-xs sm:text-sm md:text-base" style={{ color: brandColors.primary.gold }}>
              منصة النخيل والزيتون
            </span>
          </div>
        </div>
      </div>

      {/* 🟨 الصورة الرئيسية - صورة بانورامية مع تأثير حركة بطيئة */}
      <div className="relative w-full min-h-[300px] h-[45vh] sm:h-[50vh] md:h-[60vh] max-h-[500px] sm:max-h-[600px] overflow-hidden">
        {typeof heroImage === 'string' && heroImage.startsWith('linear-gradient') ? (
          <div
            className="absolute inset-0"
            style={{
              background: heroImage,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />
        ) : (
          <img
            src={heroImage}
            alt={farm.name_ar}
            onLoad={() => setImageLoaded(true)}
            className={`absolute inset-0 w-full h-full transition-transform duration-[20000ms] ease-linear ${
              imageLoaded ? 'scale-110' : 'scale-100'
            }`}
            style={{
              objectFit: 'cover',
              objectPosition: 'center 40%'
            }}
          />
        )}

        {/* Overlay نصي */}
        <div
          className="absolute inset-0 flex items-end"
          style={{
            background: 'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 50%, transparent 100%)'
          }}
        >
          <div className="w-full p-4 sm:p-6 md:p-8 pb-6 sm:pb-8 md:pb-10 text-white">
            <div className="max-w-7xl mx-auto">
              <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black mb-2 sm:mb-3 md:mb-4 leading-tight drop-shadow-lg">
                امتلك جزءًا من الطبيعة...
              </h1>
              <p className="text-base sm:text-lg md:text-xl lg:text-2xl opacity-95 drop-shadow-md">
                حيث تبدأ قصتك مع {getTreeName(farm.farm_type)} تحمل اسمك
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-6 sm:py-8 md:py-12">

        {/* 🟧 بطاقة تعريف المزرعة */}
        <div
          className="mb-6 sm:mb-8 p-4 sm:p-6 md:p-8 rounded-2xl sm:rounded-3xl backdrop-blur-sm transform active:scale-[0.99] sm:hover:scale-[1.01] transition-all duration-300"
          style={{
            background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(255, 250, 240, 0.9))',
            boxShadow: `0 20px 60px rgba(212, 175, 55, 0.3)`,
            border: `2px solid ${brandColors.primary.gold}30`
          }}
        >
          {/* العنوان والموقع */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 sm:gap-3 mb-2 sm:mb-3">
                <div className="text-3xl sm:text-4xl">{getTreeEmoji(farm.farm_type)}</div>
                <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black leading-tight" style={{ color: brandColors.primary.gold }}>
                  {farm.name_ar}
                </h2>
              </div>
              <div className="flex items-center gap-1.5 sm:gap-2 text-sm sm:text-base md:text-lg" style={{ color: brandColors.text.secondary }}>
                <MapPin className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
                <span>{farm.city}, {farm.region}</span>
              </div>
            </div>

            <div className="text-right w-full sm:w-auto">
              <div className="text-xs sm:text-sm" style={{ color: brandColors.text.secondary }}>رمز المزرعة</div>
              <div className="text-lg sm:text-xl md:text-2xl font-bold" style={{ color: brandColors.primary.gold }}>
                {farm.name_ar}
              </div>
            </div>
          </div>

          {/* النبذة التعريفية */}
          <p className="text-sm sm:text-base md:text-lg leading-relaxed mb-5 sm:mb-6 md:mb-8" style={{ color: brandColors.text.secondary }}>
            {farm.description_ar}
          </p>

          {/* 🟦 تفاصيل الاستثمار - 3 بطاقات */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 md:gap-6 mb-5 sm:mb-6 md:mb-8">
            <div
              className="p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl text-center transition-all active:scale-95 sm:hover:scale-105 touch-manipulation"
              style={{ background: brandColors.neutral.beige }}
            >
              <Trees className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 mx-auto mb-2 sm:mb-3" style={{ color: brandColors.accent.olive }} />
              <div className="text-xl sm:text-2xl md:text-3xl font-black mb-1 sm:mb-2" style={{ color: brandColors.primary.gold }}>
                {farm.total_trees.toLocaleString('ar-SA')}
              </div>
              <div className="text-xs sm:text-sm" style={{ color: brandColors.text.secondary }}>إجمالي الأشجار</div>
            </div>

            <div
              className="p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl text-center transition-all active:scale-95 sm:hover:scale-105 touch-manipulation"
              style={{ background: brandColors.neutral.beige }}
            >
              <TrendingUp className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 mx-auto mb-2 sm:mb-3" style={{ color: brandColors.accent.olive }} />
              <div className="text-xl sm:text-2xl md:text-3xl font-black mb-1 sm:mb-2" style={{ color: brandColors.primary.gold }}>
                {farm.price_per_tree.toLocaleString('ar-SA')} ر.س
              </div>
              <div className="text-xs sm:text-sm" style={{ color: brandColors.text.secondary }}>السعر لكل شجرة</div>
            </div>

            <div
              className="p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl text-center transition-all active:scale-95 sm:hover:scale-105 touch-manipulation"
              style={{ background: brandColors.neutral.beige }}
            >
              <CheckCircle2 className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 mx-auto mb-2 sm:mb-3" style={{ color: brandColors.accent.olive }} />
              <div className="text-xl sm:text-2xl md:text-3xl font-black mb-1 sm:mb-2" style={{ color: brandColors.primary.gold }}>
                {farm.available_trees.toLocaleString('ar-SA')}
              </div>
              <div className="text-xs sm:text-sm" style={{ color: brandColors.text.secondary }}>متاح للحجز</div>
            </div>
          </div>

          {/* Progress Bar - نسبة الحجز */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-sm sm:text-base" style={{ color: brandColors.text.primary }}>
                نسبة الحجز
              </span>
              <span className="text-xl sm:text-2xl font-black" style={{ color: brandColors.primary.gold }}>
                {reservationPercentage}%
              </span>
            </div>
            <div
              className="h-3 sm:h-4 rounded-full overflow-hidden relative"
              style={{ background: brandColors.neutral.beige }}
            >
              <div
                className="h-full rounded-full transition-all duration-1000 ease-out"
                style={{
                  width: `${reservationPercentage}%`,
                  background: `linear-gradient(90deg, ${brandColors.primary.gold}, ${brandColors.primary.goldDark})`
                }}
              />
            </div>
            <p className="text-xs sm:text-sm mt-2 text-center font-bold" style={{ color: brandColors.status.warning }}>
              🔥 {reservationPercentage}٪ من حجوزات المزرعة اكتملت
            </p>
          </div>
        </div>

        {/* 🟪 زر الحجز الديناميكي الذكي */}
        <div className="text-center mb-8 sm:mb-10 md:mb-12 px-2">
          <button
            onClick={onStartBooking}
            className="group relative w-full sm:w-auto px-8 sm:px-12 md:px-16 py-5 sm:py-6 md:py-7 rounded-2xl sm:rounded-3xl text-xl sm:text-2xl md:text-3xl font-black text-white transition-all duration-500 active:scale-95 sm:hover:scale-105 overflow-hidden touch-manipulation"
            style={{
              background: !farm.farm_type || farm.farm_type === 'نخيل'
                ? `linear-gradient(135deg, ${brandColors.primary.gold} 0%, ${brandColors.primary.goldDark} 50%, #B8860B 100%)`
                : `linear-gradient(135deg, ${brandColors.primary.olive} 0%, #6B8E23 50%, #556B2F 100%)`,
              boxShadow: !farm.farm_type || farm.farm_type === 'نخيل'
                ? '0 15px 50px rgba(212, 175, 55, 0.6), 0 5px 20px rgba(255, 215, 0, 0.4)'
                : '0 15px 50px rgba(85, 107, 47, 0.6), 0 5px 20px rgba(107, 142, 35, 0.4)',
              border: '2px solid rgba(255, 255, 255, 0.3)'
            }}
          >
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700"
              style={{
                background: 'linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.4) 50%, transparent 70%)',
                backgroundSize: '200% 200%',
                animation: 'shimmer 2s infinite'
              }}
            />

            <div className="relative z-10 flex items-center justify-center gap-3 sm:gap-4">
              <span className="text-3xl sm:text-4xl md:text-5xl animate-bounce">
                {getTreeEmoji(farm.farm_type)}
              </span>
              <div className="flex flex-col items-start">
                <span className="text-sm sm:text-base md:text-lg opacity-90">احجز</span>
                <span className="leading-tight">
                  {getTreeName(farm.farm_type)} الآن
                </span>
              </div>
            </div>

            <div
              className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-all duration-300"
              style={{
                background: 'radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%)',
                animation: 'pulse 2s infinite'
              }}
            />
          </button>

          <p className="mt-4 text-sm sm:text-base font-bold animate-pulse" style={{ color: brandColors.primary.gold }}>
            ✨ اضغط للبدء في الحجز المؤقت
          </p>
        </div>

        {/* 🟫 قسم الثقة والتحفيز */}
        <div
          className="text-center py-8 sm:py-12 border-t-2"
          style={{ borderColor: `${brandColors.primary.gold}20` }}
        >
          <p className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4" style={{ color: brandColors.primary.gold }}>
            استثمارك يبدأ من شجرة واحدة...
          </p>
          <p className="text-lg sm:text-xl" style={{ color: brandColors.text.secondary }}>
            ملكك مدى الحياة 🌿
          </p>
        </div>
      </div>

      {/* 🟬 الفوتر */}
      <div className="py-6 sm:py-8 text-center" style={{ background: brandColors.accent.oliveDark }}>
        <p className="text-white text-sm sm:text-base opacity-80">
          © 2025 منصة تملك المزارع - جميع الحقوق محفوظة
        </p>
      </div>
    </div>
  );
}
