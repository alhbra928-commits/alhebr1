import { useState, useEffect } from 'react';
import {
  ArrowRight,
  Plus,
  Minus,
  CheckCircle2,
  Home,
  User,
  Phone,
  ShoppingCart,
  Sparkles,
  Award,
  X,
  TreeDeciduous,
  TrendingUp,
  Info,
  AlertCircle,
  Calculator,
  Edit3,
  Leaf,
  Star
} from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';
import { FarmDetailService, FarmVariety, CreateReservationData } from '../services/farmDetailService';
import { SimpleLoader } from '../../../components/common/SimpleLoader';

interface TemporaryBookingPageProps {
  farmId: string;
  farmName: string;
  farmType: 'palm' | 'olive';
  onBack: () => void;
  onSuccess: () => void;
  onGoHome: () => void;
  onGoToInvestor: () => void;
}

interface VarietySelection {
  variety: FarmVariety;
  quantity: number;
}

const oliveTheme = {
  darkest: '#3D4F2F',
  dark: '#556B2F',
  primary: '#6B8E23',
  light: '#8BA644',
  lighter: '#A4BE7B',
  lightest: '#D4E7C5',
  cream: '#F5F7F0',
  accent: '#B8860B',
};

export function TemporaryBookingPage({
  farmId,
  farmName,
  farmType,
  onBack,
  onSuccess,
  onGoHome,
  onGoToInvestor
}: TemporaryBookingPageProps) {
  const [varieties, setVarieties] = useState<FarmVariety[]>([]);
  const [selections, setSelections] = useState<Map<string, VarietySelection>>(new Map());
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [investorName, setInvestorName] = useState('');
  const [investorPhone, setInvestorPhone] = useState('');

  const normalizedFarmType = farmType?.toLowerCase() || '';
  const isPalm = normalizedFarmType === 'palm' || normalizedFarmType === 'نخيل';

  const getFarmIcon = () => isPalm ? '🌴' : '🫒';
  const getFarmColor = () => isPalm ? brandColors.primary.gold : oliveTheme.primary;
  const getFarmGradient = () => isPalm
    ? `linear-gradient(135deg, ${brandColors.primary.gold}, ${brandColors.primary.goldDark})`
    : `linear-gradient(135deg, ${oliveTheme.dark}, ${oliveTheme.darkest})`;

  useEffect(() => {
    loadVarieties();
  }, [farmId]);

  const loadVarieties = async () => {
    const startTime = performance.now();
    console.log('[PERF] TemporaryBookingPage: Loading varieties');

    try {
      setLoading(true);
      const farmDetail = await FarmDetailService.getFarmById(farmId);
      if (farmDetail) {
        setVarieties(farmDetail.varieties);
      }
    } catch (error) {
      console.error('Error loading varieties:', error);
    } finally {
      setLoading(false);
      console.log(`[PERF] TemporaryBookingPage: TOTAL ${(performance.now() - startTime).toFixed(0)}ms`);
    }
  };

  const updateQuantity = (varietyId: string, quantity: number, variety: FarmVariety) => {
    const newSelections = new Map(selections);

    if (quantity <= 0) {
      newSelections.delete(varietyId);
    } else if (quantity > variety.available_quantity) {
      alert(`الحد الأقصى المتاح: ${variety.available_quantity} شجرة`);
      return;
    } else {
      newSelections.set(varietyId, { variety, quantity });
    }

    setSelections(newSelections);
  };

  const calculateTotal = () => {
    let total = 0;
    selections.forEach(({ variety, quantity }) => {
      total += variety.price_per_tree * quantity;
    });
    return total;
  };

  const calculateTotalTrees = () => {
    let total = 0;
    selections.forEach(({ quantity }) => {
      total += quantity;
    });
    return total;
  };

  const handleSubmit = async () => {
    if (selections.size === 0) {
      alert('يرجى اختيار صنف واحد على الأقل');
      return;
    }

    if (!investorName.trim()) {
      alert('يرجى إدخال الاسم الكامل');
      return;
    }

    if (!investorPhone.trim()) {
      alert('يرجى إدخال رقم الجوال');
      return;
    }

    const phoneRegex = /^(5\d{8}|05\d{8})$/;
    const cleanPhone = investorPhone.replace(/\s/g, '');
    if (!phoneRegex.test(cleanPhone)) {
      alert('يرجى إدخال رقم جوال سعودي صحيح (يبدأ بـ 5 أو 05)');
      return;
    }

    try {
      setSubmitting(true);

      const varietiesArray = Array.from(selections.values());
      const reservationData: CreateReservationData = {
        farm_id: farmId,
        investor_name: investorName.trim(),
        investor_phone: cleanPhone.startsWith('0') ? cleanPhone.slice(1) : cleanPhone,
        varieties: varietiesArray.map(({ variety, quantity }) => ({
          variety_id: variety.id,
          tree_count: quantity,
          price_per_tree: variety.price_per_tree
        })),
        total_trees: calculateTotalTrees(),
        total_amount: calculateTotal()
      };

      await FarmDetailService.createReservation(reservationData);

      // Store phone for automatic login
      const phoneForLogin = cleanPhone.startsWith('0') ? cleanPhone.slice(1) : cleanPhone;
      sessionStorage.setItem('pending_investor_phone', phoneForLogin);

      setShowSuccess(true);
    } catch (error: any) {
      console.error('Error submitting reservation:', error);
      alert(error.message || 'حدث خطأ أثناء الحجز، يرجى المحاولة مرة أخرى');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{
          background: `radial-gradient(circle at top right, ${oliveTheme.lightest}, ${oliveTheme.cream})`
        }}
      >
        <div className="text-center">
          <div
            className="w-28 h-28 rounded-3xl mx-auto mb-6 flex items-center justify-center animate-pulse relative"
            style={{
              background: getFarmGradient(),
              boxShadow: `0 20px 60px ${oliveTheme.primary}40`
            }}
          >
            <span className="text-6xl">{getFarmIcon()}</span>
            <div className="absolute inset-0 rounded-3xl animate-ping opacity-20" style={{ background: oliveTheme.primary }} />
          </div>
          <div className="flex justify-center mb-5">
            <SimpleLoader size="lg" color={oliveTheme.primary} />
          </div>
          <p className="text-3xl font-black mb-2" style={{ color: oliveTheme.darkest }}>
            جاري التحميل...
          </p>
          <p className="text-gray-600">الرجاء الانتظار</p>
        </div>
      </div>
    );
  }

  if (showSuccess) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{
          background: `radial-gradient(circle at center, ${oliveTheme.lightest}, ${oliveTheme.cream})`
        }}
        dir="rtl"
      >
        <div
          className="max-w-2xl w-full rounded-3xl p-8 md:p-12 text-center relative overflow-hidden"
          style={{
            background: 'white',
            boxShadow: `0 40px 100px ${oliveTheme.primary}30`,
            border: `3px solid ${oliveTheme.lighter}`
          }}
        >
          <div
            className="absolute top-0 left-0 right-0 h-3 rounded-t-3xl"
            style={{ background: getFarmGradient() }}
          />

          <div className="absolute top-8 right-8 opacity-10">
            <Leaf className="w-32 h-32" style={{ color: oliveTheme.primary }} />
          </div>
          <div className="absolute bottom-8 left-8 opacity-10">
            <Leaf className="w-32 h-32 transform rotate-180" style={{ color: oliveTheme.primary }} />
          </div>

          <div
            className="w-36 h-36 rounded-full mx-auto mb-6 flex items-center justify-center relative shadow-2xl"
            style={{
              background: `linear-gradient(135deg, ${oliveTheme.light}, ${oliveTheme.primary})`
            }}
          >
            <CheckCircle2 className="h-20 w-20 text-white" strokeWidth={3} />
            <div className="absolute -top-3 -right-3">
              <Star className="w-12 h-12 text-yellow-400 animate-pulse" fill="currentColor" />
            </div>
            <div className="absolute -bottom-3 -left-3">
              <Sparkles className="w-10 h-10 text-yellow-400 animate-pulse" style={{ animationDelay: '0.3s' }} />
            </div>
          </div>

          <h2
            className="text-4xl md:text-5xl font-black mb-4 relative z-10"
            style={{ color: oliveTheme.darkest }}
          >
            تم تسجيل حجزك بنجاح!
          </h2>

          <p className="text-xl mb-8 text-gray-700 relative z-10">
            سيتم التواصل معك قريباً لإكمال إجراءات الحجز
          </p>

          <div
            className="p-8 rounded-2xl mb-8 relative overflow-hidden z-10"
            style={{
              background: `linear-gradient(135deg, ${oliveTheme.lightest}, white)`,
              border: `2px solid ${oliveTheme.lighter}`
            }}
          >
            <div className="absolute top-0 left-0 w-20 h-20 opacity-20">
              <Leaf className="w-20 h-20" style={{ color: oliveTheme.primary }} />
            </div>
            <Award className="w-16 h-16 mx-auto mb-4" style={{ color: oliveTheme.primary }} />
            <p className="font-black text-2xl mb-3" style={{ color: oliveTheme.darkest }}>
              رقم جوالك هو مفتاح دخولك
            </p>
            <p className="text-gray-700 text-lg">
              استخدم رقم جوالك للدخول إلى لوحة المستثمر ومتابعة حجزك
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center relative z-10">
            <button
              onClick={onGoHome}
              className="flex items-center justify-center gap-3 px-8 py-4 rounded-xl font-black text-lg text-white transition-all hover:scale-105 shadow-xl"
              style={{
                background: `linear-gradient(135deg, ${oliveTheme.dark}, ${oliveTheme.darkest})`
              }}
            >
              <Home className="h-6 w-6" />
              العودة للرئيسية
            </button>

            <button
              onClick={() => {
                // Mark that we should auto-login
                sessionStorage.setItem('should_auto_login', 'true');
                onGoToInvestor();
              }}
              className="flex items-center justify-center gap-3 px-8 py-4 rounded-xl font-black text-lg transition-all hover:scale-105 shadow-xl"
              style={{
                background: 'white',
                color: oliveTheme.primary,
                border: `3px solid ${oliveTheme.primary}`
              }}
            >
              <User className="h-6 w-6" />
              لوحة المستثمر
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen pb-8"
      style={{
        background: `radial-gradient(circle at top left, ${oliveTheme.lightest}, ${oliveTheme.cream})`
      }}
      dir="rtl"
    >
      <div
        className="sticky top-0 z-50 backdrop-blur-2xl border-b"
        style={{
          background: 'rgba(255, 255, 255, 0.9)',
          borderColor: `${oliveTheme.lighter}50`,
          boxShadow: `0 4px 24px ${oliveTheme.primary}10`
        }}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-5">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center gap-2 px-5 py-3 rounded-xl font-black text-lg transition-all hover:scale-105"
              style={{
                background: 'white',
                color: oliveTheme.primary,
                boxShadow: `0 4px 16px ${oliveTheme.primary}15`,
                border: `2px solid ${oliveTheme.lighter}`
              }}
            >
              <ArrowRight className="w-6 h-6" />
              <span>رجوع</span>
            </button>

            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl relative"
                style={{
                  background: `linear-gradient(135deg, ${oliveTheme.light}, ${oliveTheme.primary})`,
                  boxShadow: `0 8px 24px ${oliveTheme.primary}30`
                }}
              >
                {getFarmIcon()}
                <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full animate-pulse" style={{ background: oliveTheme.accent }} />
              </div>
              <div className="text-right">
                <h3 className="font-black text-2xl leading-tight" style={{ color: oliveTheme.darkest }}>
                  {farmName}
                </h3>
                <p className="text-sm font-bold" style={{ color: oliveTheme.primary }}>
                  حجز مؤقت سريع
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div
          className="rounded-3xl p-10 md:p-14 mb-8 text-center relative overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${oliveTheme.dark}, ${oliveTheme.darkest})`,
            boxShadow: `0 24px 60px ${oliveTheme.darkest}40`
          }}
        >
          <div className="absolute -top-10 -right-10 w-60 h-60 rounded-full opacity-10" style={{ background: oliveTheme.lightest }} />
          <div className="absolute -bottom-10 -left-10 w-60 h-60 rounded-full opacity-10" style={{ background: oliveTheme.lightest }} />
          <div className="absolute top-10 left-10 opacity-20">
            <Leaf className="w-24 h-24 text-white animate-pulse" />
          </div>
          <div className="absolute bottom-10 right-10 opacity-20">
            <TreeDeciduous className="w-24 h-24 text-white animate-pulse" style={{ animationDelay: '1s' }} />
          </div>

          <div className="relative z-10">
            <h1 className="text-4xl md:text-5xl font-black mb-4 text-white">
              احجز أشجارك الآن
            </h1>
            <p className="text-xl text-white opacity-90 mb-6">
              اختر الأصناف والكميات المطلوبة واحصل على حجزك الفوري
            </p>
            <div
              className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl shadow-2xl"
              style={{
                background: 'white',
                border: `3px solid ${oliveTheme.accent}`
              }}
            >
              <TreeDeciduous className="w-6 h-6" style={{ color: oliveTheme.primary }} />
              <span className="font-black text-xl" style={{ color: oliveTheme.darkest }}>
                {varieties.length} {varieties.length === 1 ? 'صنف متميز' : 'أصناف متميزة'}
              </span>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div
              className="rounded-3xl overflow-hidden"
              style={{
                background: 'white',
                border: `3px solid ${oliveTheme.lighter}`,
                boxShadow: `0 20px 60px ${oliveTheme.primary}15`
              }}
            >
              <div
                className="p-8 border-b"
                style={{
                  background: `linear-gradient(to left, ${oliveTheme.lightest}, white)`,
                  borderColor: `${oliveTheme.lighter}`
                }}
              >
                <div className="flex items-center gap-4">
                  <div
                    className="p-3 rounded-2xl"
                    style={{ background: `linear-gradient(135deg, ${oliveTheme.light}, ${oliveTheme.primary})` }}
                  >
                    <ShoppingCart className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-black mb-1" style={{ color: oliveTheme.darkest }}>
                      اختر الأصناف والكميات
                    </h2>
                    <p className="text-gray-600 font-bold">حدد عدد الأشجار لكل صنف</p>
                  </div>
                </div>
              </div>

              <div className="p-8 space-y-5 max-h-[600px] overflow-y-auto">
                {varieties.map((variety, index) => {
                  const selection = selections.get(variety.id);
                  const quantity = selection?.quantity || 0;
                  const subtotal = quantity * variety.price_per_tree;

                  return (
                    <div
                      key={variety.id}
                      className="rounded-2xl p-6 transition-all duration-300 relative group"
                      style={{
                        background: quantity > 0
                          ? `linear-gradient(135deg, ${oliveTheme.lightest}, white)`
                          : 'linear-gradient(135deg, #fafafa, #ffffff)',
                        border: quantity > 0
                          ? `3px solid ${oliveTheme.primary}`
                          : '2px solid #e5e7eb',
                        boxShadow: quantity > 0
                          ? `0 12px 32px ${oliveTheme.primary}25`
                          : '0 2px 8px rgba(0,0,0,0.05)',
                        transform: quantity > 0 ? 'scale(1.02)' : 'scale(1)'
                      }}
                    >
                      {quantity > 0 && (
                        <>
                          <div
                            className="absolute top-0 left-0 right-0 h-2 rounded-t-2xl"
                            style={{ background: `linear-gradient(90deg, ${oliveTheme.light}, ${oliveTheme.accent})` }}
                          />
                          <div className="absolute top-3 left-3">
                            <Star className="w-6 h-6 animate-pulse" style={{ color: oliveTheme.accent }} fill="currentColor" />
                          </div>
                        </>
                      )}

                      <div className="flex items-start justify-between gap-4 mb-5">
                        <div className="flex-1">
                          <div className="flex items-center gap-4 mb-3">
                            <div
                              className="w-12 h-12 rounded-xl flex items-center justify-center text-xl font-black shadow-xl"
                              style={{
                                background: `linear-gradient(135deg, ${oliveTheme.light}, ${oliveTheme.primary})`,
                                color: 'white'
                              }}
                            >
                              {index + 1}
                            </div>
                            <h3 className="text-2xl font-black" style={{ color: oliveTheme.darkest }}>
                              {variety.variety_name}
                            </h3>
                          </div>

                          <p className="text-gray-600 mb-4 leading-relaxed text-lg">
                            {variety.description_ar || 'صنف متميز بجودة عالية'}
                          </p>

                          <div className="flex items-center gap-3 flex-wrap">
                            <div
                              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold"
                              style={{ background: '#dcfce7', border: '2px solid #86efac' }}
                            >
                              <TreeDeciduous className="w-5 h-5 text-green-700" />
                              <span className="text-gray-800">متاح:</span>
                              <span className="text-green-700 text-lg">{variety.available_quantity}</span>
                            </div>
                            <div
                              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold"
                              style={{ background: oliveTheme.lightest, border: `2px solid ${oliveTheme.lighter}` }}
                            >
                              <TrendingUp className="w-5 h-5" style={{ color: oliveTheme.primary }} />
                              <span className="text-gray-800">السعر:</span>
                              <span style={{ color: oliveTheme.primary }} className="text-lg">
                                {variety.price_per_tree.toLocaleString()} ريال
                              </span>
                            </div>
                          </div>
                        </div>

                        {quantity > 0 && (
                          <button
                            onClick={() => updateQuantity(variety.id, 0, variety)}
                            className="p-3 rounded-xl bg-red-500 text-white hover:bg-red-600 transition-all hover:scale-110 shadow-xl"
                          >
                            <X className="w-6 h-6" />
                          </button>
                        )}
                      </div>

                      <div className="flex items-center justify-between gap-4 pt-5 border-t-2" style={{ borderColor: quantity > 0 ? oliveTheme.lighter : '#f3f4f6' }}>
                        <div className="flex items-center gap-4">
                          <span className="text-lg font-black text-gray-800">الكمية:</span>
                          <div className="flex items-center gap-3">
                            <button
                              onClick={() => updateQuantity(variety.id, quantity - 1, variety)}
                              disabled={quantity <= 0}
                              className="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-white transition-all hover:scale-110 disabled:opacity-30 disabled:cursor-not-allowed shadow-lg"
                              style={{ background: `linear-gradient(135deg, ${oliveTheme.light}, ${oliveTheme.primary})` }}
                            >
                              <Minus className="w-6 h-6" />
                            </button>

                            <input
                              type="number"
                              min="0"
                              max={variety.available_quantity}
                              value={quantity}
                              onChange={(e) => {
                                const val = parseInt(e.target.value) || 0;
                                updateQuantity(variety.id, val, variety);
                              }}
                              className="w-28 h-12 rounded-xl text-center font-black text-2xl border-3 focus:outline-none transition-all shadow-inner"
                              style={{
                                borderColor: quantity > 0 ? oliveTheme.primary : '#d1d5db',
                                color: oliveTheme.darkest,
                                background: quantity > 0 ? 'white' : '#f9fafb'
                              }}
                            />

                            <button
                              onClick={() => updateQuantity(variety.id, quantity + 1, variety)}
                              disabled={quantity >= variety.available_quantity}
                              className="w-12 h-12 rounded-xl flex items-center justify-center font-bold text-white transition-all hover:scale-110 disabled:opacity-30 disabled:cursor-not-allowed shadow-lg"
                              style={{ background: `linear-gradient(135deg, ${oliveTheme.light}, ${oliveTheme.primary})` }}
                            >
                              <Plus className="w-6 h-6" />
                            </button>
                          </div>
                        </div>

                        {quantity > 0 && (
                          <div className="text-right">
                            <p className="text-sm text-gray-500 mb-1 flex items-center justify-end gap-1.5">
                              <Calculator className="w-4 h-4" />
                              المجموع
                            </p>
                            <p className="text-3xl font-black" style={{ color: oliveTheme.primary }}>
                              {subtotal.toLocaleString()}
                              <span className="text-lg mr-1">ريال</span>
                            </p>
                          </div>
                        )}
                      </div>

                      {variety.available_quantity < 10 && (
                        <div
                          className="mt-4 flex items-center gap-3 px-5 py-3 rounded-xl text-sm font-bold"
                          style={{
                            background: 'linear-gradient(135deg, #FEF3C7, #FDE68A)',
                            border: '2px solid #FCD34D'
                          }}
                        >
                          <AlertCircle className="w-6 h-6 text-amber-700" />
                          <span className="text-amber-900 text-base">
                            ⚠️ كمية محدودة! متبقي {variety.available_quantity} فقط
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}

                {varieties.length === 0 && (
                  <div className="text-center py-16">
                    <div
                      className="w-24 h-24 rounded-full mx-auto mb-5 flex items-center justify-center"
                      style={{ background: oliveTheme.lightest }}
                    >
                      <Info className="w-12 h-12" style={{ color: oliveTheme.primary }} />
                    </div>
                    <p className="text-xl font-bold text-gray-600">لا توجد أصناف متاحة حالياً</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-28">
              {selections.size > 0 ? (
                <div
                  className="rounded-3xl overflow-hidden"
                  style={{
                    background: 'white',
                    border: `3px solid ${oliveTheme.primary}`,
                    boxShadow: `0 24px 60px ${oliveTheme.primary}30`
                  }}
                >
                  <div
                    className="p-6 text-center relative overflow-hidden"
                    style={{ background: `linear-gradient(135deg, ${oliveTheme.dark}, ${oliveTheme.darkest})` }}
                  >
                    <div className="absolute top-0 right-0 opacity-20">
                      <Leaf className="w-24 h-24 text-white" />
                    </div>
                    <Award className="w-12 h-12 mx-auto mb-3 text-white relative z-10" />
                    <h3 className="text-2xl font-black text-white mb-1 relative z-10">
                      ملخص الطلب
                    </h3>
                    <p className="text-white opacity-90 relative z-10 font-bold text-sm">
                      مراجعة وإتمام الحجز
                    </p>
                  </div>

                  <div className="p-5 space-y-4">
                    <div
                      className="p-4 rounded-2xl"
                      style={{
                        background: `linear-gradient(135deg, ${oliveTheme.lightest}, white)`,
                        border: `2px solid ${oliveTheme.lighter}`
                      }}
                    >
                      <div className="flex justify-between items-center mb-3 pb-3 border-b-2" style={{ borderColor: oliveTheme.lighter }}>
                        <span className="text-gray-700 font-black text-base">إجمالي الأشجار</span>
                        <span className="text-3xl font-black" style={{ color: oliveTheme.primary }}>
                          {calculateTotalTrees()}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700 font-black text-base">المبلغ الإجمالي</span>
                        <div className="text-right">
                          <span className="text-3xl font-black block" style={{ color: oliveTheme.darkest }}>
                            {calculateTotal().toLocaleString()}
                          </span>
                          <span className="text-xs text-gray-600 font-bold">ريال سعودي</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Edit3 className="w-5 h-5" style={{ color: oliveTheme.primary }} />
                        <h3 className="text-lg font-black" style={{ color: oliveTheme.darkest }}>
                          أدخل بياناتك
                        </h3>
                      </div>

                      <div>
                        <label className="flex items-center gap-2 mb-2 font-black text-gray-700 text-sm">
                          <User className="w-4 h-4" style={{ color: oliveTheme.primary }} />
                          الاسم الكامل *
                        </label>
                        <input
                          type="text"
                          value={investorName}
                          onChange={(e) => setInvestorName(e.target.value)}
                          placeholder="أدخل اسمك الكامل"
                          className="w-full px-4 py-3 rounded-xl border-3 focus:outline-none transition-all font-bold text-base shadow-inner"
                          style={{
                            borderColor: investorName ? oliveTheme.primary : '#d1d5db',
                            background: investorName ? oliveTheme.cream : 'white'
                          }}
                        />
                      </div>

                      <div>
                        <label className="flex items-center gap-2 mb-2 font-black text-gray-700 text-sm">
                          <Phone className="w-4 h-4" style={{ color: oliveTheme.primary }} />
                          رقم الجوال *
                        </label>
                        <div className="flex gap-2">
                          <div
                            className="px-3 py-3 rounded-xl font-black text-base flex items-center shadow-inner flex-shrink-0"
                            style={{
                              background: oliveTheme.lightest,
                              color: oliveTheme.darkest,
                              border: `3px solid ${oliveTheme.lighter}`
                            }}
                          >
                            +966
                          </div>
                          <input
                            type="tel"
                            value={investorPhone}
                            onChange={(e) => setInvestorPhone(e.target.value)}
                            placeholder="5xxxxxxxx"
                            className="flex-1 min-w-0 px-4 py-3 rounded-xl border-3 focus:outline-none transition-all font-bold text-base shadow-inner"
                            style={{
                              borderColor: investorPhone ? oliveTheme.primary : '#d1d5db',
                              background: investorPhone ? oliveTheme.cream : 'white'
                            }}
                          />
                        </div>
                      </div>

                      <button
                        onClick={handleSubmit}
                        disabled={submitting || !investorName || !investorPhone}
                        className="w-full py-4 rounded-xl font-black text-lg text-white transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-2xl mt-4"
                        style={{
                          background: `linear-gradient(135deg, ${oliveTheme.light}, ${oliveTheme.primary})`
                        }}
                      >
                        {submitting ? (
                          <>
                            <SimpleLoader size="sm" color="#FFFFFF" />
                            <span className="mr-2">جاري التأكيد...</span>
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="h-6 w-6" />
                            تأكيد الحجز الآن
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div
                  className="rounded-3xl p-12 text-center"
                  style={{
                    background: 'white',
                    border: `3px dashed ${oliveTheme.lighter}`,
                    boxShadow: `0 12px 32px ${oliveTheme.primary}10`
                  }}
                >
                  <div
                    className="w-24 h-24 rounded-full mx-auto mb-6 flex items-center justify-center"
                    style={{ background: oliveTheme.lightest }}
                  >
                    <ShoppingCart className="w-12 h-12" style={{ color: oliveTheme.primary }} />
                  </div>
                  <h3 className="text-2xl font-black mb-3" style={{ color: oliveTheme.darkest }}>
                    ابدأ باختيار الأصناف
                  </h3>
                  <p className="text-gray-600 text-lg">
                    حدد الكميات المطلوبة من الأصناف لعرض الملخص
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
