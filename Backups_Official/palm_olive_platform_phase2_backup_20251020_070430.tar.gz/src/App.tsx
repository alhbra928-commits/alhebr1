import { DashboardView } from './modules/dashboard/DashboardView';

function App() {
  return (
    <div className="min-h-screen">
      <DashboardView />
    </div>
  );
}

export default App;
