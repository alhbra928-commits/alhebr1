import { supabase } from '../../../lib/supabase';

export interface InvestorReservation {
  id: string;
  farm_id: string;
  farm_name: string;
  farm_type: string;
  number_of_trees: number;
  total_amount: number;
  status: string;
  payment_status: string;
  reservation_date: string;
  created_at: string;
}

export interface InvestorStats {
  totalFarms: number;
  totalReservations: number;
  totalTrees: number;
  totalAmount: number;
  pendingReservations: number;
  completedReservations: number;
}

export interface InvestorTimeline {
  id: string;
  event_type: string;
  title: string;
  description: string;
  date: string;
  icon: string;
}

export interface LoginCheckResult {
  exists: boolean;
  requiresOTP: boolean;
  isFirstLogin: boolean;
  sessionToken?: string;
}

export interface LoginAttemptData {
  phone: string;
  ip_address?: string;
  user_agent?: string;
  device_type?: string;
  login_type: string;
  otp_entered?: string;
  success: boolean;
  failure_reason?: string;
}

const DEMO_MODE = true;
const DEMO_OTP = '4821';

export class InvestorService {
  static async getInvestorByPhone(phone: string): Promise<any> {
    try {
      const { data: investor, error: investorError } = await supabase
        .from('investors')
        .select('*')
        .eq('phone', phone)
        .is('deleted_at', null)
        .maybeSingle();

      if (investorError) throw investorError;

      if (investor) {
        return {
          customer_name: investor.full_name,
          customer_phone: investor.phone
        };
      }

      const { data: reservation, error: reservationError } = await supabase
        .from('reservations')
        .select('customer_name, customer_phone')
        .eq('customer_phone', phone)
        .maybeSingle();

      if (reservationError) throw reservationError;
      return reservation;
    } catch (error) {
      console.error('Error fetching investor:', error);
      throw error;
    }
  }

  static async getInvestorReservations(phone: string): Promise<InvestorReservation[]> {
    try {
      const { data, error } = await supabase
        .from('reservations')
        .select(`
          id,
          farm_id,
          number_of_trees,
          total_amount,
          status,
          payment_status,
          reservation_date,
          created_at,
          farms!inner(
            name_ar,
            farm_type
          )
        `)
        .eq('customer_phone', phone)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return (data || []).map((r: any) => ({
        id: r.id,
        farm_id: r.farm_id,
        farm_name: r.farms?.name_ar || 'مزرعة',
        farm_type: r.farms?.farm_type || 'نخيل',
        number_of_trees: r.number_of_trees,
        total_amount: r.total_amount,
        status: r.status,
        payment_status: r.payment_status,
        reservation_date: r.reservation_date,
        created_at: r.created_at
      }));
    } catch (error) {
      console.error('Error fetching reservations:', error);
      throw error;
    }
  }

  static async getInvestorStats(phone: string): Promise<InvestorStats> {
    try {
      const reservations = await this.getInvestorReservations(phone);

      const uniqueFarms = new Set(reservations.map(r => r.farm_id));
      const totalTrees = reservations.reduce((sum, r) => sum + r.number_of_trees, 0);
      const totalAmount = reservations.reduce((sum, r) => sum + parseFloat(r.total_amount.toString()), 0);
      const pendingReservations = reservations.filter(r => r.status === 'pending').length;
      const completedReservations = reservations.filter(r => r.status === 'completed').length;

      return {
        totalFarms: uniqueFarms.size,
        totalReservations: reservations.length,
        totalTrees,
        totalAmount,
        pendingReservations,
        completedReservations
      };
    } catch (error) {
      console.error('Error fetching stats:', error);
      throw error;
    }
  }

  static async getInvestorTimeline(phone: string): Promise<InvestorTimeline[]> {
    try {
      const reservations = await this.getInvestorReservations(phone);

      const timeline: InvestorTimeline[] = reservations.map(r => ({
        id: r.id,
        event_type: 'reservation',
        title: `حجز جديد في ${r.farm_name}`,
        description: `تم حجز ${r.number_of_trees} شجرة بقيمة ${r.total_amount.toLocaleString('ar-SA')} ر.س`,
        date: r.created_at,
        icon: '📋'
      }));

      return timeline.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    } catch (error) {
      console.error('Error fetching timeline:', error);
      throw error;
    }
  }

  static async getInvestorFarms(phone: string): Promise<any[]> {
    try {
      const reservations = await this.getInvestorReservations(phone);
      const farmMap = new Map();

      reservations.forEach(r => {
        if (farmMap.has(r.farm_id)) {
          const existing = farmMap.get(r.farm_id);
          existing.total_trees += r.number_of_trees;
          existing.total_amount += parseFloat(r.total_amount.toString());
        } else {
          farmMap.set(r.farm_id, {
            farm_id: r.farm_id,
            farm_name: r.farm_name,
            farm_type: r.farm_type,
            total_trees: r.number_of_trees,
            total_amount: parseFloat(r.total_amount.toString()),
            status: r.status
          });
        }
      });

      return Array.from(farmMap.values());
    } catch (error) {
      console.error('Error fetching farms:', error);
      throw error;
    }
  }

  static async checkLoginStatus(phone: string): Promise<LoginCheckResult> {
    try {
      const { data: activeSessions } = await supabase
        .from('investor_sessions')
        .select('*')
        .eq('phone', phone)
        .eq('is_active', true)
        .gt('expires_at', new Date().toISOString())
        .order('started_at', { ascending: false })
        .limit(1);

      const hasActiveSession = activeSessions && activeSessions.length > 0;

      if (hasActiveSession) {
        return {
          exists: true,
          requiresOTP: false,
          isFirstLogin: false,
          sessionToken: activeSessions[0].session_token
        };
      }

      const { data: previousSessions } = await supabase
        .from('investor_sessions')
        .select('id')
        .eq('phone', phone)
        .limit(1);

      const isFirstLogin = !previousSessions || previousSessions.length === 0;

      return {
        exists: true,
        requiresOTP: !isFirstLogin,
        isFirstLogin
      };
    } catch (error) {
      console.error('Error checking login status:', error);
      throw error;
    }
  }

  static async verifyOTP(phone: string, otp: string): Promise<boolean> {
    if (DEMO_MODE) {
      return otp === DEMO_OTP;
    }

    return false;
  }

  static async createSession(phone: string, isFirstLogin: boolean): Promise<string> {
    try {
      const sessionToken = this.generateSessionToken();
      const deviceType = this.detectDeviceType();

      const { error } = await supabase
        .from('investor_sessions')
        .insert([{
          phone,
          session_token: sessionToken,
          ip_address: null,
          user_agent: navigator.userAgent,
          device_type: deviceType,
          is_active: true,
          is_first_login: isFirstLogin,
          otp_required: !isFirstLogin,
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
        }]);

      if (error) throw error;

      return sessionToken;
    } catch (error) {
      console.error('Error creating session:', error);
      throw error;
    }
  }

  static async logLoginAttempt(data: LoginAttemptData): Promise<void> {
    try {
      const deviceType = this.detectDeviceType();

      await supabase
        .from('investor_login_attempts')
        .insert([{
          phone: data.phone,
          ip_address: data.ip_address,
          user_agent: navigator.userAgent,
          device_type: deviceType,
          login_type: data.login_type,
          otp_entered: data.otp_entered,
          success: data.success,
          failure_reason: data.failure_reason
        }]);
    } catch (error) {
      console.error('Error logging login attempt:', error);
    }
  }

  static async invalidateSession(sessionToken: string): Promise<void> {
    try {
      await supabase
        .from('investor_sessions')
        .update({
          is_active: false,
          ended_at: new Date().toISOString()
        })
        .eq('session_token', sessionToken);
    } catch (error) {
      console.error('Error invalidating session:', error);
      throw error;
    }
  }

  private static generateSessionToken(): string {
    return `investor_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
  }

  private static detectDeviceType(): string {
    const userAgent = navigator.userAgent.toLowerCase();

    if (/mobile|android|iphone|ipad|ipod/.test(userAgent)) {
      return 'mobile';
    } else if (/tablet/.test(userAgent)) {
      return 'tablet';
    } else {
      return 'desktop';
    }
  }

  static getDemoOTP(): string {
    return DEMO_MODE ? DEMO_OTP : '';
  }

  static isDemoMode(): boolean {
    return DEMO_MODE;
  }
}
