import { supabase } from '../../lib/supabase';

export interface Booking {
  id: string;
  booking_code: string;
  farm_id: string;
  investor_id: string;
  farm_code?: string;
  investor_name: string;
  investor_mobile: string;
  investor_email?: string;
  reserved_trees: number;
  total_price: number;
  payment_status: 'pending' | 'partial' | 'completed';
  payment_amount: number;
  booking_status: 'pending' | 'approved' | 'rejected' | 'documented';
  booking_date: string;
  approved_at?: string;
  approved_by?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
  farm?: any;
  investor?: any;
}

export interface CreateBookingParams {
  farm_id: string;
  investor_id: string;
  investor_name: string;
  investor_mobile: string;
  investor_email?: string;
  reserved_trees: number;
  total_price: number;
  notes?: string;
}

export class BookingsService {
  static async getAll(): Promise<Booking[]> {
    console.log('📥 BookingsService.getAll() called');

    // قراءة من جدول reservations (البيانات الحقيقية)
    const { data: reservationsData, error: reservationsError } = await supabase
      .from('reservations')
      .select(`
        *,
        farms:farm_id(id, farm_code, name_ar, farm_type, region, city)
      `)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    console.log('📊 Reservations data:', {
      count: reservationsData?.length,
      error: reservationsError
    });

    if (reservationsError) {
      console.error('Error fetching reservations:', reservationsError);
      throw reservationsError;
    }

    // تحويل بيانات reservations إلى شكل Booking
    const convertedReservations: Booking[] = (reservationsData || []).map(res => {
      // إنشاء booking_code من ID إذا لم يكن موجود
      const bookingCode = `RES-${res.id.substring(0, 8)}`;

      return {
        id: res.id,
        booking_code: bookingCode,
        farm_id: res.farm_id,
        investor_id: res.investor_id || '',
        farm_code: res.farms?.farm_code,
        investor_name: res.customer_name || 'غير معروف',
        investor_mobile: res.customer_phone || '',
        investor_email: '',
        reserved_trees: res.number_of_trees || 0,
        total_price: Number(res.total_amount) || 0,
        payment_status: res.payment_status as any || 'pending',
        payment_amount: 0,
        booking_status: this.mapReservationStatus(res.status),
        booking_date: res.reservation_date || res.created_at,
        notes: '',
        created_at: res.created_at,
        updated_at: res.updated_at || res.created_at,
        deleted_at: res.deleted_at,
        farm: res.farms
      };
    });

    console.log('✅ Converted reservations:', convertedReservations.length);

    // قراءة من جدول bookings (إن وُجد)
    const { data: bookingsData, error: bookingsError } = await supabase
      .from('bookings')
      .select(`
        *,
        farms:farm_id(id, farm_code, name_ar, farm_type, region, city),
        investors:investor_id(id, full_name, phone, email)
      `)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    console.log('📊 Bookings data:', {
      count: bookingsData?.length,
      error: bookingsError
    });

    // دمج المصفوفتين
    const allBookings = [...convertedReservations, ...(bookingsData || [])];

    console.log('✅ Combined total:', allBookings.length);

    return allBookings;
  }

  // دالة مساعدة لتحويل status من reservations إلى booking_status
  private static mapReservationStatus(status: string): 'pending' | 'approved' | 'rejected' | 'documented' {
    const statusMap: { [key: string]: 'pending' | 'approved' | 'rejected' | 'documented' } = {
      'pending': 'pending',
      'pending_contact': 'pending',
      'approved': 'approved',
      'confirmed': 'approved',
      'rejected': 'rejected',
      'cancelled': 'rejected',
      'documented': 'documented',
      'completed': 'documented'
    };
    return statusMap[status] || 'pending';
  }

  static async getById(id: string): Promise<Booking | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        farms:farm_id(*),
        investors:investor_id(*)
      `)
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) {
      console.error('Error fetching booking:', error);
      throw error;
    }

    return data;
  }

  static async getByStatus(status: string): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        farms:farm_id(id, farm_code, name_ar),
        investors:investor_id(id, full_name, phone)
      `)
      .eq('booking_status', status)
      .is('deleted_at', null)
      .order('created_at', { ascending: false});

    if (error) {
      console.error('Error fetching bookings by status:', error);
      throw error;
    }

    return data || [];
  }

  static async create(params: CreateBookingParams): Promise<Booking> {
    const farm = await supabase
      .from('farms')
      .select('farm_code')
      .eq('id', params.farm_id)
      .maybeSingle();

    const { data, error } = await supabase
      .from('bookings')
      .insert([{
        farm_id: params.farm_id,
        investor_id: params.investor_id,
        farm_code: farm.data?.farm_code,
        investor_name: params.investor_name,
        investor_mobile: params.investor_mobile,
        investor_email: params.investor_email,
        reserved_trees: params.reserved_trees,
        total_price: params.total_price,
        payment_status: 'pending',
        payment_amount: 0,
        booking_status: 'pending',
        notes: params.notes,
        booking_date: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) throw error;
    return data as Booking;
  }

  static async updateStatus(
    id: string,
    status: 'pending' | 'approved' | 'rejected' | 'documented',
    approvedBy?: string
  ): Promise<Booking> {
    console.log('📝 BookingsService.updateStatus() called:', { id, status });

    // تحويل booking_status إلى status المناسب لجدول reservations
    const reservationStatusMap: { [key: string]: string } = {
      'pending': 'pending',
      'approved': 'confirmed',
      'rejected': 'cancelled',
      'documented': 'completed'
    };

    const reservationStatus = reservationStatusMap[status] || status;

    // محاولة التحديث في جدول reservations أولاً
    const { data: resData, error: resError } = await supabase
      .from('reservations')
      .update({
        status: reservationStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .is('deleted_at', null)
      .select(`
        *,
        farms:farm_id(id, farm_code, name_ar, farm_type, region, city)
      `)
      .maybeSingle();

    if (!resError && resData) {
      console.log('✅ Updated reservation successfully');

      // تحويل البيانات المحدثة إلى شكل Booking
      const bookingCode = `RES-${resData.id.substring(0, 8)}`;
      const convertedBooking: Booking = {
        id: resData.id,
        booking_code: bookingCode,
        farm_id: resData.farm_id,
        investor_id: resData.investor_id || '',
        farm_code: resData.farms?.farm_code,
        investor_name: resData.customer_name || 'غير معروف',
        investor_mobile: resData.customer_phone || '',
        investor_email: '',
        reserved_trees: resData.number_of_trees || 0,
        total_price: Number(resData.total_amount) || 0,
        payment_status: resData.payment_status as any || 'pending',
        payment_amount: 0,
        booking_status: status,
        booking_date: resData.reservation_date || resData.created_at,
        notes: '',
        created_at: resData.created_at,
        updated_at: resData.updated_at || resData.created_at,
        deleted_at: resData.deleted_at,
        farm: resData.farms
      };

      return convertedBooking;
    }

    console.log('⚠️ Not found in reservations, trying bookings table');

    // إذا لم يوجد في reservations، حاول في bookings
    const updates: any = {
      booking_status: status,
      updated_at: new Date().toISOString()
    };

    if (status === 'approved') {
      updates.approved_at = new Date().toISOString();
      updates.approved_by = approvedBy;
    }

    const { data, error } = await supabase
      .from('bookings')
      .update(updates)
      .eq('id', id)
      .is('deleted_at', null)
      .select()
      .single();

    if (error) {
      console.error('❌ Error updating booking:', error);
      throw error;
    }

    console.log('✅ Updated booking successfully');
    return data as Booking;
  }

  static async updatePayment(
    id: string,
    paymentAmount: number,
    paymentStatus: 'pending' | 'partial' | 'completed'
  ): Promise<Booking> {
    console.log('💰 BookingsService.updatePayment() called:', { id, paymentAmount, paymentStatus });

    // محاولة التحديث في جدول reservations أولاً
    const { data: resData, error: resError } = await supabase
      .from('reservations')
      .update({
        payment_status: paymentStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .is('deleted_at', null)
      .select(`
        *,
        farms:farm_id(id, farm_code, name_ar, farm_type, region, city)
      `)
      .maybeSingle();

    if (!resError && resData) {
      console.log('✅ Updated reservation payment successfully');

      // تحويل البيانات المحدثة إلى شكل Booking
      const bookingCode = `RES-${resData.id.substring(0, 8)}`;
      const convertedBooking: Booking = {
        id: resData.id,
        booking_code: bookingCode,
        farm_id: resData.farm_id,
        investor_id: resData.investor_id || '',
        farm_code: resData.farms?.farm_code,
        investor_name: resData.customer_name || 'غير معروف',
        investor_mobile: resData.customer_phone || '',
        investor_email: '',
        reserved_trees: resData.number_of_trees || 0,
        total_price: Number(resData.total_amount) || 0,
        payment_status: resData.payment_status as any || 'pending',
        payment_amount: paymentAmount,
        booking_status: this.mapReservationStatus(resData.status),
        booking_date: resData.reservation_date || resData.created_at,
        notes: '',
        created_at: resData.created_at,
        updated_at: resData.updated_at || resData.created_at,
        deleted_at: resData.deleted_at,
        farm: resData.farms
      };

      return convertedBooking;
    }

    console.log('⚠️ Not found in reservations, trying bookings table');

    // إذا لم يوجد في reservations، حاول في bookings
    const { data, error } = await supabase
      .from('bookings')
      .update({
        payment_amount: paymentAmount,
        payment_status: paymentStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .is('deleted_at', null)
      .select()
      .single();

    if (error) {
      console.error('❌ Error updating payment:', error);
      throw error;
    }

    console.log('✅ Updated booking payment successfully');
    return data as Booking;
  }

  static async delete(id: string): Promise<void> {
    console.log('🗑️ BookingsService.delete() called:', id);

    // محاولة الحذف من reservations أولاً
    const { error: resError } = await supabase
      .from('reservations')
      .update({
        deleted_at: new Date().toISOString()
      })
      .eq('id', id);

    if (!resError) {
      console.log('✅ Deleted reservation successfully');
      return;
    }

    console.log('⚠️ Not found in reservations, trying bookings table');

    // إذا لم يوجد في reservations، حاول في bookings
    const { error } = await supabase
      .from('bookings')
      .update({
        deleted_at: new Date().toISOString()
      })
      .eq('id', id);

    if (error) {
      console.error('❌ Error deleting booking:', error);
      throw error;
    }

    console.log('✅ Deleted booking successfully');
  }

  static async migrateToDocumentation(
    bookingId: string,
    migratedBy?: string
  ): Promise<string> {
    const { data, error } = await supabase.rpc('auto_migrate_to_documentation', {
      p_booking_id: bookingId,
      p_migrated_by: migratedBy,
      p_migration_reason: 'Certificate issued'
    });

    if (error) {
      console.error('Error migrating to documentation:', error);
      throw error;
    }

    return data;
  }

  static async getStatistics() {
    console.log('📊 BookingsService.getStatistics() called');

    // الحصول على جميع الحجوزات من الدالة الموحدة
    const allBookings = await this.getAll();

    console.log('✅ Statistics from', allBookings.length, 'total bookings');

    if (!allBookings || allBookings.length === 0) {
      return {
        total: 0,
        pending: 0,
        approved: 0,
        rejected: 0,
        documented: 0,
        totalAmount: 0,
        totalTrees: 0,
        pendingPayment: 0,
        partialPayment: 0,
        completedPayment: 0
      };
    }

    return {
      total: allBookings.length,
      pending: allBookings.filter(b => b.booking_status === 'pending').length,
      approved: allBookings.filter(b => b.booking_status === 'approved').length,
      rejected: allBookings.filter(b => b.booking_status === 'rejected').length,
      documented: allBookings.filter(b => b.booking_status === 'documented').length,
      totalAmount: allBookings.reduce((sum, b) => sum + Number(b.total_price), 0),
      totalTrees: allBookings.reduce((sum, b) => sum + b.reserved_trees, 0),
      pendingPayment: allBookings.filter(b => b.payment_status === 'pending').length,
      partialPayment: allBookings.filter(b => b.payment_status === 'partial').length,
      completedPayment: allBookings.filter(b => b.payment_status === 'completed').length
    };
  }

  static formatPrice(price: number): string {
    return `${price.toLocaleString('ar-SA')} ريال`;
  }

  static getStatusColor(status: string): string {
    const colorMap: { [key: string]: string } = {
      pending: 'bg-yellow-100 text-yellow-700 border-yellow-400',
      approved: 'bg-green-100 text-green-700 border-green-400',
      rejected: 'bg-red-100 text-red-700 border-red-400',
      documented: 'bg-blue-100 text-blue-700 border-blue-400'
    };
    return colorMap[status] || 'bg-gray-100 text-gray-700 border-gray-400';
  }

  static getStatusLabel(status: string): string {
    const labelMap: { [key: string]: string } = {
      pending: 'قيد الانتظار',
      approved: 'موافق عليه',
      rejected: 'مرفوض',
      documented: 'موثّق'
    };
    return labelMap[status] || status;
  }

  static getPaymentStatusColor(status: string): string {
    const colorMap: { [key: string]: string } = {
      pending: 'bg-orange-100 text-orange-700',
      partial: 'bg-yellow-100 text-yellow-700',
      completed: 'bg-green-100 text-green-700'
    };
    return colorMap[status] || 'bg-gray-100 text-gray-700';
  }

  static getPaymentStatusLabel(status: string): string {
    const labelMap: { [key: string]: string } = {
      pending: 'لم يدفع',
      partial: 'دفع جزئي',
      completed: 'مدفوع كاملاً'
    };
    return labelMap[status] || status;
  }
}
