import React from 'react';
import {
  X,
  MapPin,
  User,
  Phone,
  Mail,
  Calendar,
  Trees,
  DollarSign,
  FileText,
  Award,
  CheckCircle,
  XCircle,
  Pause,
  Trash2,
  Map
} from 'lucide-react';
import { Booking } from '../bookingsService';

interface BookingDetailsPanelProps {
  booking: Booking | null;
  isOpen: boolean;
  onClose: () => void;
  onApprove: (booking: Booking) => void;
  onReject: (booking: Booking) => void;
  onFreeze: (booking: Booking) => void;
  onDelete: (booking: Booking) => void;
  onIssueCertificate: (booking: Booking) => void;
}

export function BookingDetailsPanel({
  booking,
  isOpen,
  onClose,
  onApprove,
  onReject,
  onFreeze,
  onDelete,
  onIssueCertificate
}: BookingDetailsPanelProps) {
  if (!isOpen || !booking) return null;

  const getStatusConfig = (status: string) => {
    const configs: any = {
      pending: { label: 'بانتظار المراجعة', color: 'bg-yellow-100 text-yellow-700' },
      approved: { label: 'معتمد', color: 'bg-green-100 text-green-700' },
      rejected: { label: 'مرفوض', color: 'bg-red-100 text-red-700' },
      documented: { label: 'موثّق', color: 'bg-blue-100 text-blue-700' }
    };
    return configs[status] || configs.pending;
  };

  const statusConfig = getStatusConfig(booking.booking_status);

  const timelineSteps = [
    {
      label: 'إنشاء الحجز',
      date: booking.booking_date,
      completed: true,
      icon: Calendar
    },
    {
      label: 'المراجعة والموافقة',
      date: booking.approved_at,
      completed: booking.booking_status !== 'pending',
      icon: CheckCircle
    },
    {
      label: 'إصدار الشهادة',
      date: null,
      completed: booking.booking_status === 'documented',
      icon: Award
    }
  ];

  return (
    <>
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
        onClick={onClose}
      />

      <div className="fixed top-0 left-0 h-full w-full md:w-[600px] bg-white shadow-2xl z-50 overflow-y-auto" dir="rtl">
        <div className="sticky top-0 bg-gradient-to-r from-[#C89B3C] to-[#D4B574] p-6 shadow-lg z-10">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black text-white mb-1">تفاصيل الحجز</h2>
              <p className="text-white/90 font-mono text-sm">{booking.booking_code}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
            >
              <X className="h-6 w-6 text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className={`p-4 rounded-xl border-2 ${statusConfig.color}`}>
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold">الحالة الحالية:</span>
              <span className="text-lg font-black">{statusConfig.label}</span>
            </div>
          </div>

          <section className="bg-gradient-to-br from-amber-50 to-orange-50 p-5 rounded-xl border-2 border-amber-200">
            <h3 className="text-lg font-black text-[#2C2C2C] mb-4 flex items-center gap-2">
              <MapPin className="h-5 w-5 text-[#C89B3C]" />
              بيانات المزرعة
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70">اسم المزرعة:</span>
                <span className="font-bold">{booking.farm?.name_ar || 'غير محدد'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70">كود المزرعة:</span>
                <span className="font-mono font-bold text-[#C89B3C]">{booking.farm_code || 'لا يوجد'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70">المنطقة:</span>
                <span className="font-bold">{booking.farm?.region || 'غير محدد'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70">المدينة:</span>
                <span className="font-bold">{booking.farm?.city || 'غير محدد'}</span>
              </div>
            </div>
          </section>

          <section className="bg-gradient-to-br from-blue-50 to-cyan-50 p-5 rounded-xl border-2 border-blue-200">
            <h3 className="text-lg font-black text-[#2C2C2C] mb-4 flex items-center gap-2">
              <User className="h-5 w-5 text-blue-600" />
              بيانات المستثمر
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70">الاسم:</span>
                <span className="font-bold">{booking.investor_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                  <Phone className="h-3 w-3" />
                  الجوال:
                </span>
                <span className="font-mono font-bold">{booking.investor_mobile}</span>
              </div>
              {booking.investor_email && (
                <div className="flex justify-between">
                  <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                    <Mail className="h-3 w-3" />
                    البريد:
                  </span>
                  <span className="font-mono text-sm">{booking.investor_email}</span>
                </div>
              )}
            </div>
          </section>

          <section className="bg-gradient-to-br from-green-50 to-emerald-50 p-5 rounded-xl border-2 border-green-200">
            <h3 className="text-lg font-black text-[#2C2C2C] mb-4 flex items-center gap-2">
              <FileText className="h-5 w-5 text-green-600" />
              تفاصيل الحجز
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  تاريخ الحجز:
                </span>
                <span className="font-mono font-bold">
                  {new Date(booking.booking_date).toLocaleDateString('ar-SA')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                  <Trees className="h-3 w-3" />
                  عدد الأشجار:
                </span>
                <span className="font-black text-amber-600 text-lg">{booking.reserved_trees} شجرة</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  السعر الإجمالي:
                </span>
                <span className="font-black text-green-600 text-lg">
                  {booking.total_price.toLocaleString('ar-SA')} ريال
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70">المبلغ المدفوع:</span>
                <span className="font-bold text-blue-600">
                  {booking.payment_amount.toLocaleString('ar-SA')} ريال
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#2C2C2C]/70">حالة الدفع:</span>
                <span className={`px-3 py-1 rounded-lg text-sm font-bold ${
                  booking.payment_status === 'completed' ? 'bg-green-100 text-green-700' :
                  booking.payment_status === 'partial' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  {booking.payment_status === 'completed' ? 'مدفوع كاملاً' :
                   booking.payment_status === 'partial' ? 'دفع جزئي' :
                   'لم يُدفع'}
                </span>
              </div>
            </div>
          </section>

          <section className="bg-gradient-to-br from-purple-50 to-pink-50 p-5 rounded-xl border-2 border-purple-200">
            <h3 className="text-lg font-black text-[#2C2C2C] mb-4">المسار الزمني (Timeline)</h3>
            <div className="space-y-4">
              {timelineSteps.map((step, index) => {
                const StepIcon = step.icon;
                return (
                  <div key={index} className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      step.completed ? 'bg-green-500' : 'bg-gray-300'
                    }`}>
                      <StepIcon className={`h-5 w-5 ${step.completed ? 'text-white' : 'text-gray-600'}`} />
                    </div>
                    <div className="flex-1">
                      <p className={`font-bold ${step.completed ? 'text-green-700' : 'text-gray-500'}`}>
                        {step.label}
                      </p>
                      {step.date && (
                        <p className="text-xs text-gray-500 font-mono">
                          {new Date(step.date).toLocaleDateString('ar-SA')} • {new Date(step.date).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {booking.notes && (
            <section className="bg-gray-50 p-4 rounded-xl border-2 border-gray-200">
              <h3 className="text-sm font-bold text-[#2C2C2C] mb-2">ملاحظات:</h3>
              <p className="text-sm text-[#2C2C2C]/70">{booking.notes}</p>
            </section>
          )}

          <div className="space-y-3 pt-4 border-t-2 border-gray-200">
            {booking.booking_status === 'pending' && (
              <>
                <button
                  onClick={() => onApprove(booking)}
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-green-500 hover:bg-green-600 text-white rounded-xl font-black text-lg transition-all shadow-lg"
                >
                  <CheckCircle className="h-6 w-6" />
                  اعتماد الحجز
                </button>
                <button
                  onClick={() => onReject(booking)}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl font-bold transition-all"
                >
                  <XCircle className="h-5 w-5" />
                  رفض الحجز
                </button>
                <button
                  onClick={() => onFreeze(booking)}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-bold transition-all"
                >
                  <Pause className="h-5 w-5" />
                  تجميد مؤقت
                </button>
              </>
            )}

            {booking.booking_status === 'approved' && (
              <button
                onClick={() => onIssueCertificate(booking)}
                className="w-full flex items-center justify-center gap-2 px-6 py-5 bg-gradient-to-r from-[#C89B3C] to-[#D4B574] hover:from-[#B8894E] hover:to-[#C9A962] text-white rounded-xl font-black text-xl transition-all shadow-2xl"
              >
                <Award className="h-7 w-7" />
                نقل إلى التوثيق وإصدار الشهادة
              </button>
            )}

            {(booking.booking_status === 'pending' || booking.booking_status === 'rejected') && (
              <button
                onClick={() => onDelete(booking)}
                className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-xl font-bold transition-all"
              >
                <Trash2 className="h-5 w-5" />
                حذف نهائي
              </button>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
