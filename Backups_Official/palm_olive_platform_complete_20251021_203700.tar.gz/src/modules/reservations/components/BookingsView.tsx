import React, { useEffect, useState } from 'react';
import {
  Calendar,
  CheckCircle,
  Clock,
  XCircle,
  DollarSign,
  FileText,
  Award,
  AlertCircle
} from 'lucide-react';
import { Card3D } from '../../../components/ui/Card3D';
import { BackButton } from '../../../components/common/BackButton';
import { BookingsService, Booking } from '../bookingsService';
import { DocumentationService } from '../../documentation/documentationService';

interface BookingsViewProps {
  onBack?: () => void;
}

export function BookingsView({ onBack }: BookingsViewProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [bookingsData, statsData] = await Promise.all([
        BookingsService.getAll(),
        BookingsService.getStatistics()
      ]);
      setBookings(bookingsData);
      setStats(statsData);
    } catch (err) {
      console.error('Error loading bookings:', err);
      alert('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (booking: Booking) => {
    if (!confirm(`هل تريد الموافقة على الحجز ${booking.booking_code}؟`)) return;

    try {
      setActionLoading(true);
      await BookingsService.updateStatus(booking.id, 'approved', 'current-user-id');
      await loadData();
      alert('✅ تم الموافقة على الحجز بنجاح');
    } catch (error) {
      console.error('Error approving booking:', error);
      alert('حدث خطأ في الموافقة على الحجز');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async (booking: Booking) => {
    if (!confirm(`هل تريد رفض الحجز ${booking.booking_code}؟`)) return;

    try {
      setActionLoading(true);
      await BookingsService.updateStatus(booking.id, 'rejected');
      await loadData();
      alert('❌ تم رفض الحجز');
    } catch (error) {
      console.error('Error rejecting booking:', error);
      alert('حدث خطأ في رفض الحجز');
    } finally {
      setActionLoading(false);
    }
  };

  const handleIssueCertificate = async (booking: Booking) => {
    if (booking.booking_status !== 'approved') {
      alert('يجب الموافقة على الحجز أولاً');
      return;
    }

    if (!confirm(`هل تريد إصدار شهادة تملك للحجز ${booking.booking_code}؟\n\nسيتم:\n• نقل الحجز للتوثيق\n• إنشاء شهادة تملك\n• إرسال إشعار للمستثمر`)) {
      return;
    }

    try {
      setActionLoading(true);

      const documentationId = await BookingsService.migrateToDocumentation(
        booking.id,
        'current-user-id'
      );

      const documentation = await DocumentationService.getById(documentationId);

      if (documentation) {
        const qrUrl = await DocumentationService.generateCertificateQR(
          documentation.certificate_code,
          documentation.verification_token
        );

        await DocumentationService.updateCertificatePDF(
          documentationId,
          `https://example.com/certificates/${documentation.certificate_code}.pdf`,
          qrUrl
        );

        alert(
          `✅ تم إصدار الشهادة بنجاح!\n\n` +
          `🔢 رقم الحجز: ${booking.booking_code}\n` +
          `📜 رقم الشهادة: ${documentation.certificate_code}\n` +
          `👤 المستثمر: ${booking.investor_name}\n` +
          `🌳 عدد الأشجار: ${booking.reserved_trees}\n\n` +
          `تم نقل السجل إلى إدارة التوثيق`
        );

        await loadData();
      }
    } catch (error: any) {
      console.error('Error issuing certificate:', error);
      alert('حدث خطأ في إصدار الشهادة: ' + (error.message || 'خطأ غير معروف'));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#F9F8F6]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#C89B3C] mx-auto mb-4"></div>
          <p className="text-[#2C2C2C]/70">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F8F6] p-8" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {onBack && (
          <div className="mb-6">
            <BackButton onBack={onBack} />
          </div>
        )}

        <div className="mb-8">
          <h1 className="text-4xl font-black text-[#C89B3C] mb-2 flex items-center gap-3">
            <Calendar className="h-10 w-10" />
            إدارة الحجوزات الذكية
          </h1>
          <p className="text-[#2C2C2C]/70 text-lg">
            متابعة الحجوزات • الموافقات • إصدار الشهادات
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card3D>
            <div className="p-6 bg-gradient-to-br from-blue-50 to-blue-100/50">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Calendar className="h-6 w-6 text-white" />
                </div>
                <span className="text-3xl font-black text-blue-600">
                  {stats?.total || 0}
                </span>
              </div>
              <h3 className="text-sm font-bold text-blue-900">إجمالي الحجوزات</h3>
            </div>
          </Card3D>

          <Card3D>
            <div className="p-6 bg-gradient-to-br from-yellow-50 to-yellow-100/50">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-yellow-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <span className="text-3xl font-black text-yellow-600">
                  {stats?.pending || 0}
                </span>
              </div>
              <h3 className="text-sm font-bold text-yellow-900">قيد الانتظار</h3>
            </div>
          </Card3D>

          <Card3D>
            <div className="p-6 bg-gradient-to-br from-green-50 to-green-100/50">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center shadow-lg">
                  <CheckCircle className="h-6 w-6 text-white" />
                </div>
                <span className="text-3xl font-black text-green-600">
                  {stats?.approved || 0}
                </span>
              </div>
              <h3 className="text-sm font-bold text-green-900">موافق عليها</h3>
            </div>
          </Card3D>

          <Card3D>
            <div className="p-6 bg-gradient-to-br from-purple-50 to-purple-100/50">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Award className="h-6 w-6 text-white" />
                </div>
                <span className="text-3xl font-black text-purple-600">
                  {stats?.documented || 0}
                </span>
              </div>
              <h3 className="text-sm font-bold text-purple-900">موثّقة</h3>
            </div>
          </Card3D>
        </div>

        {bookings.length === 0 ? (
          <div className="text-center py-12">
            <AlertCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-600 mb-2">لا توجد حجوزات</h3>
            <p className="text-gray-500">سيتم عرض الحجوزات هنا عند إضافتها</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {bookings.map((booking) => (
              <Card3D key={booking.id}>
                <div className="p-6 bg-white">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-mono text-sm font-black text-[#C89B3C]">
                          {booking.booking_code}
                        </span>
                        <span className={`px-3 py-1 rounded-lg text-xs font-bold ${BookingsService.getStatusColor(booking.booking_status)}`}>
                          {BookingsService.getStatusLabel(booking.booking_status)}
                        </span>
                      </div>
                      <h3 className="text-lg font-black text-[#2C2C2C] mb-1">
                        {booking.farm?.name_ar || 'مزرعة غير معروفة'}
                      </h3>
                      <p className="text-sm text-[#2C2C2C]/60">
                        {booking.farm?.farm_code || 'لا يوجد'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3 mb-4 border-t border-b border-gray-100 py-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#2C2C2C]/70">المستثمر:</span>
                      <span className="font-bold text-[#2C2C2C]">{booking.investor_name}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#2C2C2C]/70">الجوال:</span>
                      <span className="font-mono font-bold text-[#2C2C2C]">{booking.investor_mobile}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#2C2C2C]/70">عدد الأشجار:</span>
                      <span className="font-black text-amber-600">{booking.reserved_trees} شجرة</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#2C2C2C]/70">السعر الإجمالي:</span>
                      <span className="font-black text-green-600">
                        {BookingsService.formatPrice(booking.total_price)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#2C2C2C]/70">حالة الدفع:</span>
                      <span className={`px-2 py-1 rounded text-xs font-bold ${BookingsService.getPaymentStatusColor(booking.payment_status)}`}>
                        {BookingsService.getPaymentStatusLabel(booking.payment_status)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {booking.booking_status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleApprove(booking)}
                          disabled={actionLoading}
                          className="flex-1 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-bold text-sm transition-colors disabled:opacity-50"
                        >
                          <CheckCircle className="h-4 w-4 inline mr-2" />
                          موافقة
                        </button>
                        <button
                          onClick={() => handleReject(booking)}
                          disabled={actionLoading}
                          className="flex-1 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-bold text-sm transition-colors disabled:opacity-50"
                        >
                          <XCircle className="h-4 w-4 inline mr-2" />
                          رفض
                        </button>
                      </>
                    )}

                    {booking.booking_status === 'approved' && (
                      <button
                        onClick={() => handleIssueCertificate(booking)}
                        disabled={actionLoading}
                        className="w-full bg-gradient-to-r from-[#C89B3C] to-[#D4B574] hover:from-[#B8894E] hover:to-[#C9A962] text-white px-4 py-3 rounded-lg font-black text-sm transition-all shadow-lg disabled:opacity-50"
                      >
                        <Award className="h-5 w-5 inline mr-2" />
                        إصدار شهادة التملك
                      </button>
                    )}

                    {booking.booking_status === 'documented' && (
                      <div className="w-full bg-purple-100 text-purple-700 px-4 py-3 rounded-lg font-bold text-sm text-center border-2 border-purple-300">
                        <FileText className="h-5 w-5 inline mr-2" />
                        تم التوثيق ✅
                      </div>
                    )}

                    {booking.booking_status === 'rejected' && (
                      <div className="w-full bg-red-100 text-red-700 px-4 py-3 rounded-lg font-bold text-sm text-center border-2 border-red-300">
                        مرفوض ❌
                      </div>
                    )}
                  </div>
                </div>
              </Card3D>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
