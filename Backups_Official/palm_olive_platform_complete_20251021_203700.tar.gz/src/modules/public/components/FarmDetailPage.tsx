import { useState, useEffect } from 'react';
import { ArrowRight, MapPin, Trees, Loader } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';
import { FarmDetailService, FarmDetail } from '../services/farmDetailService';

interface FarmDetailPageProps {
  farmId: string;
  onBack: () => void;
  onStartOwnership: () => void;
}

export function FarmDetailPage({ farmId, onBack, onStartOwnership }: FarmDetailPageProps) {
  const [farm, setFarm] = useState<FarmDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    loadFarmData();
  }, [farmId]);

  const loadFarmData = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await FarmDetailService.getFarmById(farmId);

      if (!data) {
        setError('لم يتم العثور على المزرعة');
        return;
      }

      setFarm(data);
    } catch (err) {
      console.error('Error loading farm data:', err);
      setError('حدث خطأ أثناء تحميل بيانات المزرعة');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: brandGradients.beige }}
        dir="rtl"
      >
        <div className="text-center">
          <Loader
            className="h-12 w-12 animate-spin mx-auto mb-4"
            style={{ color: brandColors.primary.gold }}
          />
          <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
            جاري تحميل بيانات المزرعة...
          </p>
        </div>
      </div>
    );
  }

  if (error || !farm) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-6"
        style={{ background: brandGradients.beige }}
        dir="rtl"
      >
        <div className="text-center">
          <p className="text-2xl font-bold mb-4" style={{ color: brandColors.text.primary }}>
            {error || 'لم يتم العثور على المزرعة'}
          </p>
          <button
            onClick={onBack}
            className="px-8 py-3 rounded-lg font-bold text-white transition-all"
            style={{ background: brandGradients.gold }}
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  const isOlive = farm.farm_type?.toLowerCase().includes('زيتون');
  const isPalm = farm.farm_type?.toLowerCase().includes('نخيل');
  const isMixed = farm.farm_type?.toLowerCase().includes('مختلط');

  const completionPercentage = farm.total_trees > 0
    ? Math.round(((farm.total_trees - farm.available_trees) / farm.total_trees) * 100)
    : 0;

  const isAvailable = completionPercentage < 100;

  return (
    <div
      className="min-h-screen"
      style={{ background: brandGradients.beige }}
      dir="rtl"
    >
      <div
        className="sticky top-0 z-50 backdrop-blur-md border-b"
        style={{
          background: 'rgba(245, 240, 230, 0.9)',
          borderColor: brandColors.primary.gold + '20',
        }}
      >
        <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-bold transition-all hover:scale-105"
            style={{
              color: brandColors.primary.gold,
              background: brandColors.primary.gold + '10',
            }}
          >
            <ArrowRight className="w-5 h-5" />
            <span>العودة</span>
          </button>

          <div className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full animate-pulse"
              style={{ background: brandGradients.gold }}
            />
            <span className="font-bold" style={{ color: brandColors.primary.gold }}>
              منصة النخيل والزيتون
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-6 py-8">
        <div className="relative rounded-3xl overflow-hidden mb-8 shadow-2xl">
          <div
            className="absolute top-6 right-6 z-10 px-6 py-3 rounded-full font-bold text-white text-lg backdrop-blur-md"
            style={{
              background: isAvailable
                ? 'linear-gradient(135deg, #4ade80 0%, #22c55e 100%)'
                : 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
              boxShadow: '0 8px 32px rgba(0,0,0,0.2)',
            }}
          >
            {isAvailable ? '🟢 جاهزة للتملك' : '🔴 مكتملة'}
          </div>

          {farm.aerial_map_url ? (
            <img
              src={farm.aerial_map_url}
              alt={farm.name_ar}
              className="w-full h-[500px] object-cover"
            />
          ) : (
            <div
              className="w-full h-[500px] flex items-center justify-center"
              style={{ background: brandGradients.olive }}
            >
              <Trees className="w-32 h-32 opacity-30" style={{ color: 'white' }} />
            </div>
          )}

          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'linear-gradient(90deg, transparent 0%, rgba(212,175,55,0.1) 50%, transparent 100%)',
              animation: 'shimmer 3s infinite',
            }}
          />
        </div>

        <div
          className="rounded-3xl p-8 mb-8 shadow-xl"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(245,240,230,0.95) 100%)',
            border: `2px solid ${brandColors.primary.gold}30`,
          }}
        >
          <h1
            className="text-5xl font-black mb-6"
            style={{
              background: brandGradients.gold,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            {farm.name_ar}
          </h1>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: brandGradients.gold }}
              >
                <Trees className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm opacity-70" style={{ color: brandColors.text.secondary }}>
                  نوع المزرعة
                </p>
                <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
                  {farm.farm_type || 'غير محدد'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: brandGradients.gold }}
              >
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm opacity-70" style={{ color: brandColors.text.secondary }}>
                  الموقع
                </p>
                <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
                  {farm.city} - {farm.region}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: brandGradients.gold }}
              >
                <span className="text-xl font-black text-white">م²</span>
              </div>
              <div>
                <p className="text-sm opacity-70" style={{ color: brandColors.text.secondary }}>
                  المساحة الكلية
                </p>
                <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
                  {farm.total_area?.toLocaleString('ar-SA') || '0'} م²
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: brandGradients.gold }}
              >
                <span className="text-xl font-black text-white">ر.س</span>
              </div>
              <div>
                <p className="text-sm opacity-70" style={{ color: brandColors.text.secondary }}>
                  السعر للشجرة
                </p>
                <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
                  {farm.price_per_tree?.toLocaleString('ar-SA') || '0'} ر.س
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div
              className="p-6 rounded-2xl"
              style={{ background: brandColors.primary.gold + '10' }}
            >
              <p className="text-sm opacity-70 mb-2" style={{ color: brandColors.text.secondary }}>
                عدد الأشجار الكلي
              </p>
              <p className="text-4xl font-black" style={{ color: brandColors.primary.gold }}>
                {farm.total_trees?.toLocaleString('ar-SA') || '0'}
              </p>
            </div>

            <div
              className="p-6 rounded-2xl"
              style={{ background: brandColors.accent.olive + '10' }}
            >
              <p className="text-sm opacity-70 mb-2" style={{ color: brandColors.text.secondary }}>
                المتاح للتملك حالياً
              </p>
              <p className="text-4xl font-black" style={{ color: brandColors.accent.olive }}>
                {farm.available_trees?.toLocaleString('ar-SA') || '0'}
              </p>
            </div>
          </div>

          {farm.description_ar && (
            <div
              className="p-6 rounded-2xl"
              style={{ background: brandColors.background.beige }}
            >
              <p className="text-lg leading-relaxed" style={{ color: brandColors.text.secondary }}>
                {farm.description_ar}
              </p>
            </div>
          )}
        </div>

        <div className="text-center">
          <button
            onClick={onStartOwnership}
            disabled={!isAvailable}
            className="group relative px-16 py-6 rounded-2xl font-black text-2xl text-white transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              background: isAvailable ? brandGradients.gold : brandGradients.beige,
              boxShadow: '0 20px 60px rgba(212,175,55,0.4)',
              transform: 'perspective(1000px) rotateX(0deg)',
            }}
          >
            <div className="relative z-10 flex items-center justify-center gap-3">
              {isOlive && <span>🫒</span>}
              {isPalm && <span>🌴</span>}
              {isMixed && <span>🌳</span>}
              <span>
                {isOlive ? 'تقدّم لتملك شجرة زيتون' : 'تقدّم لتملك نخلة'}
              </span>
            </div>

            {isAvailable && (
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"
                style={{
                  background: 'linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 100%)',
                }}
              />
            )}

            {isAvailable && (
              <div
                className="absolute inset-0 rounded-2xl animate-pulse"
                style={{
                  boxShadow: '0 0 30px rgba(212,175,55,0.6)',
                }}
              />
            )}
          </button>

          {!isAvailable && (
            <p className="mt-4 text-lg font-bold" style={{ color: brandColors.text.secondary }}>
              المزرعة مكتملة - جميع الأشجار محجوزة
            </p>
          )}
        </div>
      </div>

      <style>{`
        @keyframes shimmer {
          0%, 100% { transform: translateX(-100%); }
          50% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
}
