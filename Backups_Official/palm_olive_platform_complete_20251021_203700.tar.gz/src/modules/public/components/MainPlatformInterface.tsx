import { useState, useEffect } from 'react';
import { Loader } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';
import { PublicFarm } from '../types/farm.types';
import { PublicFarmService } from '../services/publicFarmService';
import { FarmDetailService } from '../services/farmDetailService';
import { PremiumHeader } from './PremiumHeader';
import { StockTicker } from './StockTicker';
import { FarmCard3D } from './FarmCard3D';
import { FixedBottomBar } from './FixedBottomBar';
import { ConceptIntroModal } from './ConceptIntroModal';
import { FarmDetailPage } from './FarmDetailPage';
import { OwnershipPage } from './OwnershipPage';
import { ConfirmationPage } from './ConfirmationPage';
import { InvestorRouter } from '../../investor/components/InvestorRouter';

type ViewMode = 'home' | 'farmDetail' | 'ownership' | 'confirmation' | 'investor';

interface MainPlatformInterfaceProps {
  onFarmSelect?: (barcode: string) => void;
  onPreviewSelect?: (barcode: string) => void;
  onAdminLogin?: () => void;
}

export function MainPlatformInterface({
  onFarmSelect,
  onPreviewSelect,
  onAdminLogin,
}: MainPlatformInterfaceProps) {
  const [farms, setFarms] = useState<PublicFarm[]>([]);
  const [loading, setLoading] = useState(true);
  const [showConceptModal, setShowConceptModal] = useState(false);
  const [currentView, setCurrentView] = useState<ViewMode>('home');
  const [selectedFarm, setSelectedFarm] = useState<PublicFarm | null>(null);
  const [bookingData, setBookingData] = useState<any>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const farmsData = await PublicFarmService.getAllFarms();
      setFarms(farmsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFarmClick = (farm: PublicFarm) => {
    setSelectedFarm(farm);
    setCurrentView('farmDetail');
  };

  const handleStartOwnership = () => {
    setCurrentView('ownership');
  };

  const handleOwnershipConfirm = async (data: any) => {
    try {
      await FarmDetailService.createReservation({
        farm_id: data.farmId,
        investor_name: data.investorData.fullName,
        investor_phone: data.investorData.phone,
        varieties: data.varieties.map((v: any) => ({
          variety_id: v.id,
          tree_count: v.selectedQuantity,
          price_per_tree: v.price_per_tree
        })),
        total_trees: data.totalQuantity,
        total_amount: data.totalPrice
      });

      setBookingData(data);
      setCurrentView('confirmation');
    } catch (error) {
      console.error('Error creating reservation:', error);
      alert('حدث خطأ أثناء إنشاء الحجز. الرجاء المحاولة مرة أخرى.');
    }
  };

  const handleGoHome = () => {
    setCurrentView('home');
    setSelectedFarm(null);
    setBookingData(null);
  };

  const handleGoToInvestorPanel = () => {
    setCurrentView('investor');
  };

  const handleContactSales = () => {
    window.open('https://wa.me/966500000000', '_blank');
  };

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: brandGradients.beige }}
      >
        <div className="text-center">
          <Loader
            className="h-12 w-12 animate-spin mx-auto mb-4"
            style={{ color: brandColors.primary.gold }}
          />
          <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
            جاري التحميل...
          </p>
        </div>
      </div>
    );
  }

  if (currentView === 'investor') {
    return <InvestorRouter onBack={handleGoHome} />;
  }

  if (currentView === 'farmDetail' && selectedFarm) {
    return (
      <FarmDetailPage
        farmId={selectedFarm.id}
        onBack={handleGoHome}
        onStartOwnership={handleStartOwnership}
      />
    );
  }

  if (currentView === 'ownership' && selectedFarm) {
    return (
      <OwnershipPage
        farmId={selectedFarm.id}
        farmName={selectedFarm.farm_name}
        farmType={selectedFarm.tree_type}
        onBack={() => setCurrentView('farmDetail')}
        onConfirm={handleOwnershipConfirm}
      />
    );
  }

  if (currentView === 'confirmation' && selectedFarm && bookingData) {
    return (
      <ConfirmationPage
        farmName={selectedFarm.farm_name}
        farmType={selectedFarm.tree_type}
        totalQuantity={bookingData.totalQuantity}
        totalPrice={bookingData.totalPrice}
        investorPhone={bookingData.investorData.phone}
        onGoHome={handleGoHome}
        onGoToInvestorPanel={handleGoToInvestorPanel}
        onContactSales={handleContactSales}
      />
    );
  }

  // الصفحة الرئيسية
  return (
    <div className="min-h-screen" dir="rtl" style={{ background: brandGradients.beige }}>
      <PremiumHeader
        onAdminLogin={onAdminLogin}
        onInvestorLogin={handleGoToInvestorPanel}
      />
      <StockTicker />

      <div className="max-w-[1400px] mx-auto px-6 pt-8 pb-32">
        <div className="mb-8 text-center">
          <h1
            className="text-6xl font-black mb-4"
            style={{
              background: brandGradients.gold,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            مزارع النخيل والزيتون المميزة
          </h1>
          <p className="text-xl" style={{ color: brandColors.text.secondary }}>
            استثمر في مستقبل الزراعة الذكية
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {farms.map((farm) => (
            <FarmCard3D
              key={farm.barcode}
              farm={farm}
              onOwn={() => handleFarmClick(farm)}
            />
          ))}
        </div>
      </div>

      <FixedBottomBar onIntroClick={() => setShowConceptModal(true)} />

      {showConceptModal && (
        <ConceptIntroModal onClose={() => setShowConceptModal(false)} />
      )}
    </div>
  );
}
