import { useState, useEffect } from 'react';
import { LogIn, Menu, X, User } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';

interface PremiumHeaderProps {
  onAdminLogin?: () => void;
  onInvestorLogin?: () => void;
}

export function PremiumHeader({ onAdminLogin, onInvestorLogin }: PremiumHeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'الرئيسية', href: '#home' },
    { label: 'عن المنصة', href: '#about' },
    { label: 'تواصل معنا', href: '#contact' },
  ];

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: isScrolled
          ? 'rgba(46, 42, 38, 0.95)'
          : 'rgba(255, 255, 255, 0.6)',
        backdropFilter: 'blur(20px)',
        boxShadow: isScrolled
          ? '0 8px 32px rgba(0, 0, 0, 0.1)'
          : '0 2px 20px rgba(212, 175, 55, 0.1)',
      }}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="text-3xl font-black"
              style={{
                background: isScrolled ? brandGradients.gold : brandGradients.gold,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                textShadow: '0 2px 10px rgba(212, 175, 55, 0.3)',
                filter: 'drop-shadow(0 2px 4px rgba(212, 175, 55, 0.2))',
              }}
            >
              🌴 النخلة والزيتون
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            {menuItems.map((item, index) => (
              <a
                key={index}
                href={item.href}
                className="font-bold transition-all duration-300 hover:scale-110"
                style={{
                  color: isScrolled ? '#D4AF37' : brandColors.text.primary,
                  textShadow: isScrolled ? '0 0 10px rgba(212, 175, 55, 0.5)' : 'none',
                }}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <button
              onClick={onInvestorLogin}
              className="hidden md:flex items-center gap-2 px-6 py-3 rounded-2xl font-black text-white transition-all duration-300 hover:scale-105 investor-login-btn"
              style={{
                background: 'linear-gradient(135deg, #3D5B4B 0%, #5A8672 50%, #D4AF37 100%)',
                boxShadow: '0 4px 30px rgba(212, 175, 55, 0.5)',
              }}
            >
              <User className="h-5 w-5" />
              <span>لوحة المستثمر</span>
            </button>

            <button
              onClick={onAdminLogin}
              className="hidden md:flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-white transition-all duration-300 hover:scale-105"
              style={{
                background: brandGradients.gold,
                boxShadow: '0 4px 20px rgba(212, 175, 55, 0.4)',
              }}
            >
              <LogIn className="h-4 w-4" />
              <span>دخول الإدارة</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2"
              style={{ color: isScrolled ? '#D4AF37' : brandColors.text.primary }}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div
            className="md:hidden mt-4 py-4 rounded-xl"
            style={{
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
            }}
          >
            <nav className="flex flex-col gap-3">
              {menuItems.map((item, index) => (
                <a
                  key={index}
                  href={item.href}
                  className="px-4 py-2 font-bold transition-all duration-300"
                  style={{ color: brandColors.text.primary }}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <button
                onClick={() => {
                  onInvestorLogin?.();
                  setMobileMenuOpen(false);
                }}
                className="mx-4 flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-white mb-2"
                style={{ background: 'linear-gradient(135deg, #3D5B4B 0%, #5A8672 50%, #D4AF37 100%)' }}
              >
                <User className="h-4 w-4" />
                <span>لوحة المستثمر</span>
              </button>
              <button
                onClick={() => {
                  onAdminLogin?.();
                  setMobileMenuOpen(false);
                }}
                className="mx-4 flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-white"
                style={{ background: brandGradients.gold }}
              >
                <LogIn className="h-4 w-4" />
                <span>دخول لوحة الإدارة</span>
              </button>
            </nav>
          </div>
        )}
      </div>

      <style>{`
        @keyframes glow-pulse {
          0%, 100% {
            box-shadow: 0 4px 30px rgba(212, 175, 55, 0.5), 0 0 20px rgba(212, 175, 55, 0.3);
          }
          50% {
            box-shadow: 0 4px 40px rgba(212, 175, 55, 0.8), 0 0 30px rgba(212, 175, 55, 0.5);
          }
        }

        .investor-login-btn {
          animation: glow-pulse 4s ease-in-out infinite;
          position: relative;
          overflow: hidden;
        }

        .investor-login-btn::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
          transition: left 0.5s;
        }

        .investor-login-btn:hover::before {
          left: 100%;
        }
      `}</style>
    </header>
  );
}
