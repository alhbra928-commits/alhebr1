import { useState, useEffect } from 'react';
import { ArrowRight, Plus, Minus, AlertCircle, CheckCircle2, Loader } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';
import { FarmDetailService, FarmVariety } from '../services/farmDetailService';

interface SelectedVariety extends FarmVariety {
  selectedQuantity: number;
  totalPrice: number;
}

interface OwnershipPageProps {
  farmId: string;
  farmName: string;
  farmType: string;
  onBack: () => void;
  onConfirm: (data: any) => void;
}

export function OwnershipPage({ farmId, farmName, farmType, onBack, onConfirm }: OwnershipPageProps) {
  const [varieties, setVarieties] = useState<SelectedVariety[]>([]);
  const [investorData, setInvestorData] = useState({
    fullName: '',
    phone: '+966'
  });
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');

  const isOlive = farmType?.toLowerCase().includes('زيتون');

  useEffect(() => {
    loadVarieties();
  }, [farmId]);

  const loadVarieties = async () => {
    try {
      setLoading(true);
      setError('');

      const farmData = await FarmDetailService.getFarmById(farmId);

      if (!farmData || !farmData.varieties || farmData.varieties.length === 0) {
        setError('لا توجد أصناف متاحة لهذه المزرعة');
        return;
      }

      const selectedVarieties: SelectedVariety[] = farmData.varieties.map(v => ({
        ...v,
        selectedQuantity: 0,
        totalPrice: 0
      }));

      setVarieties(selectedVarieties);
    } catch (err) {
      console.error('Error loading varieties:', err);
      setError('حدث خطأ أثناء تحميل الأصناف');
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = (varietyId: string, newQuantity: number) => {
    setVarieties(prev => prev.map(v => {
      if (v.id !== varietyId) return v;

      const safeQuantity = Math.max(0, Math.min(newQuantity, v.max_booking_per_investor, v.available_quantity));
      return {
        ...v,
        selectedQuantity: safeQuantity,
        totalPrice: safeQuantity * v.price_per_tree
      };
    }));
  };

  const handleQuantityChange = (varietyId: string, value: string) => {
    const numValue = parseInt(value) || 0;
    updateQuantity(varietyId, numValue);
  };

  const incrementQuantity = (varietyId: string) => {
    const variety = varieties.find(v => v.id === varietyId);
    if (variety) {
      updateQuantity(varietyId, variety.selectedQuantity + 1);
    }
  };

  const decrementQuantity = (varietyId: string) => {
    const variety = varieties.find(v => v.id === varietyId);
    if (variety) {
      updateQuantity(varietyId, variety.selectedQuantity - 1);
    }
  };

  const totalQuantity = varieties.reduce((sum, v) => sum + v.selectedQuantity, 0);
  const totalPrice = varieties.reduce((sum, v) => sum + v.totalPrice, 0);

  const validateForm = (): boolean => {
    const newErrors: {[key: string]: string} = {};

    if (!investorData.fullName.trim()) {
      newErrors.fullName = 'الرجاء إدخال الاسم الكامل';
    }

    if (!investorData.phone || investorData.phone === '+966' || investorData.phone.length < 13) {
      newErrors.phone = 'الرجاء إدخال رقم جوال صحيح';
    }

    if (totalQuantity === 0) {
      newErrors.quantity = 'الرجاء تحديد عدد الأشجار المراد تملكها';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleConfirm = () => {
    if (!validateForm()) return;

    const selectedVarieties = varieties.filter(v => v.selectedQuantity > 0);

    onConfirm({
      farmId,
      investorData,
      varieties: selectedVarieties,
      totalQuantity,
      totalPrice
    });
  };

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: brandGradients.beige }}
        dir="rtl"
      >
        <div className="text-center">
          <Loader
            className="h-12 w-12 animate-spin mx-auto mb-4"
            style={{ color: brandColors.primary.gold }}
          />
          <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
            جاري تحميل الأصناف...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-6"
        style={{ background: brandGradients.beige }}
        dir="rtl"
      >
        <div className="text-center">
          <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: brandColors.error }} />
          <p className="text-2xl font-bold mb-4" style={{ color: brandColors.text.primary }}>
            {error}
          </p>
          <button
            onClick={onBack}
            className="px-8 py-3 rounded-lg font-bold text-white transition-all"
            style={{ background: brandGradients.gold }}
          >
            العودة
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen pb-32"
      style={{ background: brandGradients.beige }}
      dir="rtl"
    >
      <div
        className="sticky top-0 z-50 backdrop-blur-md border-b"
        style={{
          background: 'rgba(245, 240, 230, 0.9)',
          borderColor: brandColors.primary.gold + '20',
        }}
      >
        <div className="max-w-[1200px] mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-bold transition-all hover:scale-105"
            style={{
              color: brandColors.primary.gold,
              background: brandColors.primary.gold + '10',
            }}
          >
            <ArrowRight className="w-5 h-5" />
            <span>العودة</span>
          </button>

          <h1 className="text-2xl font-black" style={{ color: brandColors.primary.gold }}>
            تملك الأشجار
          </h1>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div
          className="rounded-3xl p-8 mb-8 text-center"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(245,240,230,0.95) 100%)',
            border: `2px solid ${brandColors.primary.gold}30`,
          }}
        >
          <h2 className="text-3xl font-black mb-2" style={{ color: brandColors.text.primary }}>
            {farmName}
          </h2>
          <p className="text-lg" style={{ color: brandColors.text.secondary }}>
            اختر الأصناف والكميات المراد تملكها
          </p>
        </div>

        <div className="space-y-6 mb-8">
          {varieties.map((variety) => {
            const maxAllowed = Math.min(variety.max_booking_per_investor, variety.available_quantity);
            const isAtMax = variety.selectedQuantity >= maxAllowed;

            return (
              <div
                key={variety.id}
                className="rounded-2xl p-6 transition-all duration-300"
                style={{
                  background: variety.selectedQuantity > 0
                    ? 'linear-gradient(135deg, rgba(212,175,55,0.1) 0%, rgba(255,255,255,0.95) 100%)'
                    : 'rgba(255,255,255,0.95)',
                  border: variety.selectedQuantity > 0
                    ? `3px solid ${brandColors.primary.gold}`
                    : `2px solid ${brandColors.primary.gold}20`,
                  boxShadow: variety.selectedQuantity > 0
                    ? '0 10px 40px rgba(212,175,55,0.3)'
                    : '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-2" style={{ color: brandColors.text.primary }}>
                      {variety.variety_name}
                    </h3>
                    <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                      {variety.description_ar || variety.variety_name_en}
                    </p>
                    <div className="flex items-center gap-4">
                      <span className="text-xl font-bold" style={{ color: brandColors.primary.gold }}>
                        {variety.price_per_tree.toLocaleString('ar-SA')} ر.س / شجرة
                      </span>
                      <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                        متاح للحجز: {variety.available_quantity.toLocaleString('ar-SA')}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <button
                    onClick={() => decrementQuantity(variety.id)}
                    disabled={variety.selectedQuantity === 0}
                    className="w-12 h-12 rounded-xl font-bold text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:scale-110"
                    style={{ background: brandGradients.gold }}
                  >
                    <Minus className="w-6 h-6 mx-auto" />
                  </button>

                  <input
                    type="number"
                    value={variety.selectedQuantity || ''}
                    onChange={(e) => handleQuantityChange(variety.id, e.target.value)}
                    placeholder="0"
                    min="0"
                    max={maxAllowed}
                    className="flex-1 text-center text-2xl font-black px-4 py-3 rounded-xl border-2 outline-none transition-all"
                    style={{
                      borderColor: variety.selectedQuantity > 0 ? brandColors.primary.gold : brandColors.primary.gold + '30',
                      color: brandColors.text.primary,
                      background: 'white',
                    }}
                  />

                  <button
                    onClick={() => incrementQuantity(variety.id)}
                    disabled={isAtMax}
                    className="w-12 h-12 rounded-xl font-bold text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:scale-110"
                    style={{ background: brandGradients.gold }}
                  >
                    <Plus className="w-6 h-6 mx-auto" />
                  </button>
                </div>

                {variety.selectedQuantity > 0 && (
                  <div
                    className="mt-4 p-4 rounded-xl text-center"
                    style={{ background: brandColors.primary.gold + '10' }}
                  >
                    <p className="text-xl font-bold" style={{ color: brandColors.primary.gold }}>
                      {variety.selectedQuantity.toLocaleString('ar-SA')} × {variety.price_per_tree.toLocaleString('ar-SA')} ر.س = {variety.totalPrice.toLocaleString('ar-SA')} ر.س
                    </p>
                  </div>
                )}

                {isAtMax && variety.selectedQuantity > 0 && (
                  <div
                    className="mt-4 p-4 rounded-xl flex items-center gap-3"
                    style={{ background: brandColors.primary.gold + '15' }}
                  >
                    <AlertCircle className="w-5 h-5 flex-shrink-0" style={{ color: brandColors.primary.gold }} />
                    <p className="text-sm font-bold" style={{ color: brandColors.primary.gold }}>
                      {isOlive ? '🫒' : '🌴'} الحد الأعلى للحجز من هذا النوع هو {maxAllowed.toLocaleString('ar-SA')} شجرة
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {errors.quantity && (
          <div
            className="rounded-xl p-4 mb-6 flex items-center gap-3"
            style={{ background: brandColors.error + '10' }}
          >
            <AlertCircle className="w-5 h-5" style={{ color: brandColors.error }} />
            <p className="font-bold" style={{ color: brandColors.error }}>
              {errors.quantity}
            </p>
          </div>
        )}

        <div
          className="rounded-3xl p-8 mb-8"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(245,240,230,0.95) 100%)',
            border: `2px solid ${brandColors.primary.gold}30`,
          }}
        >
          <h3 className="text-2xl font-black mb-6" style={{ color: brandColors.text.primary }}>
            بيانات المستثمر
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: brandColors.text.secondary }}>
                الاسم الكامل
              </label>
              <input
                type="text"
                value={investorData.fullName}
                onChange={(e) => setInvestorData({ ...investorData, fullName: e.target.value })}
                placeholder="أدخل اسمك الكامل"
                className="w-full px-6 py-4 rounded-xl border-2 outline-none transition-all text-lg"
                style={{
                  borderColor: errors.fullName ? brandColors.error : brandColors.primary.gold + '30',
                  color: brandColors.text.primary,
                  background: 'white',
                }}
              />
              {errors.fullName && (
                <p className="mt-2 text-sm font-bold" style={{ color: brandColors.error }}>
                  {errors.fullName}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: brandColors.text.secondary }}>
                رقم الجوال
              </label>
              <input
                type="tel"
                value={investorData.phone}
                onChange={(e) => setInvestorData({ ...investorData, phone: e.target.value })}
                placeholder="+966 5xxxxxxxx"
                className="w-full px-6 py-4 rounded-xl border-2 outline-none transition-all text-lg"
                style={{
                  borderColor: errors.phone ? brandColors.error : brandColors.primary.gold + '30',
                  color: brandColors.text.primary,
                  background: 'white',
                }}
              />
              {errors.phone && (
                <p className="mt-2 text-sm font-bold" style={{ color: brandColors.error }}>
                  {errors.phone}
                </p>
              )}
              <p className="mt-2 text-sm" style={{ color: brandColors.text.secondary }}>
                سيُستخدم رقم الجوال كوسيلة دخولك إلى لوحة المستثمر
              </p>
            </div>
          </div>
        </div>
      </div>

      <div
        className="fixed bottom-0 left-0 right-0 z-50 backdrop-blur-md border-t"
        style={{
          background: 'rgba(245, 240, 230, 0.95)',
          borderColor: brandColors.primary.gold + '30',
        }}
      >
        <div className="max-w-[1200px] mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm mb-1" style={{ color: brandColors.text.secondary }}>
                إجمالي قيمة التملك
              </p>
              <p
                className="text-4xl font-black animate-pulse"
                style={{
                  background: brandGradients.gold,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                {totalPrice.toLocaleString('ar-SA')} ر.س
              </p>
            </div>

            <div className="text-left">
              <p className="text-sm mb-1" style={{ color: brandColors.text.secondary }}>
                عدد الأشجار
              </p>
              <p className="text-4xl font-black" style={{ color: brandColors.accent.olive }}>
                {totalQuantity.toLocaleString('ar-SA')}
              </p>
            </div>
          </div>

          <button
            onClick={handleConfirm}
            disabled={totalQuantity === 0}
            className="w-full py-5 rounded-2xl font-black text-2xl text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.02]"
            style={{
              background: totalQuantity > 0 ? brandGradients.gold : brandGradients.beige,
              boxShadow: totalQuantity > 0 ? '0 10px 40px rgba(212,175,55,0.4)' : 'none',
            }}
          >
            <div className="flex items-center justify-center gap-3">
              <CheckCircle2 className="w-8 h-8" />
              <span>تأكيد الحجز المؤقت</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
