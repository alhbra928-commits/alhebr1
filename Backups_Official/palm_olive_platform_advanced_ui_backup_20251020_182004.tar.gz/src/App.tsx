import { useState } from 'react';
import { EnhancedDashboard } from './modules/dashboard/EnhancedDashboard';
import { OwnersView } from './modules/owners/components/OwnersView';
import { FarmsView } from './modules/farms/components/FarmsView';
import { AdvancedBookingsView } from './modules/reservations/components/AdvancedBookingsView';
import { AdvancedInvestorsView } from './modules/investors/components/AdvancedInvestorsView';
import { WalletsView } from './modules/wallets/components/WalletsView';
import { FarmFinanceDashboard } from './modules/finance/components/FarmFinanceDashboard';
import { AdvancedFinancialDashboard } from './modules/finance/components/AdvancedFinancialDashboard';
import { AgricultureView } from './modules/agriculture/components/AgricultureView';
import { AdvancedDocumentationView } from './modules/documentation/components/AdvancedDocumentationView';
import { MarketingView } from './modules/marketing/components/MarketingView';
import { SettingsView } from './modules/settings/components/SettingsView';

function App() {
  const [activeModule, setActiveModule] = useState('dashboard');

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return (
          <EnhancedDashboard
            onModuleSelect={setActiveModule}
            activeModule={activeModule}
          />
        );
      case 'owners':
        return <OwnersView onBack={() => setActiveModule('dashboard')} />;
      case 'farms':
        return <FarmsView onBack={() => setActiveModule('dashboard')} />;
      case 'reservations':
        return <AdvancedBookingsView onBack={() => setActiveModule('dashboard')} />;
      case 'investors':
        return <AdvancedInvestorsView onBack={() => setActiveModule('dashboard')} />;
      case 'wallets':
        return <WalletsView onBack={() => setActiveModule('dashboard')} />;
      case 'finance':
        return <AdvancedFinancialDashboard onBack={() => setActiveModule('dashboard')} />;
      case 'agriculture':
        return <AgricultureView onBack={() => setActiveModule('dashboard')} />;
      case 'documentation':
        return <AdvancedDocumentationView onBack={() => setActiveModule('dashboard')} />;
      case 'marketing':
        return <MarketingView onBack={() => setActiveModule('dashboard')} />;
      case 'settings':
        return <SettingsView onBack={() => setActiveModule('dashboard')} />;
      default:
        return (
          <EnhancedDashboard
            onModuleSelect={setActiveModule}
            activeModule={activeModule}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#F9F8F6]" dir="rtl">
      {renderModule()}
    </div>
  );
}

export default App;
