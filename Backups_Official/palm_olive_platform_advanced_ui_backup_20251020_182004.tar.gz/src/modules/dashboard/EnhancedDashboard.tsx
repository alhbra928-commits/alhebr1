import React, { useEffect, useState } from 'react';
import {
  MapPin,
  Calendar,
  Wallet,
  Users,
  Building,
  Award,
  TrendingUp,
  Settings,
  Sprout
} from 'lucide-react';
import { DashboardService } from './dashboardService';

interface EnhancedDashboardProps {
  onModuleSelect: (moduleId: string) => void;
  activeModule: string;
}

export function EnhancedDashboard({ onModuleSelect }: EnhancedDashboardProps) {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setLoading(true);
      const data = await DashboardService.getOverallStatistics();
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const modules = [
    {
      id: 'owners',
      title: 'أصحاب المزارع',
      subtitle: 'إدارة أصحاب المزارع',
      value: stats?.owners?.total || 0,
      icon: Building,
      gradient: 'linear-gradient(135deg, #C89B3C 0%, #E8C170 100%)',
      bgColor: 'bg-gradient-to-br from-[#C89B3C]/10 to-[#E8C170]/10',
    },
    {
      id: 'farms',
      title: 'المزارع',
      subtitle: 'إدارة المزارع والأشجار',
      value: stats?.farms?.total || 0,
      icon: MapPin,
      gradient: 'linear-gradient(135deg, #3D5B4B 0%, #5A8672 100%)',
      bgColor: 'bg-gradient-to-br from-[#3D5B4B]/10 to-[#5A8672]/10',
    },
    {
      id: 'reservations',
      title: 'الحجوزات',
      subtitle: 'متابعة الحجوزات والعقود',
      value: stats?.reservations?.total || 0,
      icon: Calendar,
      gradient: 'linear-gradient(135deg, #C89B3C 0%, #D4AF37 100%)',
      bgColor: 'bg-gradient-to-br from-[#C89B3C]/10 to-[#D4AF37]/10',
    },
    {
      id: 'investors',
      title: 'المستثمرون',
      subtitle: 'إدارة حسابات المستثمرين',
      value: stats?.users?.totalInvestors || 0,
      icon: Users,
      gradient: 'linear-gradient(135deg, #8B7355 0%, #A68968 100%)',
      bgColor: 'bg-gradient-to-br from-[#8B7355]/10 to-[#A68968]/10',
    },
    {
      id: 'finance',
      title: 'النظام المالي الذكي',
      subtitle: 'إدارة مالية شاملة ومبسطة',
      value: 4,
      icon: Wallet,
      gradient: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
      bgColor: 'bg-gradient-to-br from-emerald-500/10 to-emerald-600/10',
    },
    {
      id: 'agriculture',
      title: 'الخدمات الزراعية',
      subtitle: 'المعاملات والمنتجات الزراعية',
      value: 0,
      icon: Sprout,
      gradient: 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)',
      bgColor: 'bg-gradient-to-br from-green-500/10 to-green-600/10',
    },
    {
      id: 'documentation',
      title: 'التوثيق',
      subtitle: 'إصدار شهادات الملكية',
      value: 0,
      icon: Award,
      gradient: 'linear-gradient(135deg, #D4AF37 0%, #F4EBDD 100%)',
      bgColor: 'bg-gradient-to-br from-[#D4AF37]/10 to-[#F4EBDD]/10',
    },
    {
      id: 'marketing',
      title: 'التسويق',
      subtitle: 'متابعة الحملات التسويقية',
      value: 0,
      icon: TrendingUp,
      gradient: 'linear-gradient(135deg, #8B7355 0%, #C89B3C 100%)',
      bgColor: 'bg-gradient-to-br from-[#8B7355]/10 to-[#C89B3C]/10',
    },
    {
      id: 'settings',
      title: 'الإعدادات',
      subtitle: 'تخصيص النظام والإعدادات',
      value: 6,
      icon: Settings,
      gradient: 'linear-gradient(135deg, #3D5B4B 0%, #5A8672 100%)',
      bgColor: 'bg-gradient-to-br from-[#3D5B4B]/10 to-[#5A8672]/10',
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F9F8F6]">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#C89B3C] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg text-[#2C2C2C] font-medium">جاري تحميل لوحة التحكم...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F8F6]" dir="rtl">
      <div className="relative">
        <div className="bg-gradient-to-r from-[#C89B3C] to-[#D4AF37] shadow-lg">
          <div className="max-w-7xl mx-auto px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-xl">
                  <MapPin className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-white">
                    لوحة التحكم الرئيسية
                  </h1>
                  <p className="text-white/90 text-sm">منصة تملك النخيل والزيتون</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-4 py-2 bg-white/20 backdrop-blur-sm rounded-xl flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-white text-sm font-medium">9 وحدات نشطة</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {modules.map((module, index) => {
              const Icon = module.icon;
              const isHovered = hoveredCard === module.id;

              return (
                <div
                  key={module.id}
                  className="animate-fade-in-up"
                  style={{
                    animationDelay: `${index * 80}ms`,
                    animationFillMode: 'backwards',
                  }}
                >
                  <button
                    onClick={() => onModuleSelect(module.id)}
                    onMouseEnter={() => setHoveredCard(module.id)}
                    onMouseLeave={() => setHoveredCard(null)}
                    className={`
                      w-full p-6 rounded-3xl transition-all duration-500 ease-out
                      ${module.bgColor}
                      ${isHovered ? 'shadow-2xl scale-105' : 'shadow-lg'}
                      border-2 border-transparent
                      ${isHovered ? 'border-[#C89B3C]' : ''}
                      hover:bg-white/80
                      backdrop-blur-sm
                      transform
                      group
                      relative
                      overflow-hidden
                    `}
                  >
                    <div className={`
                      absolute inset-0 bg-gradient-to-br from-[#C89B3C]/0 to-[#C89B3C]/10
                      opacity-0 group-hover:opacity-100 transition-opacity duration-500
                    `}></div>

                    <div className="relative z-10">
                      <div className="flex items-start justify-between mb-4">
                        <div
                          className={`
                            w-16 h-16 rounded-2xl flex items-center justify-center
                            shadow-lg transition-all duration-500
                            ${isHovered ? 'scale-110 rotate-6' : ''}
                          `}
                          style={{
                            background: module.gradient,
                          }}
                        >
                          <Icon className="h-8 w-8 text-white" />
                        </div>
                        <div
                          className={`
                            px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-xl
                            transition-all duration-300
                            ${isHovered ? 'scale-110' : ''}
                          `}
                        >
                          <span className="text-2xl font-bold text-[#C89B3C]">
                            {module.value}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <h3 className="text-xl font-bold text-[#2C2C2C] mb-1 group-hover:text-[#C89B3C] transition-colors">
                          {module.title}
                        </h3>
                        <p className="text-sm text-[#2C2C2C]/70">
                          {module.subtitle}
                        </p>
                      </div>

                      <div className={`
                        mt-4 h-1 bg-gradient-to-r from-[#C89B3C]/20 to-transparent rounded-full
                        transition-all duration-500
                        ${isHovered ? 'from-[#C89B3C] scale-105' : ''}
                      `}></div>
                    </div>
                  </button>
                </div>
              );
            })}
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg border-2 border-[#C89B3C]/20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-[#2C2C2C]">إجمالي الإيرادات</h3>
                <div className="w-12 h-12 bg-gradient-to-br from-[#C89B3C] to-[#E8C170] rounded-xl flex items-center justify-center">
                  <Wallet className="h-6 w-6 text-white" />
                </div>
              </div>
              <p className="text-3xl font-black text-[#C89B3C]">
                {(stats?.revenue?.total || 0).toLocaleString('ar-SA')} ريال
              </p>
              <p className="text-sm text-[#2C2C2C]/70 mt-2">من جميع الحجوزات</p>
            </div>

            <div className="p-6 bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg border-2 border-[#3D5B4B]/20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-[#2C2C2C]">إجمالي الأشجار</h3>
                <div className="w-12 h-12 bg-gradient-to-br from-[#3D5B4B] to-[#5A8672] rounded-xl flex items-center justify-center">
                  <MapPin className="h-6 w-6 text-white" />
                </div>
              </div>
              <p className="text-3xl font-black text-[#3D5B4B]">
                {(stats?.farms?.totalTrees || 0).toLocaleString('ar-SA')}
              </p>
              <p className="text-sm text-[#2C2C2C]/70 mt-2">في جميع المزارع</p>
            </div>

            <div className="p-6 bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg border-2 border-[#8B7355]/20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-[#2C2C2C]">الأشجار المتاحة</h3>
                <div className="w-12 h-12 bg-gradient-to-br from-[#8B7355] to-[#A68968] rounded-xl flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-white" />
                </div>
              </div>
              <p className="text-3xl font-black text-[#8B7355]">
                {(stats?.farms?.availableTrees || 0).toLocaleString('ar-SA')}
              </p>
              <p className="text-sm text-[#2C2C2C]/70 mt-2">جاهزة للحجز</p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fade-in-up {
          animation: fade-in-up 0.6s ease-out;
        }

        @keyframes shimmer {
          0% {
            background-position: -200% center;
          }
          100% {
            background-position: 200% center;
          }
        }

        .group:hover .animate-shimmer {
          animation: shimmer 2s infinite;
          background-size: 200% 100%;
        }
      `}</style>
    </div>
  );
}
