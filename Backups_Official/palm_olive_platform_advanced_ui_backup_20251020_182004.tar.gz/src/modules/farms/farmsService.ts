import { supabase } from '../../lib/supabase';

export interface FarmFormData {
  name_ar: string;
  owner_id: string;
  deed_number: string;
  area_sqm: number;
  area_unit: string;
  farm_type: string;
  description_ar?: string;
  crop_type: string;
  total_trees: number;
  actual_price: number;
  marketing_price: number;
  unit_marketing_price: number;
  total_marketing_price: number;
  unit_actual_price: number;
  total_actual_price: number;
  has_well: boolean;
  has_electricity: boolean;
  has_fence: boolean;
  has_road: boolean;
  has_sterilization: boolean;
  technical_notes?: string;
  region: string;
  city: string;
  latitude?: number;
  longitude?: number;
  google_map_link?: string;
  aerial_map_url?: string;
  payment_grace_period: number;
  status: string;
  admin_notes?: string;
}

export interface Farm extends FarmFormData {
  id: string;
  farm_code?: string;
  farm_barcode?: string;
  barcode_generated_at?: string;
  created_at: string;
  created_by?: string;
  updated_at: string;
  updated_by?: string;
  deleted_at?: string;
  deleted_by?: string;
}

export interface TreeCode {
  id: string;
  farm_id: string;
  tree_code: string;
  tree_status: 'متاحة' | 'محجوزة' | 'مباعة';
  created_at: string;
  updated_at: string;
}

export class FarmsService {
  static async getAll() {
    const { data: farms, error } = await supabase
      .from('farms')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching farms:', error);
      throw error;
    }

    if (!farms || farms.length === 0) return [];

    // Get all owner IDs
    const ownerIds = [...new Set(farms.map(f => f.owner_id).filter(Boolean))];

    // Fetch owners
    const { data: owners } = await supabase
      .from('farm_owners')
      .select('id, full_name, mobile_number')
      .in('id', ownerIds);

    const ownersMap = new Map(owners?.map(o => [o.id, o]) || []);

    // Merge data
    return farms.map(farm => ({
      ...farm,
      owner: ownersMap.get(farm.owner_id) || null
    }));
  }

  static async getById(id: string) {
    const { data: farm, error } = await supabase
      .from('farms')
      .select('*')
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) {
      console.error('Error fetching farm:', error);
      throw error;
    }

    if (!farm) return null;

    // Fetch owner
    const { data: owner } = await supabase
      .from('farm_owners')
      .select('id, full_name, mobile_number, region, city')
      .eq('id', farm.owner_id)
      .maybeSingle();

    return {
      ...farm,
      owner: owner || null
    };
  }

  static async getActive() {
    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .eq('status', 'active')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching active farms:', error);
      throw error;
    }
    return data || [];
  }

  static async create(farm: FarmFormData) {
    const { data, error } = await supabase
      .from('farms')
      .insert([{
        ...farm,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) throw error;
    return data as Farm;
  }

  static async update(id: string, updates: Partial<FarmFormData>) {
    const { data, error } = await supabase
      .from('farms')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .is('deleted_at', null)
      .select()
      .single();

    if (error) throw error;
    return data as Farm;
  }

  static async deletePermanently(id: string, reason?: string) {
    const { error } = await supabase.rpc('delete_farm_permanently', {
      p_farm_id: id,
      p_deleted_by: null,
      p_reason: reason
    });

    if (error) throw error;
  }

  static async getStatistics() {
    const { data, error } = await supabase.rpc('get_farms_statistics');

    if (error) {
      console.error('Error fetching statistics:', error);
      return {
        total: 0,
        active: 0,
        frozen: 0,
        under_review: 0,
        total_trees: 0,
        available_trees: 0,
        total_area: 0,
        avg_marketing_price: 0
      };
    }
    return data;
  }

  static formatPrice(price: number): string {
    return `${price.toLocaleString('ar-SA')} ريال`;
  }

  static getFarmTypeEmoji(type: string): string {
    const emojiMap: { [key: string]: string } = {
      'نخيل': '🌴',
      'زيتون': '🫒',
      'مختلط': '🌾'
    };
    return emojiMap[type] || '🌱';
  }

  static getStatusColor(status: string): string {
    const colorMap: { [key: string]: string } = {
      active: 'bg-green-100 text-green-700 border-green-400',
      frozen: 'bg-blue-100 text-blue-700 border-blue-400',
      under_review: 'bg-yellow-100 text-yellow-700 border-yellow-400',
      archived: 'bg-gray-100 text-gray-700 border-gray-400'
    };
    return colorMap[status] || 'bg-gray-100 text-gray-700 border-gray-400';
  }

  static getStatusLabel(status: string): string {
    const labelMap: { [key: string]: string } = {
      active: 'نشطة',
      frozen: 'مجمدة',
      under_review: 'تحت المراجعة',
      archived: 'مؤرشفة'
    };
    return labelMap[status] || status;
  }

  static calculateProfitMargin(actualPrice: number, marketingPrice: number): number {
    if (actualPrice === 0) return 0;
    return ((marketingPrice - actualPrice) / actualPrice) * 100;
  }

  static formatArea(area: number, unit: string): string {
    return `${area.toLocaleString('ar-SA')} ${unit}`;
  }

  static async getTreeCodes(farmId: string): Promise<TreeCode[]> {
    const { data, error } = await supabase
      .from('farm_trees')
      .select('*')
      .eq('farm_id', farmId)
      .order('tree_code', { ascending: true });

    if (error) {
      console.error('Error fetching tree codes:', error);
      throw error;
    }

    return data || [];
  }

  static async getFarmWithTreeCodes(farmId: string) {
    const farm = await this.getById(farmId);
    if (!farm) return null;

    const treeCodes = await this.getTreeCodes(farmId);

    return {
      ...farm,
      treeCodes
    };
  }

  static async generateBarcode(farmCode: string, farmName: string): Promise<string> {
    const barcodeData = {
      farm_code: farmCode,
      farm_name: farmName,
      generated_at: new Date().toISOString()
    };

    const dataString = JSON.stringify(barcodeData);
    const encodedData = encodeURIComponent(dataString);
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodedData}`;

    return qrCodeUrl;
  }

  static async updateBarcodeInfo(farmId: string, barcodeUrl: string) {
    const { error } = await supabase
      .from('farms')
      .update({
        farm_barcode: barcodeUrl,
        barcode_generated_at: new Date().toISOString()
      })
      .eq('id', farmId);

    if (error) throw error;
  }

  static async getTreeCodesByStatus(farmId: string, status: string): Promise<TreeCode[]> {
    const { data, error } = await supabase
      .from('farm_trees')
      .select('*')
      .eq('farm_id', farmId)
      .eq('tree_status', status)
      .order('tree_code', { ascending: true });

    if (error) {
      console.error('Error fetching tree codes by status:', error);
      throw error;
    }

    return data || [];
  }

  static async updateTreeStatus(treeCode: string, newStatus: 'متاحة' | 'محجوزة' | 'مباعة') {
    const { error } = await supabase
      .from('farm_trees')
      .update({
        tree_status: newStatus,
        updated_at: new Date().toISOString()
      })
      .eq('tree_code', treeCode);

    if (error) throw error;
  }

  static async createBackupForCodes(farmId: string) {
    const farm = await this.getFarmWithTreeCodes(farmId);
    if (!farm) return null;

    const backup = {
      farm_code: farm.farm_code,
      farm_name: farm.name_ar,
      farm_barcode: farm.farm_barcode,
      total_trees: farm.total_trees,
      tree_codes: farm.treeCodes,
      backup_date: new Date().toISOString(),
      backup_reason: 'Automatic backup after farm creation'
    };

    return backup;
  }
}
