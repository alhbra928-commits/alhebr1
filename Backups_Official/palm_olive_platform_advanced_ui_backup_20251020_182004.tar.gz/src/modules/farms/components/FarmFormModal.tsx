import React, { useState, useEffect } from 'react';
import { X, Save, Home, Sprout, MapPin, Settings, Upload, Check } from 'lucide-react';

interface FarmFormData {
  name_ar: string;
  owner_id: string;
  deed_number: string;
  area_sqm: number;
  area_unit: string;
  farm_type: string;
  description_ar: string;
  crop_type: string;
  total_trees: number;
  actual_price: number;
  marketing_price: number;
  unit_marketing_price: number;
  total_marketing_price: number;
  unit_actual_price: number;
  total_actual_price: number;
  has_well: boolean;
  has_electricity: boolean;
  has_fence: boolean;
  has_road: boolean;
  has_sterilization: boolean;
  technical_notes: string;
  region: string;
  city: string;
  latitude?: number;
  longitude?: number;
  google_map_link: string;
  aerial_map_url: string;
  payment_grace_period: number;
  status: string;
  admin_notes: string;
}

interface FarmFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: FarmFormData) => Promise<void>;
  owners: any[];
  initialData?: any;
  mode: 'create' | 'edit';
}

export function FarmFormModal({ isOpen, onClose, onSubmit, owners, initialData, mode }: FarmFormModalProps) {
  const [activeTab, setActiveTab] = useState(0);
  const [formData, setFormData] = useState<FarmFormData>({
    name_ar: '',
    owner_id: '',
    deed_number: '',
    area_sqm: 0,
    area_unit: 'متر',
    farm_type: 'نخيل',
    description_ar: '',
    crop_type: '',
    total_trees: 0,
    actual_price: 0,
    marketing_price: 0,
    unit_marketing_price: 0,
    total_marketing_price: 0,
    unit_actual_price: 0,
    total_actual_price: 0,
    has_well: false,
    has_electricity: false,
    has_fence: false,
    has_road: false,
    has_sterilization: false,
    technical_notes: '',
    region: '',
    city: '',
    latitude: undefined,
    longitude: undefined,
    google_map_link: '',
    aerial_map_url: '',
    payment_grace_period: 6,
    status: 'active',
    admin_notes: ''
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<any>({});
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  const tabs = [
    { id: 0, label: 'البيانات الأساسية', icon: Home },
    { id: 1, label: 'التفاصيل الزراعية', icon: Sprout },
    { id: 2, label: 'الموقع والخريطة', icon: MapPin },
    { id: 3, label: 'الإعدادات', icon: Settings }
  ];

  // حساب تلقائي للأسعار الإجمالية
  useEffect(() => {
    const totalMarketing = formData.total_trees * formData.unit_marketing_price;
    const totalActual = formData.total_trees * formData.unit_actual_price;

    if (formData.total_marketing_price !== totalMarketing || formData.total_actual_price !== totalActual) {
      setFormData(prev => ({
        ...prev,
        total_marketing_price: totalMarketing,
        total_actual_price: totalActual
      }));
    }
  }, [formData.total_trees, formData.unit_marketing_price, formData.unit_actual_price]);

  useEffect(() => {
    if (initialData && mode === 'edit') {
      setFormData({
        name_ar: initialData.name_ar || '',
        owner_id: initialData.owner_id || '',
        deed_number: initialData.deed_number || '',
        area_sqm: initialData.area_sqm || 0,
        area_unit: initialData.area_unit || 'متر',
        farm_type: initialData.farm_type || 'نخيل',
        description_ar: initialData.description_ar || '',
        crop_type: initialData.crop_type || '',
        total_trees: initialData.total_trees || 0,
        actual_price: initialData.actual_price || 0,
        marketing_price: initialData.marketing_price || 0,
        unit_marketing_price: initialData.unit_marketing_price || 0,
        total_marketing_price: initialData.total_marketing_price || 0,
        unit_actual_price: initialData.unit_actual_price || 0,
        total_actual_price: initialData.total_actual_price || 0,
        has_well: initialData.has_well || false,
        has_electricity: initialData.has_electricity || false,
        has_fence: initialData.has_fence || false,
        has_road: initialData.has_road || false,
        has_sterilization: initialData.has_sterilization || false,
        technical_notes: initialData.technical_notes || '',
        region: initialData.region || '',
        city: initialData.city || '',
        latitude: initialData.latitude,
        longitude: initialData.longitude,
        google_map_link: initialData.google_map_link || '',
        aerial_map_url: initialData.aerial_map_url || '',
        payment_grace_period: initialData.payment_grace_period || 6,
        status: initialData.status || 'active',
        admin_notes: initialData.admin_notes || ''
      });
      if (initialData.aerial_map_url) {
        setImagePreview(initialData.aerial_map_url);
      }
    }
    setActiveTab(0);
    setErrors({});
  }, [initialData, mode, isOpen]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('حجم الصورة يجب أن يكون أقل من 5 ميغابايت');
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const validate = () => {
    const newErrors: any = {};

    if (!formData.name_ar.trim()) newErrors.name_ar = 'اسم المزرعة مطلوب';
    if (!formData.owner_id) newErrors.owner_id = 'يجب اختيار صاحب المزرعة';
    if (!formData.deed_number.trim()) newErrors.deed_number = 'رقم الصك مطلوب';
    if (!formData.area_sqm || formData.area_sqm <= 0) newErrors.area_sqm = 'المساحة مطلوبة';
    if (!formData.crop_type.trim()) newErrors.crop_type = 'الصنف الزراعي مطلوب';
    if (!formData.total_trees || formData.total_trees <= 0) newErrors.total_trees = 'عدد الأشجار مطلوب';
    if (!formData.actual_price || formData.actual_price <= 0) newErrors.actual_price = 'السعر الفعلي مطلوب';
    if (!formData.marketing_price || formData.marketing_price <= 0) newErrors.marketing_price = 'السعر التسويقي مطلوب';
    if (!formData.region.trim()) newErrors.region = 'المنطقة مطلوبة';
    if (!formData.city.trim()) newErrors.city = 'المدينة مطلوبة';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      alert('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    try {
      setLoading(true);

      let finalData = { ...formData };

      if (imageFile) {
        finalData.aerial_map_url = imagePreview;
      }

      await onSubmit(finalData);
      onClose();
    } catch (error: any) {
      setErrors({ submit: error.message || 'حدث خطأ أثناء الحفظ' });
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" dir="rtl">
      <div className="bg-white rounded-3xl shadow-2xl max-w-6xl w-full max-h-[95vh] overflow-hidden">
        <div className="bg-gradient-to-r from-[#C89B3C] to-[#D4AF37] p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <Home className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-white">
                  {mode === 'create' ? 'إضافة مزرعة جديدة' : 'تعديل بيانات المزرعة'}
                </h2>
                <p className="text-white/80 text-sm">
                  {mode === 'create' ? 'إدخال كامل بيانات المزرعة والتفاصيل التسويقية' : 'تحديث المعلومات'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-xl flex items-center justify-center transition-colors"
              type="button"
            >
              <X className="h-5 w-5 text-white" />
            </button>
          </div>

          <div className="flex gap-2 mt-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl transition-all ${
                    activeTab === tab.id
                      ? 'bg-white text-[#C89B3C] shadow-lg'
                      : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="text-sm font-bold">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[calc(95vh-280px)]">
          {activeTab === 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-[#3D5B4B] mb-4 flex items-center gap-2">
                <Home className="h-5 w-5" />
                البيانات الأساسية للمزرعة
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    اسم المزرعة *
                  </label>
                  <input
                    type="text"
                    value={formData.name_ar}
                    onChange={(e) => setFormData({ ...formData, name_ar: e.target.value })}
                    className={`w-full px-4 py-3 bg-white border-2 ${
                      errors.name_ar ? 'border-red-400' : 'border-[#C89B3C]/20'
                    } rounded-xl focus:outline-none focus:border-[#C89B3C] transition-colors`}
                    placeholder="مزرعة النخيل الذهبية"
                  />
                  {errors.name_ar && <p className="text-red-500 text-xs mt-1">{errors.name_ar}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    صاحب المزرعة *
                  </label>
                  <select
                    value={formData.owner_id}
                    onChange={(e) => setFormData({ ...formData, owner_id: e.target.value })}
                    className={`w-full px-4 py-3 bg-white border-2 ${
                      errors.owner_id ? 'border-red-400' : 'border-[#C89B3C]/20'
                    } rounded-xl focus:outline-none focus:border-[#C89B3C] transition-colors`}
                  >
                    <option value="">-- اختر المالك --</option>
                    {owners.map((owner) => (
                      <option key={owner.id} value={owner.id}>
                        {owner.full_name}
                      </option>
                    ))}
                  </select>
                  {errors.owner_id && <p className="text-red-500 text-xs mt-1">{errors.owner_id}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    رقم صك المزرعة *
                  </label>
                  <input
                    type="text"
                    value={formData.deed_number}
                    onChange={(e) => setFormData({ ...formData, deed_number: e.target.value })}
                    className={`w-full px-4 py-3 bg-white border-2 ${
                      errors.deed_number ? 'border-red-400' : 'border-[#C89B3C]/20'
                    } rounded-xl focus:outline-none focus:border-[#C89B3C] transition-colors`}
                    placeholder="123456789"
                  />
                  {errors.deed_number && <p className="text-red-500 text-xs mt-1">{errors.deed_number}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">المساحة *</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={formData.area_sqm}
                      onChange={(e) => setFormData({ ...formData, area_sqm: parseFloat(e.target.value) })}
                      className={`flex-1 px-4 py-3 bg-white border-2 ${
                        errors.area_sqm ? 'border-red-400' : 'border-[#C89B3C]/20'
                      } rounded-xl focus:outline-none focus:border-[#C89B3C] transition-colors`}
                      placeholder="5000"
                    />
                    <select
                      value={formData.area_unit}
                      onChange={(e) => setFormData({ ...formData, area_unit: e.target.value })}
                      className="px-4 py-3 bg-white border-2 border-[#C89B3C]/20 rounded-xl focus:outline-none focus:border-[#C89B3C]"
                    >
                      <option value="متر">متر</option>
                      <option value="هكتار">هكتار</option>
                    </select>
                  </div>
                  {errors.area_sqm && <p className="text-red-500 text-xs mt-1">{errors.area_sqm}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">نوع المزرعة *</label>
                  <select
                    value={formData.farm_type}
                    onChange={(e) => setFormData({ ...formData, farm_type: e.target.value })}
                    className="w-full px-4 py-3 bg-white border-2 border-[#C89B3C]/20 rounded-xl focus:outline-none focus:border-[#C89B3C]"
                  >
                    <option value="نخيل">🌴 نخيل</option>
                    <option value="زيتون">🫒 زيتون</option>
                    <option value="مختلط">🌾 مختلط</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    الوصف العام
                  </label>
                  <textarea
                    value={formData.description_ar}
                    onChange={(e) => setFormData({ ...formData, description_ar: e.target.value })}
                    className="w-full px-4 py-3 bg-white border-2 border-[#C89B3C]/20 rounded-xl focus:outline-none focus:border-[#C89B3C] transition-colors"
                    placeholder="وصف شامل عن المزرعة..."
                    rows={3}
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-green-700 mb-4 flex items-center gap-2">
                <Sprout className="h-5 w-5" />
                التفاصيل الزراعية والتسويقية
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    الصنف الزراعي *
                  </label>
                  <input
                    type="text"
                    value={formData.crop_type}
                    onChange={(e) => setFormData({ ...formData, crop_type: e.target.value })}
                    className={`w-full px-4 py-3 bg-white border-2 ${
                      errors.crop_type ? 'border-red-400' : 'border-green-200'
                    } rounded-xl focus:outline-none focus:border-green-400 transition-colors`}
                    placeholder="خلاص، سكري، بيكال..."
                  />
                  {errors.crop_type && <p className="text-red-500 text-xs mt-1">{errors.crop_type}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    عدد الأشجار *
                  </label>
                  <input
                    type="number"
                    value={formData.total_trees}
                    onChange={(e) => setFormData({ ...formData, total_trees: parseInt(e.target.value) })}
                    className={`w-full px-4 py-3 bg-white border-2 ${
                      errors.total_trees ? 'border-red-400' : 'border-green-200'
                    } rounded-xl focus:outline-none focus:border-green-400 transition-colors`}
                    placeholder="100"
                  />
                  {errors.total_trees && <p className="text-red-500 text-xs mt-1">{errors.total_trees}</p>}
                </div>

                {/* نظام التسعير الذكي */}
                <div className="md:col-span-2">
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl p-6">
                    <h3 className="text-lg font-bold text-[#2C2C2C] mb-4 flex items-center gap-2">
                      <span className="text-2xl">🧮</span>
                      نظام التسعير الذكي - الحساب التلقائي
                    </h3>
                    <p className="text-sm text-[#2C2C2C]/70 mb-6 flex items-center gap-2">
                      <span>💡</span>
                      يتم حساب الأسعار الإجمالية تلقائياً بناءً على: عدد الأشجار × السعر للوحدة
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* السعر الفعلي للوحدة */}
                      <div>
                        <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                          السعر الفعلي للوحدة (ريال) * <span className="text-red-500 text-xs">(إداري فقط)</span>
                        </label>
                        <input
                          type="number"
                          value={formData.unit_actual_price}
                          onChange={(e) => setFormData({ ...formData, unit_actual_price: parseFloat(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-red-50 border-2 border-red-200 rounded-xl focus:outline-none focus:border-red-400 transition-colors font-bold text-red-600"
                          placeholder="500"
                          min="0"
                        />
                        <p className="text-xs text-[#2C2C2C]/60 mt-1">السعر الفعلي لكل نخلة/شجرة</p>
                      </div>

                      {/* الإجمالي الفعلي */}
                      <div>
                        <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                          الإجمالي الفعلي الكلي (ريال) <span className="text-xs text-blue-600">🔄 تلقائي</span>
                        </label>
                        <div className="w-full px-4 py-3 bg-red-100 border-2 border-red-300 rounded-xl font-black text-2xl text-red-700 flex items-center justify-between">
                          <span>{formData.total_actual_price.toLocaleString('ar-SA')}</span>
                          <span className="text-sm">ريال</span>
                        </div>
                        <p className="text-xs text-[#2C2C2C]/60 mt-1">
                          {formData.total_trees} شجرة × {formData.unit_actual_price.toLocaleString('ar-SA')} ريال
                        </p>
                      </div>

                      {/* السعر التسويقي للوحدة */}
                      <div>
                        <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                          السعر التسويقي للوحدة (ريال) * <span className="text-green-500 text-xs">(للمستثمرين)</span>
                        </label>
                        <input
                          type="number"
                          value={formData.unit_marketing_price}
                          onChange={(e) => setFormData({ ...formData, unit_marketing_price: parseFloat(e.target.value) || 0 })}
                          className="w-full px-4 py-3 bg-green-50 border-2 border-green-200 rounded-xl focus:outline-none focus:border-green-400 transition-colors font-bold text-green-600"
                          placeholder="650"
                          min="0"
                        />
                        <p className="text-xs text-[#2C2C2C]/60 mt-1">السعر التسويقي لكل نخلة/شجرة</p>
                      </div>

                      {/* الإجمالي التسويقي */}
                      <div>
                        <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                          الإجمالي التسويقي الكلي (ريال) <span className="text-xs text-blue-600">🔄 تلقائي</span>
                        </label>
                        <div className="w-full px-4 py-3 bg-green-100 border-2 border-green-300 rounded-xl font-black text-2xl text-green-700 flex items-center justify-between">
                          <span>{formData.total_marketing_price.toLocaleString('ar-SA')}</span>
                          <span className="text-sm">ريال</span>
                        </div>
                        <p className="text-xs text-[#2C2C2C]/60 mt-1">
                          {formData.total_trees} شجرة × {formData.unit_marketing_price.toLocaleString('ar-SA')} ريال
                        </p>
                      </div>
                    </div>

                    {/* مؤشر هامش الربح الذكي */}
                    {formData.unit_actual_price > 0 && formData.unit_marketing_price > 0 && (
                      <div className={`mt-6 p-4 rounded-xl border-2 ${
                        formData.unit_marketing_price >= formData.unit_actual_price
                          ? 'bg-green-50 border-green-300'
                          : 'bg-red-50 border-red-300'
                      }`}>
                        {formData.unit_marketing_price >= formData.unit_actual_price ? (
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">✅</span>
                            <div className="flex-1">
                              <p className="font-bold text-green-700 text-sm">هامش ربح صحي</p>
                              <p className="text-xs text-green-600 mt-1">
                                السعر الفعلي: {formData.total_actual_price.toLocaleString('ar-SA')} ريال /
                                التسويقي: {formData.total_marketing_price.toLocaleString('ar-SA')} ريال
                                (+{(((formData.unit_marketing_price - formData.unit_actual_price) / formData.unit_actual_price) * 100).toFixed(1)}%)
                              </p>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">⚠️</span>
                            <div className="flex-1">
                              <p className="font-bold text-red-700 text-sm">تحذير: السعر التسويقي أقل من الفعلي!</p>
                              <p className="text-xs text-red-600 mt-1">
                                قد يؤدي هذا إلى خسارة. يُرجى مراجعة الأسعار.
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    السعر الفعلي (ريال) * <span className="text-red-500 text-xs">(إداري فقط)</span>
                  </label>
                  <input
                    type="number"
                    value={formData.actual_price}
                    onChange={(e) => setFormData({ ...formData, actual_price: parseFloat(e.target.value) })}
                    className={`w-full px-4 py-3 bg-red-50 border-2 ${
                      errors.actual_price ? 'border-red-400' : 'border-red-200'
                    } rounded-xl focus:outline-none focus:border-red-400 transition-colors`}
                    placeholder="500000"
                  />
                  {errors.actual_price && <p className="text-red-500 text-xs mt-1">{errors.actual_price}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    السعر التسويقي (ريال) * <span className="text-green-500 text-xs">(للمستثمرين)</span>
                  </label>
                  <input
                    type="number"
                    value={formData.marketing_price}
                    onChange={(e) => setFormData({ ...formData, marketing_price: parseFloat(e.target.value) })}
                    className={`w-full px-4 py-3 bg-green-50 border-2 ${
                      errors.marketing_price ? 'border-red-400' : 'border-green-200'
                    } rounded-xl focus:outline-none focus:border-green-400 transition-colors`}
                    placeholder="600000"
                  />
                  {errors.marketing_price && <p className="text-red-500 text-xs mt-1">{errors.marketing_price}</p>}
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-3">
                    المميزات الإضافية
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                    {[
                      { key: 'has_well', label: 'بئر', icon: '💧' },
                      { key: 'has_electricity', label: 'كهرباء', icon: '⚡' },
                      { key: 'has_fence', label: 'سور', icon: '🚧' },
                      { key: 'has_road', label: 'طريق', icon: '🛣️' },
                      { key: 'has_sterilization', label: 'عقم زراعي', icon: '🌿' }
                    ].map((feature) => (
                      <label
                        key={feature.key}
                        className={`flex items-center gap-2 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                          formData[feature.key as keyof FarmFormData]
                            ? 'bg-green-50 border-green-400'
                            : 'bg-gray-50 border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={formData[feature.key as keyof FarmFormData] as boolean}
                          onChange={(e) => setFormData({ ...formData, [feature.key]: e.target.checked })}
                          className="w-4 h-4"
                        />
                        <span className="text-lg">{feature.icon}</span>
                        <span className="text-sm font-medium">{feature.label}</span>
                        {formData[feature.key as keyof FarmFormData] && (
                          <Check className="h-4 w-4 text-green-600 mr-auto" />
                        )}
                      </label>
                    ))}
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    ملاحظات فنية
                  </label>
                  <textarea
                    value={formData.technical_notes}
                    onChange={(e) => setFormData({ ...formData, technical_notes: e.target.value })}
                    className="w-full px-4 py-3 bg-white border-2 border-green-200 rounded-xl focus:outline-none focus:border-green-400 transition-colors"
                    placeholder="تفاصيل إضافية عن الإنتاج أو الحالة..."
                    rows={3}
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 2 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-blue-700 mb-4 flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                الموقع والخريطة الجوية
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">المنطقة *</label>
                  <input
                    type="text"
                    value={formData.region}
                    onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                    className={`w-full px-4 py-3 bg-white border-2 ${
                      errors.region ? 'border-red-400' : 'border-blue-200'
                    } rounded-xl focus:outline-none focus:border-blue-400 transition-colors`}
                    placeholder="الرياض"
                  />
                  {errors.region && <p className="text-red-500 text-xs mt-1">{errors.region}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">المدينة *</label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className={`w-full px-4 py-3 bg-white border-2 ${
                      errors.city ? 'border-red-400' : 'border-blue-200'
                    } rounded-xl focus:outline-none focus:border-blue-400 transition-colors`}
                    placeholder="الدرعية"
                  />
                  {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">خط العرض</label>
                  <input
                    type="number"
                    step="0.000001"
                    value={formData.latitude || ''}
                    onChange={(e) => setFormData({ ...formData, latitude: parseFloat(e.target.value) })}
                    className="w-full px-4 py-3 bg-white border-2 border-blue-200 rounded-xl focus:outline-none focus:border-blue-400 transition-colors"
                    placeholder="24.7136"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">خط الطول</label>
                  <input
                    type="number"
                    step="0.000001"
                    value={formData.longitude || ''}
                    onChange={(e) => setFormData({ ...formData, longitude: parseFloat(e.target.value) })}
                    className="w-full px-4 py-3 bg-white border-2 border-blue-200 rounded-xl focus:outline-none focus:border-blue-400 transition-colors"
                    placeholder="46.6753"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    رابط خريطة جوجل
                  </label>
                  <input
                    type="url"
                    value={formData.google_map_link}
                    onChange={(e) => setFormData({ ...formData, google_map_link: e.target.value })}
                    className="w-full px-4 py-3 bg-white border-2 border-blue-200 rounded-xl focus:outline-none focus:border-blue-400 transition-colors"
                    placeholder="https://maps.google.com/..."
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    مدة السماح لتحصيل المبلغ الكامل *
                  </label>
                  <select
                    value={formData.payment_grace_period}
                    onChange={(e) => setFormData({ ...formData, payment_grace_period: parseInt(e.target.value) })}
                    className="w-full px-4 py-3 bg-white border-2 border-blue-200 rounded-xl focus:outline-none focus:border-blue-400"
                  >
                    <option value={3}>3 أشهر</option>
                    <option value={6}>6 أشهر</option>
                    <option value={9}>9 أشهر</option>
                    <option value={12}>12 شهر</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    📤 رفع الخريطة الجوية للمزرعة (من Google Earth)
                  </label>
                  <div className="border-2 border-dashed border-blue-300 rounded-xl p-6 text-center">
                    <input
                      type="file"
                      accept="image/jpeg,image/png"
                      onChange={handleImageChange}
                      className="hidden"
                      id="aerial-map-upload"
                    />
                    <label
                      htmlFor="aerial-map-upload"
                      className="cursor-pointer flex flex-col items-center gap-3"
                    >
                      {imagePreview ? (
                        <div className="relative">
                          <img
                            src={imagePreview}
                            alt="Aerial Map Preview"
                            className="max-h-64 rounded-lg"
                          />
                          <div className="absolute top-2 right-2 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                            <Check className="h-3 w-3" />
                            تم الرفع
                          </div>
                        </div>
                      ) : (
                        <>
                          <Upload className="h-12 w-12 text-blue-400" />
                          <div>
                            <p className="text-blue-600 font-bold">اضغط هنا لرفع الصورة</p>
                            <p className="text-xs text-gray-500 mt-1">JPG أو PNG - الحد الأقصى 5 ميغابايت</p>
                            <p className="text-xs text-gray-500">الدقة الموصى بها: 1920×1080 أو أعلى</p>
                          </div>
                        </>
                      )}
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-gray-700 mb-4 flex items-center gap-2">
                <Settings className="h-5 w-5" />
                الإعدادات المالية والإدارية
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    حالة المزرعة
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="w-full px-4 py-3 bg-white border-2 border-gray-200 rounded-xl focus:outline-none focus:border-gray-400"
                  >
                    <option value="active">✅ نشطة</option>
                    <option value="frozen">🧊 مجمدة</option>
                    <option value="under_review">🕐 تحت المراجعة</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-[#2C2C2C] mb-2">
                    ملاحظات الإدارة (للاستخدام الداخلي فقط)
                  </label>
                  <textarea
                    value={formData.admin_notes}
                    onChange={(e) => setFormData({ ...formData, admin_notes: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-gray-400 transition-colors"
                    placeholder="ملاحظات خاصة بالإدارة..."
                    rows={4}
                  />
                </div>
              </div>

              <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4">
                <h4 className="font-bold text-amber-900 mb-2">📋 ملخص البيانات</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                  <div>
                    <p className="text-gray-600">اسم المزرعة:</p>
                    <p className="font-bold">{formData.name_ar || '-'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">المساحة:</p>
                    <p className="font-bold">{formData.area_sqm} {formData.area_unit}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">عدد الأشجار:</p>
                    <p className="font-bold">{formData.total_trees || 0}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">السعر التسويقي:</p>
                    <p className="font-bold text-green-600">{formData.marketing_price.toLocaleString()} ريال</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {errors.submit && (
            <div className="p-4 bg-red-50 border-2 border-red-200 rounded-xl">
              <p className="text-red-600 text-sm">{errors.submit}</p>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-[#C89B3C] to-[#D4AF37] text-white rounded-xl hover:shadow-lg transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed font-bold"
            >
              <Save className="h-5 w-5" />
              {loading ? 'جاري الحفظ...' : mode === 'create' ? '💾 حفظ المزرعة' : '✏️ حفظ التعديلات'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-4 bg-gray-200 text-gray-700 rounded-xl hover:bg-gray-300 transition-colors font-medium"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
