import React from 'react';
import {
  Calendar,
  User,
  MapPin,
  Trees,
  DollarSign,
  Eye,
  CheckCircle,
  XCircle,
  Award,
  Pause,
  Trash2,
  Clock
} from 'lucide-react';
import { Card3D } from '../../../components/ui/Card3D';
import { Booking } from '../bookingsService';

interface BookingCard3DProps {
  booking: Booking;
  onView: (booking: Booking) => void;
  onApprove: (booking: Booking) => void;
  onReject: (booking: Booking) => void;
  onFreeze: (booking: Booking) => void;
  onDelete: (booking: Booking) => void;
  onIssueCertificate: (booking: Booking) => void;
}

export function BookingCard3D({
  booking,
  onView,
  onApprove,
  onReject,
  onFreeze,
  onDelete,
  onIssueCertificate
}: BookingCard3DProps) {
  const getStatusConfig = (status: string) => {
    const configs: any = {
      pending: {
        label: 'بانتظار المراجعة',
        color: 'bg-gradient-to-r from-yellow-50 to-yellow-100',
        textColor: 'text-yellow-700',
        borderColor: 'border-yellow-300',
        icon: Clock,
        nextAction: 'بانتظار اعتماد الإدارة'
      },
      approved: {
        label: 'معتمد',
        color: 'bg-gradient-to-r from-green-50 to-green-100',
        textColor: 'text-green-700',
        borderColor: 'border-green-300',
        icon: CheckCircle,
        nextAction: 'جاهز للتوثيق'
      },
      rejected: {
        label: 'مرفوض',
        color: 'bg-gradient-to-r from-red-50 to-red-100',
        textColor: 'text-red-700',
        borderColor: 'border-red-300',
        icon: XCircle,
        nextAction: 'تم رفض الحجز'
      },
      documented: {
        label: 'موثّق',
        color: 'bg-gradient-to-r from-blue-50 to-blue-100',
        textColor: 'text-blue-700',
        borderColor: 'border-blue-300',
        icon: Award,
        nextAction: 'تم إصدار الشهادة'
      }
    };
    return configs[status] || configs.pending;
  };

  const getPaymentStatusConfig = (status: string) => {
    const configs: any = {
      pending: { label: 'لم يُدفع', color: 'bg-orange-100 text-orange-700' },
      partial: { label: 'دفع جزئي', color: 'bg-yellow-100 text-yellow-700' },
      completed: { label: 'مدفوع كاملاً', color: 'bg-green-100 text-green-700' }
    };
    return configs[status] || configs.pending;
  };

  const statusConfig = getStatusConfig(booking.booking_status);
  const paymentConfig = getPaymentStatusConfig(booking.payment_status);
  const StatusIcon = statusConfig.icon;

  return (
    <Card3D>
      <div className="group relative">
        <div className={`p-6 ${statusConfig.color} border-2 ${statusConfig.borderColor} rounded-xl transition-all duration-300 hover:shadow-xl`}>
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-mono text-sm font-black text-[#C89B3C] tracking-wider">
                  {booking.booking_code}
                </span>
                <span className={`px-3 py-1 rounded-lg text-xs font-bold border-2 ${statusConfig.borderColor} ${statusConfig.textColor} bg-white/80`}>
                  {statusConfig.label}
                </span>
              </div>

              <h3 className="text-lg font-black text-[#2C2C2C] mb-1 flex items-center gap-2">
                <MapPin className="h-4 w-4 text-[#C89B3C]" />
                {booking.farm?.name_ar || 'مزرعة غير معروفة'}
              </h3>

              <p className="text-xs text-[#2C2C2C]/60 font-mono">
                {booking.farm_code || 'لا يوجد كود'}
              </p>
            </div>

            <div className="flex flex-col items-end gap-2">
              <StatusIcon className={`h-8 w-8 ${statusConfig.textColor}`} />
            </div>
          </div>

          <div className="space-y-2 mb-4 pb-4 border-b-2 border-white/50">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                <User className="h-3 w-3" />
                المستثمر:
              </span>
              <span className="font-bold text-[#2C2C2C]">{booking.investor_name}</span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                التاريخ:
              </span>
              <span className="font-mono text-[#2C2C2C]">
                {new Date(booking.booking_date).toLocaleDateString('ar-SA')}
              </span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                <Trees className="h-3 w-3" />
                الأشجار:
              </span>
              <span className="font-black text-amber-600">{booking.reserved_trees} شجرة</span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2C2C2C]/70 flex items-center gap-1">
                <DollarSign className="h-3 w-3" />
                المبلغ:
              </span>
              <span className="font-black text-green-600">
                {booking.total_price.toLocaleString('ar-SA')} ريال
              </span>
            </div>

            <div className="flex items-center justify-between text-sm">
              <span className="text-[#2C2C2C]/70">حالة الدفع:</span>
              <span className={`px-2 py-1 rounded text-xs font-bold ${paymentConfig.color}`}>
                {paymentConfig.label}
              </span>
            </div>
          </div>

          <div className="mb-4">
            <p className="text-xs text-[#2C2C2C]/60 italic flex items-center gap-1">
              <Clock className="h-3 w-3" />
              الإجراء التالي: <span className="font-bold">{statusConfig.nextAction}</span>
            </p>
          </div>

          <div className="opacity-0 group-hover:opacity-100 transition-all duration-300 space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onView(booking)}
                className="flex items-center justify-center gap-1 px-3 py-2 bg-white/90 hover:bg-white text-[#2C2C2C] border-2 border-[#2C2C2C]/20 rounded-lg font-bold text-xs transition-all"
              >
                <Eye className="h-3 w-3" />
                عرض
              </button>

              {booking.booking_status === 'pending' && (
                <>
                  <button
                    onClick={() => onApprove(booking)}
                    className="flex items-center justify-center gap-1 px-3 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg font-bold text-xs transition-all"
                  >
                    <CheckCircle className="h-3 w-3" />
                    اعتماد
                  </button>
                  <button
                    onClick={() => onReject(booking)}
                    className="flex items-center justify-center gap-1 px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-bold text-xs transition-all"
                  >
                    <XCircle className="h-3 w-3" />
                    رفض
                  </button>
                  <button
                    onClick={() => onFreeze(booking)}
                    className="flex items-center justify-center gap-1 px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-bold text-xs transition-all"
                  >
                    <Pause className="h-3 w-3" />
                    تجميد
                  </button>
                </>
              )}

              {booking.booking_status === 'approved' && (
                <button
                  onClick={() => onIssueCertificate(booking)}
                  className="col-span-2 flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-[#C89B3C] to-[#D4B574] hover:from-[#B8894E] hover:to-[#C9A962] text-white rounded-lg font-black text-sm transition-all shadow-lg"
                >
                  <Award className="h-4 w-4" />
                  إصدار الشهادة
                </button>
              )}

              {(booking.booking_status === 'pending' || booking.booking_status === 'rejected') && (
                <button
                  onClick={() => onDelete(booking)}
                  className="flex items-center justify-center gap-1 px-3 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg font-bold text-xs transition-all"
                >
                  <Trash2 className="h-3 w-3" />
                  حذف
                </button>
              )}
            </div>
          </div>

          {booking.booking_status === 'documented' && (
            <div className="mt-4 p-3 bg-gradient-to-r from-purple-100 to-blue-100 border-2 border-purple-300 rounded-lg text-center">
              <p className="text-sm font-black text-purple-700 flex items-center justify-center gap-2">
                <Award className="h-5 w-5" />
                تم التوثيق وإصدار الشهادة
              </p>
            </div>
          )}
        </div>
      </div>
    </Card3D>
  );
}
