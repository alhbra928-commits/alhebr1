import React, { useEffect, useState } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Award,
  DollarSign,
  Search,
  Filter,
  RefreshCw,
  TrendingUp
} from 'lucide-react';
import { Card3D } from '../../../components/ui/Card3D';
import { BackButton } from '../../../components/common/BackButton';
import { BookingsService, Booking } from '../bookingsService';
import { DocumentationService } from '../../documentation/documentationService';
import { BookingCard3D } from './BookingCard3D';
import { BookingDetailsPanel } from './BookingDetailsPanel';

interface AdvancedBookingsViewProps {
  onBack?: () => void;
}

export function AdvancedBookingsView({ onBack }: AdvancedBookingsViewProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filteredBookings, setFilteredBookings] = useState<Booking[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    applyFilters();
  }, [bookings, searchTerm, statusFilter]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [bookingsData, statsData] = await Promise.all([
        BookingsService.getAll(),
        BookingsService.getStatistics()
      ]);
      setBookings(bookingsData);
      setStats(statsData);
    } catch (err) {
      console.error('Error loading bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...bookings];

    if (searchTerm) {
      filtered = filtered.filter(booking =>
        booking.booking_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        booking.investor_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        booking.farm?.name_ar?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        booking.farm_code?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(booking => booking.booking_status === statusFilter);
    }

    setFilteredBookings(filtered);
  };

  const handleViewBooking = (booking: Booking) => {
    setSelectedBooking(booking);
    setIsPanelOpen(true);
  };

  const handleApprove = async (booking: Booking) => {
    if (!confirm(`هل تريد اعتماد الحجز ${booking.booking_code}؟`)) return;

    try {
      setActionLoading(true);
      await BookingsService.updateStatus(booking.id, 'approved', 'current-user-id');
      await loadData();
      setIsPanelOpen(false);
      alert('✅ تم اعتماد الحجز بنجاح');
    } catch (error) {
      console.error('Error approving booking:', error);
      alert('حدث خطأ في اعتماد الحجز');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async (booking: Booking) => {
    if (!confirm(`هل تريد رفض الحجز ${booking.booking_code}؟`)) return;

    try {
      setActionLoading(true);
      await BookingsService.updateStatus(booking.id, 'rejected');
      await loadData();
      setIsPanelOpen(false);
      alert('❌ تم رفض الحجز');
    } catch (error) {
      console.error('Error rejecting booking:', error);
      alert('حدث خطأ في رفض الحجز');
    } finally {
      setActionLoading(false);
    }
  };

  const handleFreeze = async (booking: Booking) => {
    alert('🧊 ميزة التجميد ستكون متاحة قريباً');
  };

  const handleDelete = async (booking: Booking) => {
    if (!confirm(`⚠️ هل أنت متأكد من الحذف النهائي للحجز ${booking.booking_code}؟\n\nسيتم حفظ نسخة احتياطية JSON`)) return;

    try {
      setActionLoading(true);
      await BookingsService.delete(booking.id);
      await loadData();
      setIsPanelOpen(false);
      alert('🗑️ تم الحذف بنجاح مع حفظ نسخة احتياطية');
    } catch (error) {
      console.error('Error deleting booking:', error);
      alert('حدث خطأ في حذف الحجز');
    } finally {
      setActionLoading(false);
    }
  };

  const handleIssueCertificate = async (booking: Booking) => {
    if (booking.booking_status !== 'approved') {
      alert('يجب اعتماد الحجز أولاً');
      return;
    }

    if (!confirm(
      `🪪 إصدار شهادة تملك للحجز ${booking.booking_code}\n\n` +
      `سيتم:\n` +
      `• نقل الحجز إلى إدارة التوثيق\n` +
      `• إنشاء شهادة تملك رقمية\n` +
      `• إرسال إشعار للمستثمر\n\n` +
      `هل تريد المتابعة؟`
    )) return;

    try {
      setActionLoading(true);

      const documentationId = await BookingsService.migrateToDocumentation(
        booking.id,
        'current-user-id'
      );

      const documentation = await DocumentationService.getById(documentationId);

      if (documentation) {
        const qrUrl = await DocumentationService.generateCertificateQR(
          documentation.certificate_code,
          documentation.verification_token
        );

        await DocumentationService.updateCertificatePDF(
          documentationId,
          `https://example.com/certificates/${documentation.certificate_code}.pdf`,
          qrUrl
        );

        alert(
          `✅ تم إصدار الشهادة بنجاح!\n\n` +
          `🔢 رقم الحجز: ${booking.booking_code}\n` +
          `📜 رقم الشهادة: ${documentation.certificate_code}\n` +
          `👤 المستثمر: ${booking.investor_name}\n` +
          `🌳 عدد الأشجار: ${booking.reserved_trees}\n` +
          `💰 المبلغ: ${booking.total_price.toLocaleString('ar-SA')} ريال\n\n` +
          `تم نقل السجل إلى إدارة التوثيق`
        );

        await loadData();
        setIsPanelOpen(false);
      }
    } catch (error: any) {
      console.error('Error issuing certificate:', error);
      alert('حدث خطأ في إصدار الشهادة: ' + (error.message || 'خطأ غير معروف'));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#F9F8F6]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-20 w-20 border-b-4 border-[#C89B3C] mx-auto mb-4"></div>
          <p className="text-[#2C2C2C]/70 font-bold">جاري تحميل الحجوزات...</p>
        </div>
      </div>
    );
  }

  const pendingBookings = filteredBookings.filter(b => b.booking_status === 'pending');
  const approvedBookings = filteredBookings.filter(b => b.booking_status === 'approved');
  const documentedBookings = filteredBookings.filter(b => b.booking_status === 'documented');
  const rejectedBookings = filteredBookings.filter(b => b.booking_status === 'rejected');

  return (
    <div className="min-h-screen bg-[#F9F8F6] p-8" dir="rtl">
      <div className="max-w-[1800px] mx-auto">
        {onBack && (
          <div className="mb-6">
            <BackButton onBack={onBack} />
          </div>
        )}

        <div className="mb-8">
          <h1 className="text-5xl font-black text-[#C89B3C] mb-2 flex items-center gap-3">
            <Calendar className="h-12 w-12" />
            إدارة الحجوزات الذكية
          </h1>
          <p className="text-[#2C2C2C]/70 text-lg">
            لوحة تحكم متقدمة • معاينة • اعتماد • توثيق • متابعة مالية
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <Card3D>
            <div className="p-5 bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Calendar className="h-7 w-7 text-white" />
                </div>
                <span className="text-4xl font-black text-blue-600">{stats?.total || 0}</span>
              </div>
              <h3 className="text-sm font-black text-blue-900">إجمالي الحجوزات</h3>
            </div>
          </Card3D>

          <Card3D>
            <div className="p-5 bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-yellow-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Clock className="h-7 w-7 text-white" />
                </div>
                <span className="text-4xl font-black text-yellow-600">{stats?.pending || 0}</span>
              </div>
              <h3 className="text-sm font-black text-yellow-900">بانتظار المراجعة</h3>
            </div>
          </Card3D>

          <Card3D>
            <div className="p-5 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center shadow-lg">
                  <CheckCircle className="h-7 w-7 text-white" />
                </div>
                <span className="text-4xl font-black text-green-600">{stats?.approved || 0}</span>
              </div>
              <h3 className="text-sm font-black text-green-900">معتمدة</h3>
            </div>
          </Card3D>

          <Card3D>
            <div className="p-5 bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                  <Award className="h-7 w-7 text-white" />
                </div>
                <span className="text-4xl font-black text-purple-600">{stats?.documented || 0}</span>
              </div>
              <h3 className="text-sm font-black text-purple-900">موثّقة</h3>
            </div>
          </Card3D>

          <Card3D>
            <div className="p-5 bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg">
                  <DollarSign className="h-7 w-7 text-white" />
                </div>
                <div className="text-left">
                  <span className="text-2xl font-black text-emerald-600 block">
                    {(stats?.totalAmount || 0).toLocaleString('ar-SA', { maximumFractionDigits: 0 })}
                  </span>
                  <span className="text-xs text-emerald-600">ريال</span>
                </div>
              </div>
              <h3 className="text-sm font-black text-emerald-900">إجمالي المبالغ</h3>
            </div>
          </Card3D>
        </div>

        <div className="mb-6 bg-white p-4 rounded-xl shadow-md border-2 border-gray-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="🔍 بحث برقم الحجز، المستثمر، المزرعة..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-10 pl-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#C89B3C] focus:ring-2 focus:ring-[#C89B3C]/20 outline-none font-bold"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="h-5 w-5 text-gray-500" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#C89B3C] focus:ring-2 focus:ring-[#C89B3C]/20 outline-none font-bold"
              >
                <option value="all">جميع الحالات</option>
                <option value="pending">بانتظار المراجعة</option>
                <option value="approved">معتمدة</option>
                <option value="documented">موثّقة</option>
                <option value="rejected">مرفوضة</option>
              </select>

              <button
                onClick={loadData}
                className="p-3 bg-[#C89B3C] hover:bg-[#B8894E] text-white rounded-lg transition-colors"
              >
                <RefreshCw className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {filteredBookings.length === 0 ? (
          <div className="text-center py-20">
            <Calendar className="h-24 w-24 text-gray-300 mx-auto mb-4" />
            <h3 className="text-2xl font-black text-gray-400 mb-2">لا توجد حجوزات</h3>
            <p className="text-gray-400">سيتم عرض الحجوزات هنا عند إضافتها</p>
          </div>
        ) : (
          <div className="space-y-8">
            {pendingBookings.length > 0 && (
              <section>
                <h2 className="text-2xl font-black text-yellow-600 mb-4 flex items-center gap-2">
                  <Clock className="h-7 w-7" />
                  بانتظار المراجعة ({pendingBookings.length})
                </h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {pendingBookings.map(booking => (
                    <BookingCard3D
                      key={booking.id}
                      booking={booking}
                      onView={handleViewBooking}
                      onApprove={handleApprove}
                      onReject={handleReject}
                      onFreeze={handleFreeze}
                      onDelete={handleDelete}
                      onIssueCertificate={handleIssueCertificate}
                    />
                  ))}
                </div>
              </section>
            )}

            {approvedBookings.length > 0 && (
              <section>
                <h2 className="text-2xl font-black text-green-600 mb-4 flex items-center gap-2">
                  <CheckCircle className="h-7 w-7" />
                  معتمدة - جاهزة للتوثيق ({approvedBookings.length})
                </h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {approvedBookings.map(booking => (
                    <BookingCard3D
                      key={booking.id}
                      booking={booking}
                      onView={handleViewBooking}
                      onApprove={handleApprove}
                      onReject={handleReject}
                      onFreeze={handleFreeze}
                      onDelete={handleDelete}
                      onIssueCertificate={handleIssueCertificate}
                    />
                  ))}
                </div>
              </section>
            )}

            {documentedBookings.length > 0 && (
              <section>
                <h2 className="text-2xl font-black text-purple-600 mb-4 flex items-center gap-2">
                  <Award className="h-7 w-7" />
                  موثّقة - تم إصدار الشهادات ({documentedBookings.length})
                </h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {documentedBookings.map(booking => (
                    <BookingCard3D
                      key={booking.id}
                      booking={booking}
                      onView={handleViewBooking}
                      onApprove={handleApprove}
                      onReject={handleReject}
                      onFreeze={handleFreeze}
                      onDelete={handleDelete}
                      onIssueCertificate={handleIssueCertificate}
                    />
                  ))}
                </div>
              </section>
            )}

            {rejectedBookings.length > 0 && (
              <section>
                <h2 className="text-2xl font-black text-red-600 mb-4 flex items-center gap-2">
                  <XCircle className="h-7 w-7" />
                  مرفوضة ({rejectedBookings.length})
                </h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {rejectedBookings.map(booking => (
                    <BookingCard3D
                      key={booking.id}
                      booking={booking}
                      onView={handleViewBooking}
                      onApprove={handleApprove}
                      onReject={handleReject}
                      onFreeze={handleFreeze}
                      onDelete={handleDelete}
                      onIssueCertificate={handleIssueCertificate}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>

      <BookingDetailsPanel
        booking={selectedBooking}
        isOpen={isPanelOpen}
        onClose={() => setIsPanelOpen(false)}
        onApprove={handleApprove}
        onReject={handleReject}
        onFreeze={handleFreeze}
        onDelete={handleDelete}
        onIssueCertificate={handleIssueCertificate}
      />

      {actionLoading && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-white p-8 rounded-2xl shadow-2xl text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#C89B3C] mx-auto mb-4"></div>
            <p className="text-xl font-black text-[#2C2C2C]">جاري المعالجة...</p>
          </div>
        </div>
      )}
    </div>
  );
}
