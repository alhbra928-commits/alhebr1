import React, { useEffect, useState } from 'react';
import { Calendar, CheckCircle, Clock, XCircle, DollarSign, Users } from 'lucide-react';
import { Card3D } from '../../../components/ui/Card3D';
import { BackButton } from '../../../components/common/BackButton';
import { ReservationsService } from '../reservationsService';

interface ReservationsViewProps {
  onBack?: () => void;
}

export function ReservationsView({ onBack }: ReservationsViewProps) {
  const [reservations, setReservations] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReservations();
  }, []);

  const loadReservations = async () => {
    try {
      setLoading(true);
      const [reservationsData, statsData] = await Promise.all([
        ReservationsService.getAll(),
        ReservationsService.getStatistics()
      ]);
      setReservations(reservationsData);
      setStats(statsData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const getStatusInfo = (status: string) => {
    const statusMap: any = {
      pending: { label: 'قيد الانتظار', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
      confirmed: { label: 'مؤكد', color: 'bg-blue-100 text-blue-700', icon: CheckCircle },
      active: { label: 'نشط', color: 'bg-green-100 text-green-700', icon: CheckCircle },
      completed: { label: 'مكتمل', color: 'bg-gray-100 text-gray-700', icon: CheckCircle },
      cancelled: { label: 'ملغي', color: 'bg-red-100 text-red-700', icon: XCircle },
    };
    return statusMap[status] || statusMap.pending;
  };

  return (
    <div className="min-h-screen bg-[#F9F8F6] p-8" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {onBack && (
          <div className="mb-6">
            <BackButton onBack={onBack} />
          </div>
        )}

        <div className="mb-8">
          <h1 className="text-4xl font-black text-[#C89B3C] mb-2">إدارة الحجوزات</h1>
          <p className="text-[#2C2C2C]/70">متابعة وإدارة جميع حجوزات المستثمرين</p>
        </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Calendar className="h-5 w-5 text-blue-600" />
              </div>
              <span className="text-2xl font-bold text-gray-900">{stats?.total || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">إجمالي الحجوزات</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
              <span className="text-2xl font-bold text-yellow-600">{stats?.pending || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">قيد الانتظار</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <span className="text-2xl font-bold text-green-600">{stats?.active || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">نشطة</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-purple-600" />
              </div>
              <span className="text-2xl font-bold text-purple-600">
                {((stats?.totalAmount || 0) / 1000).toFixed(0)}k
              </span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">إجمالي الإيرادات</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Users className="h-5 w-5 text-orange-600" />
              </div>
              <span className="text-2xl font-bold text-orange-600">{stats?.totalTrees || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">أشجار محجوزة</h3>
          </div>
        </Card3D>
      </div>

      <div className="space-y-4">
        {reservations.map((reservation) => {
          const statusInfo = getStatusInfo(reservation.status);
          const StatusIcon = statusInfo.icon;

          return (
            <Card3D key={reservation.id}>
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-bold text-gray-900">
                        حجز #{reservation.id.slice(0, 8)}
                      </h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${statusInfo.color}`}>
                        <StatusIcon className="h-3 w-3" />
                        {statusInfo.label}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">
                      المزرعة: {reservation.farms?.name_ar || 'غير متوفر'}
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="text-2xl font-bold text-gray-900">
                      {Number(reservation.total_amount).toLocaleString()} ريال
                    </p>
                    <p className="text-xs text-gray-500">المبلغ الإجمالي</p>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-600 mb-1">عدد الأشجار</p>
                    <p className="text-sm font-semibold text-gray-900">{reservation.number_of_trees}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-600 mb-1">سعر الشجرة</p>
                    <p className="text-sm font-semibold text-gray-900">
                      {Number(reservation.price_per_tree).toLocaleString()} ريال
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-600 mb-1">حالة الدفع</p>
                    <p className="text-sm font-semibold text-gray-900">
                      {reservation.payment_status === 'paid' ? 'مدفوع' : 'معلق'}
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-600 mb-1">تاريخ الحجز</p>
                    <p className="text-sm font-semibold text-gray-900">
                      {new Date(reservation.created_at).toLocaleDateString('ar-SA')}
                    </p>
                  </div>
                </div>
              </div>
            </Card3D>
          );
        })}
      </div>

      {reservations.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد حجوزات</h3>
            <p className="text-gray-600">ستظهر الحجوزات الجديدة هنا</p>
          </div>
        )}
      </div>
    </div>
  );
}
