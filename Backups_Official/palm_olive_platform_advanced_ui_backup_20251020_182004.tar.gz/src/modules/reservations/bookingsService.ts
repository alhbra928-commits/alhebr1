import { supabase } from '../../lib/supabase';

export interface Booking {
  id: string;
  booking_code: string;
  farm_id: string;
  investor_id: string;
  farm_code?: string;
  investor_name: string;
  investor_mobile: string;
  investor_email?: string;
  reserved_trees: number;
  total_price: number;
  payment_status: 'pending' | 'partial' | 'completed';
  payment_amount: number;
  booking_status: 'pending' | 'approved' | 'rejected' | 'documented';
  booking_date: string;
  approved_at?: string;
  approved_by?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
  farm?: any;
  investor?: any;
}

export interface CreateBookingParams {
  farm_id: string;
  investor_id: string;
  investor_name: string;
  investor_mobile: string;
  investor_email?: string;
  reserved_trees: number;
  total_price: number;
  notes?: string;
}

export class BookingsService {
  static async getAll(): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        farms:farm_id(id, farm_code, name_ar, farm_type, region, city),
        investors:investor_id(id, full_name, mobile_number, email)
      `)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching bookings:', error);
      throw error;
    }

    return data || [];
  }

  static async getById(id: string): Promise<Booking | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        farms:farm_id(*),
        investors:investor_id(*)
      `)
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) {
      console.error('Error fetching booking:', error);
      throw error;
    }

    return data;
  }

  static async getByStatus(status: string): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        farms:farm_id(id, farm_code, name_ar),
        investors:investor_id(id, full_name, mobile_number)
      `)
      .eq('booking_status', status)
      .is('deleted_at', null)
      .order('created_at', { ascending: false});

    if (error) {
      console.error('Error fetching bookings by status:', error);
      throw error;
    }

    return data || [];
  }

  static async create(params: CreateBookingParams): Promise<Booking> {
    const farm = await supabase
      .from('farms')
      .select('farm_code')
      .eq('id', params.farm_id)
      .maybeSingle();

    const { data, error } = await supabase
      .from('bookings')
      .insert([{
        farm_id: params.farm_id,
        investor_id: params.investor_id,
        farm_code: farm.data?.farm_code,
        investor_name: params.investor_name,
        investor_mobile: params.investor_mobile,
        investor_email: params.investor_email,
        reserved_trees: params.reserved_trees,
        total_price: params.total_price,
        payment_status: 'pending',
        payment_amount: 0,
        booking_status: 'pending',
        notes: params.notes,
        booking_date: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) throw error;
    return data as Booking;
  }

  static async updateStatus(
    id: string,
    status: 'pending' | 'approved' | 'rejected' | 'documented',
    approvedBy?: string
  ): Promise<Booking> {
    const updates: any = {
      booking_status: status,
      updated_at: new Date().toISOString()
    };

    if (status === 'approved') {
      updates.approved_at = new Date().toISOString();
      updates.approved_by = approvedBy;
    }

    const { data, error } = await supabase
      .from('bookings')
      .update(updates)
      .eq('id', id)
      .is('deleted_at', null)
      .select()
      .single();

    if (error) throw error;
    return data as Booking;
  }

  static async updatePayment(
    id: string,
    paymentAmount: number,
    paymentStatus: 'pending' | 'partial' | 'completed'
  ): Promise<Booking> {
    const { data, error } = await supabase
      .from('bookings')
      .update({
        payment_amount: paymentAmount,
        payment_status: paymentStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .is('deleted_at', null)
      .select()
      .single();

    if (error) throw error;
    return data as Booking;
  }

  static async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('bookings')
      .update({
        deleted_at: new Date().toISOString()
      })
      .eq('id', id);

    if (error) throw error;
  }

  static async migrateToDocumentation(
    bookingId: string,
    migratedBy?: string
  ): Promise<string> {
    const { data, error } = await supabase.rpc('auto_migrate_to_documentation', {
      p_booking_id: bookingId,
      p_migrated_by: migratedBy,
      p_migration_reason: 'Certificate issued'
    });

    if (error) {
      console.error('Error migrating to documentation:', error);
      throw error;
    }

    return data;
  }

  static async getStatistics() {
    const { data, error } = await supabase
      .from('bookings')
      .select('booking_status, payment_status, total_price, reserved_trees')
      .is('deleted_at', null);

    if (error) {
      console.error('Error fetching statistics:', error);
      return {
        total: 0,
        pending: 0,
        approved: 0,
        rejected: 0,
        documented: 0,
        totalAmount: 0,
        totalTrees: 0,
        pendingPayment: 0,
        partialPayment: 0,
        completedPayment: 0
      };
    }

    return {
      total: data.length,
      pending: data.filter(b => b.booking_status === 'pending').length,
      approved: data.filter(b => b.booking_status === 'approved').length,
      rejected: data.filter(b => b.booking_status === 'rejected').length,
      documented: data.filter(b => b.booking_status === 'documented').length,
      totalAmount: data.reduce((sum, b) => sum + Number(b.total_price), 0),
      totalTrees: data.reduce((sum, b) => sum + b.reserved_trees, 0),
      pendingPayment: data.filter(b => b.payment_status === 'pending').length,
      partialPayment: data.filter(b => b.payment_status === 'partial').length,
      completedPayment: data.filter(b => b.payment_status === 'completed').length
    };
  }

  static formatPrice(price: number): string {
    return `${price.toLocaleString('ar-SA')} ريال`;
  }

  static getStatusColor(status: string): string {
    const colorMap: { [key: string]: string } = {
      pending: 'bg-yellow-100 text-yellow-700 border-yellow-400',
      approved: 'bg-green-100 text-green-700 border-green-400',
      rejected: 'bg-red-100 text-red-700 border-red-400',
      documented: 'bg-blue-100 text-blue-700 border-blue-400'
    };
    return colorMap[status] || 'bg-gray-100 text-gray-700 border-gray-400';
  }

  static getStatusLabel(status: string): string {
    const labelMap: { [key: string]: string } = {
      pending: 'قيد الانتظار',
      approved: 'موافق عليه',
      rejected: 'مرفوض',
      documented: 'موثّق'
    };
    return labelMap[status] || status;
  }

  static getPaymentStatusColor(status: string): string {
    const colorMap: { [key: string]: string } = {
      pending: 'bg-orange-100 text-orange-700',
      partial: 'bg-yellow-100 text-yellow-700',
      completed: 'bg-green-100 text-green-700'
    };
    return colorMap[status] || 'bg-gray-100 text-gray-700';
  }

  static getPaymentStatusLabel(status: string): string {
    const labelMap: { [key: string]: string } = {
      pending: 'لم يدفع',
      partial: 'دفع جزئي',
      completed: 'مدفوع كاملاً'
    };
    return labelMap[status] || status;
  }
}
