import { supabase } from '../../../lib/supabase';

export interface PaymentReceipt {
  id: string;
  reservation_id: string;
  investor_id: string | null;
  bank_name: string;
  amount: number;
  transfer_date: string;
  receipt_file_url: string;
  receipt_file_name: string;
  notes: string | null;
  status: 'pending' | 'verified' | 'rejected';
  verified_by: string | null;
  verified_at: string | null;
  verification_notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreatePaymentReceiptParams {
  reservationId: string;
  investorId: string | null;
  bankName: string;
  amount: number;
  transferDate: string;
  receiptFileUrl: string;
  receiptFileName: string;
  notes?: string;
}

export class PaymentReceiptService {
  static async uploadReceipt(params: CreatePaymentReceiptParams): Promise<PaymentReceipt> {
    console.log('📤 Uploading payment receipt:', params);

    const { data, error } = await supabase
      .from('payment_receipts')
      .insert([{
        reservation_id: params.reservationId,
        investor_id: params.investorId,
        bank_name: params.bankName,
        amount: params.amount,
        transfer_date: params.transferDate,
        receipt_file_url: params.receiptFileUrl,
        receipt_file_name: params.receiptFileName,
        notes: params.notes || null,
        status: 'pending',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) {
      console.error('❌ Error uploading receipt:', error);
      throw error;
    }

    console.log('✅ Receipt uploaded successfully:', data.id);

    const { error: updateError } = await supabase
      .from('reservations')
      .update({
        booking_status: 'pending_verification',
        updated_at: new Date().toISOString()
      })
      .eq('id', params.reservationId);

    if (updateError) {
      console.error('⚠️ Warning: Failed to update booking status:', updateError);
    } else {
      console.log('✅ Booking status updated to pending_verification');
    }

    return data as PaymentReceipt;
  }

  static async getReceiptsByReservation(reservationId: string): Promise<PaymentReceipt[]> {
    const { data, error } = await supabase
      .from('payment_receipts')
      .select('*')
      .eq('reservation_id', reservationId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching receipts:', error);
      throw error;
    }

    return data || [];
  }

  static async getReceiptsByInvestor(investorId: string): Promise<PaymentReceipt[]> {
    const { data, error } = await supabase
      .from('payment_receipts')
      .select('*')
      .eq('investor_id', investorId)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching investor receipts:', error);
      throw error;
    }

    return data || [];
  }

  static async getPendingReceipts(): Promise<PaymentReceipt[]> {
    const { data, error } = await supabase
      .from('payment_receipts')
      .select(`
        *,
        reservations:reservation_id(
          id,
          customer_name,
          customer_phone,
          number_of_trees,
          total_amount,
          farms:farm_id(name_ar, farm_code)
        )
      `)
      .eq('status', 'pending')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching pending receipts:', error);
      throw error;
    }

    return data || [];
  }

  static async verifyReceipt(
    receiptId: string,
    verifiedBy: string,
    verificationNotes?: string
  ): Promise<PaymentReceipt> {
    const { data, error } = await supabase
      .from('payment_receipts')
      .update({
        status: 'verified',
        verified_by: verifiedBy,
        verified_at: new Date().toISOString(),
        verification_notes: verificationNotes || null,
        updated_at: new Date().toISOString()
      })
      .eq('id', receiptId)
      .select()
      .single();

    if (error) {
      console.error('Error verifying receipt:', error);
      throw error;
    }

    return data as PaymentReceipt;
  }

  static async rejectReceipt(
    receiptId: string,
    verifiedBy: string,
    verificationNotes: string
  ): Promise<PaymentReceipt> {
    const { data, error } = await supabase
      .from('payment_receipts')
      .update({
        status: 'rejected',
        verified_by: verifiedBy,
        verified_at: new Date().toISOString(),
        verification_notes: verificationNotes,
        updated_at: new Date().toISOString()
      })
      .eq('id', receiptId)
      .select()
      .single();

    if (error) {
      console.error('Error rejecting receipt:', error);
      throw error;
    }

    return data as PaymentReceipt;
  }

  static getStatusLabel(status: string): string {
    const labels: { [key: string]: string } = {
      'pending': 'بانتظار التحقق',
      'verified': 'تم التحقق',
      'rejected': 'مرفوض'
    };
    return labels[status] || status;
  }

  static getStatusColor(status: string): string {
    const colors: { [key: string]: string } = {
      'pending': '#f59e0b',
      'verified': '#10b981',
      'rejected': '#ef4444'
    };
    return colors[status] || '#6b7280';
  }

  static async uploadFileToStorage(file: File): Promise<string> {
    const fileName = `receipt_${Date.now()}_${file.name}`;
    const filePath = `payment-receipts/${fileName}`;

    const { data, error } = await supabase.storage
      .from('receipts')
      .upload(filePath, file);

    if (error) {
      console.error('Error uploading file to storage:', error);
      throw error;
    }

    const { data: urlData } = supabase.storage
      .from('receipts')
      .getPublicUrl(filePath);

    return urlData.publicUrl;
  }
}
