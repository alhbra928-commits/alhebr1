import { useState, useEffect } from 'react';
import {
  Home, FileText, Trees, Award, Wallet, Clock, Bell, LogOut, Loader,
  CheckCircle2, AlertCircle, XCircle, Download, Wifi, Upload, FileCheck
} from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';
import { InvestorService, InvestorStats, InvestorReservation, InvestorTimeline } from '../services/investorService';
import { useRealtimeTables } from '../../../lib/realtimeSync';
import { PaymentReceiptUploadModal } from './PaymentReceiptUploadModal';
import { PaymentReceiptService } from '../services/paymentReceiptService';
import { ProgressTracker } from './ProgressTracker';
import { NotificationBadge, TabGlow } from './NotificationBadge';
import { NotificationBadgeService, BadgeNotifications } from '../services/notificationBadgeService';
import { ConnectionStatus } from './ConnectionStatus';
import { EnhancedNotificationService, Notification, ConnectionStatus as ConnStatus } from '../services/enhancedNotificationService';
import { CertificateModal } from './CertificateModal';

interface InvestorDashboardProps {
  phone: string;
  onLogout: () => void;
  isFirstTimeLogin?: boolean;
}

type TabType = 'home' | 'reservations' | 'farms' | 'certificates' | 'financials' | 'timeline' | 'notifications';

export function InvestorDashboard({ phone, onLogout, isFirstTimeLogin = false }: InvestorDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<InvestorStats | null>(null);
  const [reservations, setReservations] = useState<InvestorReservation[]>([]);
  const [farms, setFarms] = useState<any[]>([]);
  const [timeline, setTimeline] = useState<InvestorTimeline[]>([]);
  const [investorName, setInvestorName] = useState('');
  const [certificates, setCertificates] = useState<any[]>([]);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedReservation, setSelectedReservation] = useState<InvestorReservation | null>(null);
  const [receiptsMap, setReceiptsMap] = useState<{ [key: string]: any[] }>({});
  const [showWelcome, setShowWelcome] = useState(isFirstTimeLogin);
  const [certificateModalOpen, setCertificateModalOpen] = useState(false);
  const [selectedCertificate, setSelectedCertificate] = useState<any>(null);
  const [badgeCounts, setBadgeCounts] = useState<BadgeNotifications>({
    reservations: 0,
    certificates: 0,
    financials: 0,
    notifications: 0
  });
  const [connectionStatus, setConnectionStatus] = useState<ConnStatus>({
    status: 'connecting',
    lastUpdate: new Date()
  });
  const [realtimeNotifications, setRealtimeNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    loadAllData();

    const unsubscribeNotifications = NotificationBadgeService.subscribeToUpdates(
      phone,
      (counts) => {
        console.log('🔔 Notification counts updated:', counts);
        setBadgeCounts(counts);
      }
    );

    EnhancedNotificationService.subscribeToNotifications(
      phone,
      (notification) => {
        console.log('🔔 New realtime notification:', notification);
        setRealtimeNotifications(prev => [notification, ...prev]);
        loadAllData();
      },
      (status) => {
        setConnectionStatus(status);
      }
    );

    EnhancedNotificationService.subscribeToReservationUpdates(
      phone,
      (reservation) => {
        console.log('🔄 Reservation updated via realtime:', reservation);
        loadAllData();
      }
    );

    const unsubscribe = useRealtimeTables([
      {
        name: 'reservations',
        callbacks: {
          onInsert: () => {
            console.log('🔄 New reservation detected, reloading investor data...');
            loadAllData();
          },
          onUpdate: () => {
            console.log('🔄 Reservation updated, reloading investor data...');
            loadAllData();
          }
        },
        filter: `customer_phone=eq.${phone}`
      },
      {
        name: 'payment_receipts',
        callbacks: {
          onInsert: () => {
            console.log('🔄 New receipt uploaded, reloading...');
            loadAllData();
          },
          onUpdate: () => {
            console.log('🔄 Receipt status updated, reloading...');
            loadAllData();
          }
        }
      },
      {
        name: 'investors',
        callbacks: {
          onUpdate: () => {
            console.log('🔄 Investor data updated, reloading...');
            loadAllData();
          }
        },
        filter: `phone=eq.${phone}`
      }
    ]);

    return () => {
      unsubscribe();
      unsubscribeNotifications.then(unsub => unsub());
      EnhancedNotificationService.unsubscribeAll();
    };
  }, [phone]);

  const loadAllData = async () => {
    try {
      setLoading(true);

      const [statsData, reservationsData, farmsData, timelineData, investorData, certificatesData] = await Promise.all([
        InvestorService.getInvestorStats(phone),
        InvestorService.getInvestorReservations(phone),
        InvestorService.getInvestorFarms(phone),
        InvestorService.getInvestorTimeline(phone),
        InvestorService.getInvestorByPhone(phone),
        InvestorService.getInvestorCertificates(phone)
      ]);

      setStats(statsData);
      setReservations(reservationsData);
      setFarms(farmsData);
      setTimeline(timelineData);
      setInvestorName(investorData?.customer_name || phone);
      setCertificates(certificatesData);

      const receiptsPromises = reservationsData.map(res =>
        PaymentReceiptService.getReceiptsByReservation(res.id)
      );
      const receiptsResults = await Promise.all(receiptsPromises);
      const newReceiptsMap: { [key: string]: any[] } = {};
      reservationsData.forEach((res, idx) => {
        newReceiptsMap[res.id] = receiptsResults[idx];
      });
      setReceiptsMap(newReceiptsMap);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUploadReceipt = (reservation: InvestorReservation) => {
    setSelectedReservation(reservation);
    setUploadModalOpen(true);
  };

  const handleUploadSuccess = () => {
    loadAllData();
  };

  const getStatusInfo = (bookingStatus: string, reservationId?: string) => {
    switch (bookingStatus) {
      case 'temporary':
        return { label: '🕓 حجز مؤقت', color: '#6b7280', icon: Clock };
      case 'approved':
        return { label: '✅ معتمد - يرجى رفع الإيصال', color: '#d4af37', icon: CheckCircle2 };
      case 'pending_verification':
        return { label: '📩 قيد التحقق المالي', color: '#16a34a', icon: Clock };
      case 'verified':
        return { label: '💳 تم التحقق من السداد', color: '#10b981', icon: CheckCircle2 };
      case 'ownership_completed':
        return { label: '🏆 اكتمال التملك', color: '#d4af37', icon: Award };
      case 'documented':
        return { label: '📜 موثق', color: '#3b82f6', icon: FileCheck };
      case 'cancelled':
        return { label: 'ملغي', color: '#ef4444', icon: XCircle };
      default:
        return { label: bookingStatus, color: '#6b7280', icon: AlertCircle };
    }
  };

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: brandGradients.beige }}
      >
        <div className="text-center">
          <Loader
            className="h-12 w-12 animate-spin mx-auto mb-4"
            style={{ color: brandColors.primary.gold }}
          />
          <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
            جاري تحميل لوحة المستثمر...
          </p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'reservations', label: 'حجوزاتي', icon: FileText },
    { id: 'farms', label: 'مزارعي', icon: Trees },
    { id: 'certificates', label: 'الشهادات', icon: Award },
    { id: 'financials', label: 'المالية', icon: Wallet },
    { id: 'timeline', label: 'الجدول الزمني', icon: Clock },
    { id: 'notifications', label: 'الإشعارات', icon: Bell },
  ];

  return (
    <div
      className="min-h-screen"
      style={{ background: brandGradients.beige }}
      dir="rtl"
    >
      {showWelcome && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-6 backdrop-blur-lg"
          style={{ background: 'rgba(0,0,0,0.7)' }}
          onClick={() => setShowWelcome(false)}
        >
          <div
            className="relative max-w-2xl w-full rounded-3xl p-12 text-center"
            style={{
              background: 'linear-gradient(135deg, rgba(212,175,55,0.15) 0%, rgba(255,255,255,0.1) 100%)',
              border: `2px solid ${brandColors.primary.gold}60`,
              boxShadow: '0 30px 80px rgba(0,0,0,0.5)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className="w-32 h-32 rounded-full mx-auto mb-8 flex items-center justify-center"
              style={{
                background: brandGradients.gold,
                boxShadow: '0 20px 60px rgba(212,175,55,0.5)',
                animation: 'bounce 1s infinite'
              }}
            >
              <CheckCircle2 className="w-20 h-20 text-white" />
            </div>

            <h2
              className="text-5xl font-black mb-4"
              style={{
                background: brandGradients.gold,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              مرحباً بك في عائلة النخيل والزيتون! 🎉
            </h2>

            <p className="text-2xl font-bold text-white opacity-90 mb-8">
              {investorName || 'عزيزنا المستثمر'}
            </p>

            <div
              className="rounded-2xl p-6 mb-8"
              style={{
                background: 'rgba(212,175,55,0.1)',
                border: `1px solid ${brandColors.primary.gold}30`,
              }}
            >
              <p className="text-lg leading-relaxed text-white opacity-90">
                تم إنشاء حسابك بنجاح! 🌟
                <br />
                الآن يمكنك متابعة حجوزاتك، رفع إيصالات السداد، والحصول على شهاداتك الرقمية
                <br />
                نحن سعداء بانضمامك لرحلة التملك الزراعي المميزة 🫒🌴
              </p>
            </div>

            <button
              onClick={() => setShowWelcome(false)}
              className="px-12 py-4 rounded-2xl font-black text-xl text-white transition-all hover:scale-105"
              style={{
                background: brandGradients.gold,
                boxShadow: '0 10px 40px rgba(212,175,55,0.4)',
              }}
            >
              ابدأ رحلتك الآن ✨
            </button>
          </div>
        </div>
      )}

      <div
        className="sticky top-0 z-50 backdrop-blur-md border-b"
        style={{
          background: 'rgba(245, 240, 230, 0.9)',
          borderColor: brandColors.primary.gold + '20',
        }}
      >
        <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between">
          <ConnectionStatus
            status={connectionStatus.status}
            lastUpdate={connectionStatus.lastUpdate}
            className="mr-auto"
          />
          <div>
            <h1 className="text-2xl font-black" style={{ color: brandColors.primary.gold }}>
              لوحة المستثمر
            </h1>
            <p className="text-sm" style={{ color: brandColors.text.secondary }}>
              مرحباً، {investorName}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 rounded-lg border border-green-200">
              <Wifi className="w-4 h-4 text-green-600 animate-pulse" />
              <span className="text-xs font-bold text-green-600">متزامن</span>
            </div>
            <div className="text-left">
              <p className="text-xs" style={{ color: brandColors.text.secondary }}>
                جلسة نشطة
              </p>
              <p className="text-xs font-bold" style={{ color: brandColors.primary.gold }}>
                {phone}
              </p>
            </div>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-5 py-3 rounded-xl font-black transition-all hover:scale-105"
              style={{
                color: 'white',
                background: 'linear-gradient(135deg, #DC2626 0%, #EF4444 100%)',
                boxShadow: '0 4px 20px rgba(220, 38, 38, 0.3)',
              }}
            >
              <LogOut className="w-5 h-5" />
              <span>الخروج الكامل</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-6 py-8">
        <div className="flex gap-4 mb-8 overflow-x-auto pb-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            const badgeCount =
              tab.id === 'reservations' ? badgeCounts.reservations :
              tab.id === 'certificates' ? badgeCounts.certificates :
              tab.id === 'financials' ? badgeCounts.financials :
              tab.id === 'notifications' ? badgeCounts.notifications :
              0;

            const hasNotification = badgeCount > 0 && !isActive;

            const handleTabClick = () => {
              setActiveTab(tab.id as TabType);
              NotificationBadgeService.saveLastViewed(tab.id);

              setTimeout(async () => {
                const newCounts = await NotificationBadgeService.getNotificationCounts(phone);
                setBadgeCounts(newCounts);
              }, 300);
            };

            return (
              <button
                key={tab.id}
                onClick={handleTabClick}
                className="relative flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all whitespace-nowrap"
                style={{
                  background: isActive ? brandGradients.gold : 'white',
                  color: isActive ? 'white' : brandColors.text.primary,
                  boxShadow: isActive ? '0 4px 20px rgba(212,175,55,0.3)' : '0 2px 10px rgba(0,0,0,0.05)',
                }}
              >
                {hasNotification && <TabGlow hasNotification={true} color="gold" />}

                <div className="relative">
                  <Icon className="w-5 h-5" />
                  <NotificationBadge count={badgeCount} animate={!isActive} />
                </div>

                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {activeTab === 'home' && stats && (
          <div>
            <h2 className="text-3xl font-black mb-6" style={{ color: brandColors.text.primary }}>
              نظرة عامة
            </h2>

            {stats.totalReservations === 0 && (
              <div
                className="rounded-3xl p-12 mb-8 text-center"
                style={{
                  background: 'linear-gradient(135deg, rgba(212,175,55,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                  border: `2px solid ${brandColors.primary.gold}30`,
                  boxShadow: '0 10px 40px rgba(0,0,0,0.08)',
                }}
              >
                <div
                  className="w-24 h-24 rounded-full mx-auto mb-6 flex items-center justify-center"
                  style={{
                    background: brandGradients.gold,
                    boxShadow: '0 10px 30px rgba(212,175,55,0.3)',
                  }}
                >
                  <span className="text-5xl">🌴</span>
                </div>

                <h3 className="text-3xl font-black mb-4" style={{ color: brandColors.text.primary }}>
                  مرحباً بك في لوحة المستثمر!
                </h3>

                <p className="text-xl mb-6" style={{ color: brandColors.text.secondary }}>
                  ابدأ رحلتك الاستثمارية في مزارع النخيل والزيتون
                </p>

                <div className="space-y-4 max-w-xl mx-auto">
                  <div className="text-right p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.5)' }}>
                    <p className="font-bold mb-2" style={{ color: brandColors.text.primary }}>
                      🌿 استثمر في مزارع حقيقية
                    </p>
                    <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                      اختر من بين مزارعنا المتنوعة وابدأ الاستثمار
                    </p>
                  </div>

                  <div className="text-right p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.5)' }}>
                    <p className="font-bold mb-2" style={{ color: brandColors.text.primary }}>
                      📊 تابع استثماراتك
                    </p>
                    <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                      راقب أرباحك وعوائدك بشكل مباشر
                    </p>
                  </div>

                  <div className="text-right p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.5)' }}>
                    <p className="font-bold mb-2" style={{ color: brandColors.text.primary }}>
                      🏆 احصل على شهادات الملكية
                    </p>
                    <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                      وثّق استثماراتك بشهادات رسمية
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => window.location.href = '/'}
                  className="mt-8 px-8 py-4 rounded-2xl font-black text-xl text-white transition-all hover:scale-105"
                  style={{
                    background: brandGradients.gold,
                    boxShadow: '0 10px 40px rgba(212,175,55,0.3)',
                  }}
                >
                  تصفح المزارع المتاحة 🌾
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div
                className="rounded-2xl p-6"
                style={{
                  background: 'linear-gradient(135deg, rgba(212,175,55,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                  border: `2px solid ${brandColors.primary.gold}30`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <Trees className="w-8 h-8 mb-3" style={{ color: brandColors.primary.gold }} />
                <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                  مزارعي
                </p>
                <p className="text-4xl font-black" style={{ color: brandColors.primary.gold }}>
                  {stats.totalFarms}
                </p>
              </div>

              <div
                className="rounded-2xl p-6"
                style={{
                  background: 'linear-gradient(135deg, rgba(59,130,246,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                  border: `2px solid rgba(59,130,246,0.3)`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <FileText className="w-8 h-8 mb-3 text-blue-500" />
                <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                  إجمالي الحجوزات
                </p>
                <p className="text-4xl font-black text-blue-500">
                  {stats.totalReservations}
                </p>
              </div>

              <div
                className="rounded-2xl p-6"
                style={{
                  background: 'linear-gradient(135deg, rgba(16,185,129,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                  border: `2px solid rgba(16,185,129,0.3)`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <Award className="w-8 h-8 mb-3 text-green-500" />
                <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                  إجمالي الأشجار
                </p>
                <p className="text-4xl font-black text-green-500">
                  {stats.totalTrees.toLocaleString('ar-SA')}
                </p>
              </div>

              <div
                className="rounded-2xl p-6"
                style={{
                  background: 'linear-gradient(135deg, rgba(168,85,247,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                  border: `2px solid rgba(168,85,247,0.3)`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <Wallet className="w-8 h-8 mb-3 text-purple-500" />
                <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                  إجمالي الاستثمار
                </p>
                <p className="text-3xl font-black text-purple-500">
                  {stats.totalAmount.toLocaleString('ar-SA')} ر.س
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div
                className="rounded-2xl p-6"
                style={{
                  background: 'white',
                  border: `2px solid ${brandColors.primary.gold}30`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <h3 className="text-xl font-black mb-4" style={{ color: brandColors.text.primary }}>
                  آخر الحجوزات
                </h3>
                <div className="space-y-3">
                  {reservations.slice(0, 3).map((reservation) => {
                    const statusInfo = getStatusInfo((reservation as any).booking_status || reservation.status, reservation.id);
                    const StatusIcon = statusInfo.icon;

                    return (
                      <div
                        key={reservation.id}
                        className="p-4 rounded-xl flex items-center justify-between"
                        style={{ background: brandColors.background.beige }}
                      >
                        <div className="flex-1">
                          <p className="font-bold mb-1" style={{ color: brandColors.text.primary }}>
                            {reservation.farm_name}
                          </p>
                          <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                            {reservation.number_of_trees} شجرة - {reservation.total_amount.toLocaleString('ar-SA')} ر.س
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <StatusIcon className="w-5 h-5" style={{ color: statusInfo.color }} />
                          <span className="text-sm font-bold" style={{ color: statusInfo.color }}>
                            {statusInfo.label}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div
                className="rounded-2xl p-6"
                style={{
                  background: 'white',
                  border: `2px solid ${brandColors.primary.gold}30`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <h3 className="text-xl font-black mb-4" style={{ color: brandColors.text.primary }}>
                  الإحصائيات
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span style={{ color: brandColors.text.secondary }}>حجوزات قيد المعالجة</span>
                    <span className="text-xl font-black text-blue-500">{stats.pendingReservations}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span style={{ color: brandColors.text.secondary }}>حجوزات مكتملة</span>
                    <span className="text-xl font-black text-green-500">{stats.completedReservations}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span style={{ color: brandColors.text.secondary }}>معدل السعر للشجرة</span>
                    <span className="text-xl font-black" style={{ color: brandColors.primary.gold }}>
                      {stats.totalTrees > 0 ? Math.round(stats.totalAmount / stats.totalTrees).toLocaleString('ar-SA') : 0} ر.س
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'reservations' && (
          <div>
            <h2 className="text-3xl font-black mb-6" style={{ color: brandColors.text.primary }}>
              حجوزاتي الحالية
            </h2>

            {reservations.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: brandColors.text.secondary }} />
                <p className="text-xl" style={{ color: brandColors.text.secondary }}>
                  لا توجد حجوزات حالياً
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {reservations.map((reservation) => {
                  const bookingStatus = (reservation as any).booking_status || 'temporary';
                  const statusInfo = getStatusInfo(bookingStatus, reservation.id);
                  const StatusIcon = statusInfo.icon;

                  return (
                    <div
                      key={reservation.id}
                      className="rounded-2xl p-6 transition-all hover:scale-[1.02]"
                      style={{
                        background: 'white',
                        border: `2px solid ${statusInfo.color}30`,
                        boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                      }}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <h3 className="text-xl font-black" style={{ color: brandColors.text.primary }}>
                          {reservation.farm_name}
                        </h3>
                        <div
                          className="px-3 py-1 rounded-full flex items-center gap-2"
                          style={{ background: `${statusInfo.color}20` }}
                        >
                          <StatusIcon className="w-4 h-4" style={{ color: statusInfo.color }} />
                          <span className="text-sm font-bold" style={{ color: statusInfo.color }}>
                            {statusInfo.label}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                            نوع المزرعة
                          </span>
                          <span className="font-bold" style={{ color: brandColors.text.primary }}>
                            {reservation.farm_type}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                            عدد الأشجار
                          </span>
                          <span className="font-bold" style={{ color: brandColors.text.primary }}>
                            {reservation.number_of_trees.toLocaleString('ar-SA')}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                            المبلغ الإجمالي
                          </span>
                          <span className="font-black text-lg" style={{ color: brandColors.primary.gold }}>
                            {reservation.total_amount.toLocaleString('ar-SA')} ر.س
                          </span>
                        </div>

                        <div
                          className="pt-3 mt-3"
                          style={{ borderTop: `1px solid ${brandColors.primary.gold}20` }}
                        >
                          <p className="text-xs" style={{ color: brandColors.text.secondary }}>
                            تاريخ الحجز: {new Date(reservation.created_at).toLocaleDateString('ar-SA')}
                          </p>
                        </div>

                        <div className="mt-4">
                          <ProgressTracker bookingStatus={bookingStatus} />
                        </div>

                        {bookingStatus === 'pending_verification' && (
                          <div className="mt-4">
                            <div
                              className="p-4 rounded-xl text-center"
                              style={{
                                background: 'linear-gradient(135deg, rgba(16,185,129,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                                border: '2px solid rgba(16,185,129,0.3)',
                              }}
                            >
                              <p className="text-sm font-bold text-green-700 leading-relaxed">
                                🌿 شكرًا لإتمامك الخطوة الثانية!<br/>
                                تم استلام إيصال السداد، وسيتم التحقق منه خلال 24 ساعة بإذن الله.
                              </p>
                            </div>
                          </div>
                        )}

                        {bookingStatus === 'ownership_completed' && (
                          <div className="mt-4">
                            <div
                              className="p-4 rounded-xl text-center mb-3"
                              style={{
                                background: brandGradients.gold,
                                boxShadow: '0 8px 25px rgba(212,175,55,0.3)',
                              }}
                            >
                              <p className="text-base font-bold text-white leading-relaxed">
                                🎉 مبروك! اكتملت رحلة التملك وتم إصدار الشهادة بنجاح.
                              </p>
                            </div>
                            <button
                              onClick={() => setActiveTab('certificates')}
                              className="w-full px-4 py-3 rounded-xl font-bold text-white transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
                              style={{
                                background: brandGradients.gold,
                                boxShadow: '0 4px 15px rgba(212,175,55,0.3)'
                              }}
                            >
                              <Award className="w-5 h-5" />
                              📜 عرض الشهادة الذهبية
                            </button>
                          </div>
                        )}

                        {bookingStatus === 'documented' && (
                          <div className="mt-4">
                            <div
                              className="p-4 rounded-xl text-center"
                              style={{
                                background: 'linear-gradient(135deg, rgba(59,130,246,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                                border: '2px solid rgba(59,130,246,0.3)',
                              }}
                            >
                              <p className="text-sm font-bold text-blue-700 leading-relaxed">
                                📜 تم توثيق ملكيتك بشكل نهائي. يمكنك تحميل المستندات الرسمية.
                              </p>
                            </div>
                          </div>
                        )}

                        {bookingStatus === 'approved' && (
                          <div className="mt-4 space-y-3">
                            {receiptsMap[reservation.id]?.length > 0 ? (
                              <div className="space-y-2">
                                {receiptsMap[reservation.id].map(receipt => (
                                  <div
                                    key={receipt.id}
                                    className="p-3 rounded-xl flex items-center justify-between"
                                    style={{
                                      background: `${PaymentReceiptService.getStatusColor(receipt.status)}10`,
                                      border: `1px solid ${PaymentReceiptService.getStatusColor(receipt.status)}30`
                                    }}
                                  >
                                    <span
                                      className="text-sm font-bold"
                                      style={{ color: PaymentReceiptService.getStatusColor(receipt.status) }}
                                    >
                                      {PaymentReceiptService.getStatusLabel(receipt.status)}
                                    </span>
                                    <span className="text-xs" style={{ color: brandColors.text.secondary }}>
                                      {new Date(receipt.created_at).toLocaleDateString('ar-SA')}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <>
                                <div
                                  className="p-4 rounded-xl text-center animate-fade-in"
                                  style={{
                                    background: brandGradients.gold,
                                    boxShadow: '0 8px 25px rgba(212,175,55,0.25)',
                                  }}
                                >
                                  <p
                                    className="text-base font-semibold leading-relaxed"
                                    style={{
                                      color: 'white',
                                      textShadow: '0 2px 4px rgba(0,0,0,0.1)',
                                      fontFamily: 'Cairo, Noto Sans Arabic, sans-serif'
                                    }}
                                  >
                                    🌟 مبروك! تمت الموافقة على حجزك رسميًا — يمكنك الآن استكمال التملك برفع إيصال السداد.
                                  </p>
                                </div>

                                <button
                                  onClick={() => handleUploadReceipt(reservation)}
                                  className="w-full px-4 py-3 rounded-xl font-bold text-white transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
                                  style={{
                                    background: brandGradients.gold,
                                    boxShadow: '0 4px 15px rgba(212,175,55,0.3)'
                                  }}
                                >
                                  <Upload className="w-5 h-5" />
                                  رفع إيصال السداد البنكي
                                </button>
                              </>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === 'farms' && (
          <div>
            <h2 className="text-3xl font-black mb-6" style={{ color: brandColors.text.primary }}>
              مزارعي
            </h2>

            {farms.length === 0 ? (
              <div className="text-center py-12">
                <Trees className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: brandColors.text.secondary }} />
                <p className="text-xl" style={{ color: brandColors.text.secondary }}>
                  لا توجد مزارع حالياً
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {farms.map((farm) => (
                  <div
                    key={farm.farm_id}
                    className="rounded-2xl p-6 transition-all hover:scale-[1.02]"
                    style={{
                      background: 'linear-gradient(135deg, rgba(212,175,55,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                      border: `2px solid ${brandColors.primary.gold}30`,
                      boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                    }}
                  >
                    <Trees className="w-12 h-12 mb-4" style={{ color: brandColors.primary.gold }} />

                    <h3 className="text-2xl font-black mb-4" style={{ color: brandColors.text.primary }}>
                      {farm.farm_name}
                    </h3>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span style={{ color: brandColors.text.secondary }}>نوع المزرعة</span>
                        <span className="font-bold" style={{ color: brandColors.text.primary }}>
                          {farm.farm_type}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span style={{ color: brandColors.text.secondary }}>الأشجار المملوكة</span>
                        <span className="text-2xl font-black" style={{ color: brandColors.accent.olive }}>
                          {farm.total_trees.toLocaleString('ar-SA')}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span style={{ color: brandColors.text.secondary }}>قيمة الاستثمار</span>
                        <span className="text-xl font-black" style={{ color: brandColors.primary.gold }}>
                          {farm.total_amount.toLocaleString('ar-SA')} ر.س
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'certificates' && (
          <div>
            <h2 className="text-3xl font-black mb-6" style={{ color: brandColors.text.primary }}>
              شهادات التملك
            </h2>

            {certificates.length === 0 ? (
              <div className="text-center py-12">
                <Award className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: brandColors.text.secondary }} />
                <p className="text-xl mb-2" style={{ color: brandColors.text.secondary }}>
                  لا توجد شهادات حالياً
                </p>
                <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                  سيتم إصدار الشهادات فور اعتماد الحجوزات
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {certificates.map((cert: any) => (
                  <div
                    key={cert.id}
                    className="rounded-2xl p-6 transform transition-all hover:scale-[1.02]"
                    style={{
                      background: brandGradients.gold,
                      border: `2px solid ${brandColors.primary.gold}`,
                      boxShadow: '0 8px 30px rgba(212,175,55,0.2)'
                    }}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <Award className="w-10 h-10" style={{ color: brandColors.primary.gold }} />
                        <div>
                          <p className="text-sm font-bold" style={{ color: brandColors.text.secondary }}>
                            رقم الشهادة
                          </p>
                          <p className="text-xl font-black" style={{ color: brandColors.text.primary }}>
                            {cert.certificate_code}
                          </p>
                        </div>
                      </div>
                      <div
                        className="px-3 py-1 rounded-full text-xs font-bold"
                        style={{
                          background: brandColors.status.success,
                          color: 'white'
                        }}
                      >
                        موثق
                      </div>
                    </div>

                    <div className="space-y-3 mb-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                          المزرعة
                        </span>
                        <span className="font-bold" style={{ color: brandColors.text.primary }}>
                          {cert.farm_name}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                          عدد الأشجار
                        </span>
                        <span className="font-bold" style={{ color: brandColors.text.primary }}>
                          {cert.reserved_trees.toLocaleString('ar-SA')}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                          القيمة الإجمالية
                        </span>
                        <span className="font-bold" style={{ color: brandColors.primary.gold }}>
                          {parseFloat(cert.total_price).toLocaleString('ar-SA')} ر.س
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm" style={{ color: brandColors.text.secondary }}>
                          تاريخ الإصدار
                        </span>
                        <span className="text-sm font-bold" style={{ color: brandColors.text.primary }}>
                          {new Date(cert.created_at).toLocaleDateString('ar-SA')}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedCertificate(cert);
                        setCertificateModalOpen(true);
                      }}
                      className="w-full py-3 rounded-xl font-bold text-white transition-all hover:scale-[1.02] flex items-center justify-center gap-2"
                      style={{ background: brandColors.primary.gold }}
                    >
                      <Award className="w-5 h-5" />
                      عرض الشهادة
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'financials' && stats && (
          <div>
            <h2 className="text-3xl font-black mb-6" style={{ color: brandColors.text.primary }}>
              حسابي المالي
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div
                className="rounded-2xl p-8"
                style={{
                  background: 'linear-gradient(135deg, rgba(168,85,247,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                  border: `2px solid rgba(168,85,247,0.3)`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <Wallet className="w-12 h-12 mb-4 text-purple-500" />
                <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                  إجمالي الاستثمار
                </p>
                <p className="text-5xl font-black text-purple-500 mb-4">
                  {stats.totalAmount.toLocaleString('ar-SA')}
                </p>
                <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                  ريال سعودي
                </p>
              </div>

              <div
                className="rounded-2xl p-8"
                style={{
                  background: 'linear-gradient(135deg, rgba(16,185,129,0.1) 0%, rgba(255,255,255,0.95) 100%)',
                  border: `2px solid rgba(16,185,129,0.3)`,
                  boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                }}
              >
                <Award className="w-12 h-12 mb-4 text-green-500" />
                <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                  إجمالي الأشجار
                </p>
                <p className="text-5xl font-black text-green-500 mb-4">
                  {stats.totalTrees.toLocaleString('ar-SA')}
                </p>
                <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                  شجرة
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'timeline' && (
          <div>
            <h2 className="text-3xl font-black mb-6" style={{ color: brandColors.text.primary }}>
              الجدول الزمني
            </h2>

            {timeline.length === 0 ? (
              <div className="text-center py-12">
                <Clock className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: brandColors.text.secondary }} />
                <p className="text-xl" style={{ color: brandColors.text.secondary }}>
                  لا توجد أحداث
                </p>
              </div>
            ) : (
              <div className="relative">
                <div
                  className="absolute right-6 top-0 bottom-0 w-0.5"
                  style={{ background: brandColors.primary.gold + '30' }}
                />

                <div className="space-y-6">
                  {timeline.map((event) => (
                    <div key={event.id} className="relative pr-16">
                      <div
                        className="absolute right-0 w-12 h-12 rounded-full flex items-center justify-center"
                        style={{ background: brandGradients.gold }}
                      >
                        <span className="text-2xl">{event.icon}</span>
                      </div>

                      <div
                        className="rounded-2xl p-6"
                        style={{
                          background: 'white',
                          border: `2px solid ${brandColors.primary.gold}30`,
                          boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                        }}
                      >
                        <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                          {new Date(event.date).toLocaleDateString('ar-SA', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                        <h3 className="text-xl font-black mb-2" style={{ color: brandColors.text.primary }}>
                          {event.title}
                        </h3>
                        <p style={{ color: brandColors.text.secondary }}>
                          {event.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'notifications' && (
          <div>
            <h2 className="text-3xl font-black mb-6" style={{ color: brandColors.text.primary }}>
              الإشعارات
            </h2>

            <div className="text-center py-12">
              <Bell className="w-16 h-16 mx-auto mb-4 opacity-30" style={{ color: brandColors.text.secondary }} />
              <p className="text-xl" style={{ color: brandColors.text.secondary }}>
                لا توجد إشعارات جديدة
              </p>
            </div>
          </div>
        )}
      </div>

      {uploadModalOpen && selectedReservation && (
        <PaymentReceiptUploadModal
          reservationId={selectedReservation.id}
          reservationAmount={selectedReservation.total_amount}
          farmName={selectedReservation.farm_name}
          onClose={() => {
            setUploadModalOpen(false);
            setSelectedReservation(null);
          }}
          onSuccess={handleUploadSuccess}
        />
      )}

      {certificateModalOpen && selectedCertificate && (
        <CertificateModal
          certificate={selectedCertificate}
          isOpen={certificateModalOpen}
          onClose={() => {
            setCertificateModalOpen(false);
            setSelectedCertificate(null);
          }}
        />
      )}
    </div>
  );
}
