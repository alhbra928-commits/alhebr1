import React, { useEffect, useState } from 'react';
import { Calendar, CheckCircle, Clock, XCircle, DollarSign, Users, Wifi } from 'lucide-react';
import { Card3D } from '../../../components/ui/Card3D';
import { BackButton } from '../../../components/common/BackButton';
import { ReservationsService } from '../reservationsService';
import { useRealtimeTables } from '../../../lib/realtimeSync';

interface ReservationsViewProps {
  onBack?: () => void;
}

export function ReservationsView({ onBack }: ReservationsViewProps) {
  const [reservations, setReservations] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isRealtime, setIsRealtime] = useState(true);

  useEffect(() => {
    loadReservations();

    const unsubscribe = useRealtimeTables([
      {
        name: 'reservations',
        callbacks: {
          onInsert: () => {
            console.log('🔄 New reservation detected, reloading...');
            loadReservations();
          },
          onUpdate: () => {
            console.log('🔄 Reservation updated, reloading...');
            loadReservations();
          },
          onDelete: () => {
            console.log('🔄 Reservation deleted, reloading...');
            loadReservations();
          }
        }
      },
      {
        name: 'investors',
        callbacks: {
          onInsert: () => loadReservations(),
          onUpdate: () => loadReservations()
        }
      }
    ]);

    return () => unsubscribe();
  }, []);

  const loadReservations = async () => {
    try {
      console.log('🔄 loadReservations() called');
      setLoading(true);
      const [reservationsData, statsData] = await Promise.all([
        ReservationsService.getAll(),
        ReservationsService.getStatistics()
      ]);
      console.log('✅ Loaded reservations:', reservationsData);
      console.log('✅ Loaded stats:', statsData);
      console.log('📊 Reservations array length:', reservationsData?.length);
      console.log('📊 Reservations is Array?:', Array.isArray(reservationsData));

      setReservations(reservationsData || []);
      setStats(statsData);

      console.log('✅ State updated successfully');
    } catch (err) {
      console.error('❌ Error loading reservations:', err);
      setReservations([]);
      setStats(null);
    } finally {
      setLoading(false);
      console.log('✅ Loading complete');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const getStatusInfo = (status: string) => {
    const statusMap: any = {
      pending: { label: 'قيد الانتظار', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
      pending_contact: { label: 'بانتظار التواصل', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
      confirmed: { label: 'مؤكد', color: 'bg-blue-100 text-blue-700', icon: CheckCircle },
      active: { label: 'نشط', color: 'bg-green-100 text-green-700', icon: CheckCircle },
      completed: { label: 'مكتمل', color: 'bg-gray-100 text-gray-700', icon: CheckCircle },
      cancelled: { label: 'ملغي', color: 'bg-red-100 text-red-700', icon: XCircle },
    };
    return statusMap[status] || statusMap.pending;
  };

  console.log('🎨 Rendering ReservationsView');
  console.log('📊 Current reservations state:', reservations);
  console.log('📊 Reservations.length:', reservations.length);
  console.log('📊 Loading state:', loading);

  return (
    <div className="min-h-screen bg-[#F9F8F6] p-8" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {onBack && (
          <div className="mb-6">
            <BackButton onBack={onBack} />
          </div>
        )}

        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-black text-[#C89B3C] mb-2">إدارة الحجوزات</h1>
            <p className="text-[#2C2C2C]/70">متابعة وإدارة جميع حجوزات المستثمرين</p>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-green-50 rounded-lg border border-green-200">
            <Wifi className="w-5 h-5 text-green-600 animate-pulse" />
            <span className="text-sm font-bold text-green-600">مزامنة لحظية</span>
          </div>
        </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Calendar className="h-5 w-5 text-blue-600" />
              </div>
              <span className="text-2xl font-bold text-gray-900">{stats?.total || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">إجمالي الحجوزات</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
              <span className="text-2xl font-bold text-yellow-600">{stats?.pending || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">قيد الانتظار</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <span className="text-2xl font-bold text-green-600">{stats?.active || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">نشطة</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-purple-600" />
              </div>
              <span className="text-2xl font-bold text-purple-600">
                {((stats?.totalAmount || 0) / 1000).toFixed(0)}k
              </span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">إجمالي الإيرادات</h3>
          </div>
        </Card3D>

        <Card3D>
          <div className="p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Users className="h-5 w-5 text-orange-600" />
              </div>
              <span className="text-2xl font-bold text-orange-600">{stats?.totalTrees || 0}</span>
            </div>
            <h3 className="text-sm font-medium text-gray-600">أشجار محجوزة</h3>
          </div>
        </Card3D>
      </div>

      <div className="space-y-4">
        {reservations.length === 0 ? (
          <Card3D>
            <div className="p-12 text-center">
              <Calendar className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد حجوزات</h3>
              <p className="text-gray-600">لم يتم إضافة أي حجوزات بعد</p>
              <p className="text-xs text-gray-500 mt-2">عدد الحجوزات: {reservations.length}</p>
            </div>
          </Card3D>
        ) : (
          reservations.map((reservation) => {
            try {
              const statusInfo = getStatusInfo(reservation.status);
              const StatusIcon = statusInfo.icon;
              const pricePerTree = reservation.price_per_tree ? Number(reservation.price_per_tree) : 0;
              const totalAmount = reservation.total_amount ? Number(reservation.total_amount) : 0;

              return (
                <Card3D key={reservation.id}>
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-bold text-gray-900">
                            {reservation.customer_name || 'غير معروف'}
                          </h3>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${statusInfo.color}`}>
                            <StatusIcon className="h-3 w-3" />
                            {statusInfo.label}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">
                          المزرعة: {reservation.farms?.name_ar || 'غير متوفر'}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          رقم الحجز: {reservation.id.slice(0, 8)}
                        </p>
                      </div>
                      <div className="text-left">
                        <p className="text-2xl font-bold text-gray-900">
                          {totalAmount.toLocaleString('ar-SA')} ريال
                        </p>
                        <p className="text-xs text-gray-500">المبلغ الإجمالي</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600 mb-1">عدد الأشجار</p>
                        <p className="text-sm font-semibold text-gray-900">{reservation.number_of_trees || 0}</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600 mb-1">سعر الشجرة</p>
                        <p className="text-sm font-semibold text-gray-900">
                          {pricePerTree.toLocaleString('ar-SA', { maximumFractionDigits: 2 })} ريال
                        </p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600 mb-1">حالة الدفع</p>
                        <p className="text-sm font-semibold text-gray-900">
                          {reservation.payment_status === 'paid' ? 'مدفوع' : 'معلق'}
                        </p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600 mb-1">تاريخ الحجز</p>
                        <p className="text-sm font-semibold text-gray-900">
                          {new Date(reservation.created_at).toLocaleDateString('ar-SA')}
                        </p>
                      </div>
                    </div>
                  </div>
                </Card3D>
              );
            } catch (error) {
              console.error('Error rendering reservation:', reservation, error);
              return null;
            }
          })
        )}
      </div>
    </div>
  );
}
