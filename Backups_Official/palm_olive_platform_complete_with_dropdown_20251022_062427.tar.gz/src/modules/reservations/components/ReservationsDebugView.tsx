import { useState, useEffect } from 'react';
import { supabase } from '../../../lib/supabase';
import { ReservationsService } from '../reservationsService';

export function ReservationsDebugView() {
  const [directQuery, setDirectQuery] = useState<any>(null);
  const [serviceQuery, setServiceQuery] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    runTests();
  }, []);

  const runTests = async () => {
    console.log('🔍 Starting diagnostic tests...');

    try {
      console.log('1️⃣ Test: Direct Supabase Query');
      const { data: directData, error: directError } = await supabase
        .from('reservations')
        .select('*')
        .is('deleted_at', null);

      setDirectQuery({ data: directData, error: directError });
      console.log('Direct query result:', { data: directData, error: directError });

      console.log('2️⃣ Test: ReservationsService.getAll()');
      const serviceData = await ReservationsService.getAll();
      setServiceQuery({ data: serviceData });
      console.log('Service result:', serviceData);

      console.log('3️⃣ Test: ReservationsService.getStatistics()');
      const statsData = await ReservationsService.getStatistics();
      setStats(statsData);
      console.log('Statistics result:', statsData);

    } catch (error) {
      console.error('❌ Test failed:', error);
      setServiceQuery({ error });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8 bg-gray-50 min-h-screen" dir="rtl">
        <h1 className="text-3xl font-bold mb-4">تشخيص الحجوزات</h1>
        <div className="bg-white p-6 rounded-lg shadow">
          <p>جاري الفحص...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 bg-gray-50 min-h-screen" dir="rtl">
      <h1 className="text-3xl font-bold mb-6">تشخيص الحجوزات</h1>

      <div className="space-y-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">1️⃣ استعلام مباشر (Direct Query)</h2>
          <div className="bg-gray-100 p-4 rounded overflow-auto max-h-64">
            <pre className="text-sm">{JSON.stringify(directQuery, null, 2)}</pre>
          </div>
          <div className="mt-2">
            {directQuery?.error ? (
              <p className="text-red-600 font-bold">❌ خطأ في الاستعلام المباشر</p>
            ) : (
              <p className="text-green-600 font-bold">
                ✅ نجح: {directQuery?.data?.length || 0} حجز
              </p>
            )}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">2️⃣ خدمة الحجوزات (Service)</h2>
          <div className="bg-gray-100 p-4 rounded overflow-auto max-h-64">
            <pre className="text-sm">{JSON.stringify(serviceQuery, null, 2)}</pre>
          </div>
          <div className="mt-2">
            {serviceQuery?.error ? (
              <p className="text-red-600 font-bold">❌ خطأ في الخدمة</p>
            ) : (
              <p className="text-green-600 font-bold">
                ✅ نجح: {serviceQuery?.data?.length || 0} حجز
              </p>
            )}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">3️⃣ الإحصائيات</h2>
          <div className="bg-gray-100 p-4 rounded overflow-auto">
            <pre className="text-sm">{JSON.stringify(stats, null, 2)}</pre>
          </div>
        </div>

        <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-200">
          <h2 className="text-xl font-bold mb-4">معلومات الاتصال</h2>
          <div className="space-y-2">
            <p><strong>URL:</strong> {import.meta.env.VITE_SUPABASE_URL}</p>
            <p><strong>Key:</strong> {import.meta.env.VITE_SUPABASE_ANON_KEY?.substring(0, 20)}...</p>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <button
          onClick={runTests}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-blue-700"
        >
          🔄 إعادة الاختبار
        </button>
      </div>
    </div>
  );
}
