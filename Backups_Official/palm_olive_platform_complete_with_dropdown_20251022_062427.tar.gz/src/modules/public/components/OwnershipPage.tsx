import { useState, useEffect } from 'react';
import { ArrowRight, Plus, Minus, AlertCircle, CheckCircle2, Loader, User, Phone, Sparkles, Trash2, ChevronDown } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';
import { FarmDetailService, FarmVariety } from '../services/farmDetailService';

const ERROR_COLOR = '#E57373';

interface AddedVariety {
  id: string;
  variety: FarmVariety;
  quantity: number;
  subtotal: number;
}

interface OwnershipPageProps {
  farmId: string;
  farmName: string;
  farmType: string;
  onBack: () => void;
  onConfirm: (data: any) => void;
}

export function OwnershipPage({ farmId, farmName, farmType, onBack, onConfirm }: OwnershipPageProps) {
  const [availableVarieties, setAvailableVarieties] = useState<FarmVariety[]>([]);
  const [addedVarieties, setAddedVarieties] = useState<AddedVariety[]>([]);

  // Current selection in the card
  const [selectedVarietyId, setSelectedVarietyId] = useState<string>('');
  const [selectedQuantity, setSelectedQuantity] = useState<number>(0);

  const [investorData, setInvestorData] = useState({
    fullName: '',
    phone: '+966'
  });
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [step, setStep] = useState<'varieties' | 'data'>('varieties');

  const MAX_VARIETIES = 20;
  const isOlive = farmType?.toLowerCase().includes('زيتون');

  console.log('🔍 OwnershipPage mounted!');
  console.log('🔍 Props:', { farmId, farmName, farmType, step });
  console.log('🔍 State:', { loading, error, varietiesLength: availableVarieties.length });

  useEffect(() => {
    console.log('🔄 useEffect triggered! farmId:', farmId);
    loadVarieties();
  }, [farmId]);

  const loadVarieties = async () => {
    try {
      setLoading(true);
      setError('');

      const farmData = await FarmDetailService.getFarmById(farmId);

      if (!farmData) {
        setError('لم يتم العثور على المزرعة');
        setLoading(false);
        return;
      }

      if (!farmData.varieties || farmData.varieties.length === 0) {
        setError('لا توجد أصناف متاحة لهذه المزرعة. يرجى التواصل مع الإدارة.');
        setLoading(false);
        return;
      }

      setAvailableVarieties(farmData.varieties);
    } catch (err) {
      console.error('❌ Error loading varieties:', err);
      setError('حدث خطأ أثناء تحميل الأصناف');
    } finally {
      setLoading(false);
    }
  };

  const getSelectedVariety = (): FarmVariety | undefined => {
    return availableVarieties.find(v => v.id === selectedVarietyId);
  };

  const addVariety = () => {
    const variety = getSelectedVariety();
    if (!variety || selectedQuantity <= 0) {
      setErrors({ general: 'الرجاء اختيار صنف وإدخال الكمية' });
      return;
    }

    if (selectedQuantity > variety.available_quantity) {
      setErrors({ general: `الكمية المتاحة لهذا الصنف: ${variety.available_quantity}` });
      return;
    }

    if (addedVarieties.length >= MAX_VARIETIES) {
      setErrors({ general: `الحد الأقصى ${MAX_VARIETIES} صنف` });
      return;
    }

    const newAddedVariety: AddedVariety = {
      id: Date.now().toString(),
      variety,
      quantity: selectedQuantity,
      subtotal: selectedQuantity * variety.price_per_tree
    };

    setAddedVarieties([...addedVarieties, newAddedVariety]);
    setSelectedVarietyId('');
    setSelectedQuantity(0);
    setErrors({});
  };

  const removeVariety = (id: string) => {
    setAddedVarieties(addedVarieties.filter(v => v.id !== id));
  };

  const getTotalQuantity = () => {
    return addedVarieties.reduce((sum, v) => sum + v.quantity, 0);
  };

  const getTotalPrice = () => {
    return addedVarieties.reduce((sum, v) => sum + v.subtotal, 0);
  };

  const validateInvestorData = (): boolean => {
    const newErrors: {[key: string]: string} = {};

    if (!investorData.fullName.trim()) {
      newErrors.fullName = 'الرجاء إدخال الاسم الكامل';
    }

    if (!investorData.phone || investorData.phone === '+966' || investorData.phone.length < 13) {
      newErrors.phone = 'الرجاء إدخال رقم جوال صحيح';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinueToData = () => {
    if (addedVarieties.length === 0) {
      setErrors({ general: 'الرجاء إضافة صنف واحد على الأقل' });
      return;
    }
    setErrors({});
    setStep('data');
  };

  const handleConfirm = () => {
    if (!validateInvestorData()) {
      return;
    }

    onConfirm({
      farmId,
      investorData,
      varieties: addedVarieties.map(av => ({
        ...av.variety,
        selectedQuantity: av.quantity,
        subtotal: av.subtotal
      })),
      totalQuantity: getTotalQuantity(),
      totalPrice: getTotalPrice()
    });
  };

  console.log('📊 Render state:', { loading, error, varietiesCount: availableVarieties.length, step });

  // TEST: Always show something to debug
  if (loading) {
    console.log('⏳ Showing loading screen');
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: brandGradients.beige }}
        dir="rtl"
      >
        <div className="text-center">
          <Loader
            className="h-12 w-12 animate-spin mx-auto mb-4"
            style={{ color: brandColors.primary.gold }}
          />
          <p className="text-xl font-bold" style={{ color: brandColors.text.primary }}>
            جاري تحميل الأصناف...
          </p>
          <p className="text-sm mt-4" style={{ color: brandColors.text.secondary }}>
            Farm ID: {farmId}
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    console.log('❌ Showing error screen:', error);
    return (
      <div
        className="min-h-screen flex items-center justify-center p-6"
        style={{ background: brandGradients.beige }}
        dir="rtl"
      >
        <div className="text-center">
          <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: ERROR_COLOR }} />
          <p className="text-2xl font-bold mb-4" style={{ color: brandColors.text.primary }}>
            {error}
          </p>
          <button
            onClick={onBack}
            className="px-8 py-3 rounded-xl font-bold text-white transition-all hover:scale-105"
            style={{ background: brandGradients.gold }}
          >
            العودة
          </button>
        </div>
      </div>
    );
  }

  console.log('✅ Rendering main content, step:', step);

  return (
    <div
      className="min-h-screen"
      style={{ background: brandGradients.beige }}
      dir="rtl"
    >
      <div
        className="sticky top-0 z-50 backdrop-blur-lg border-b shadow-lg"
        style={{
          background: 'rgba(255, 255, 255, 0.98)',
          borderColor: brandColors.primary.gold + '30',
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-5 py-3 rounded-xl font-bold transition-all hover:scale-105 shadow-md"
            style={{
              color: brandColors.primary.gold,
              background: brandColors.primary.gold + '15',
            }}
          >
            <ArrowRight className="w-5 h-5" />
            <span>العودة</span>
          </button>

          <div className="text-center">
            <h1 className="text-3xl font-black mb-1" style={{ color: brandColors.primary.gold }}>
              {isOlive ? '🫒' : '🌴'} صفحة تحديد الأصناف وحجز التملك
            </h1>
            <p className="text-sm font-bold" style={{ color: brandColors.text.secondary }}>
              {farmName}
            </p>
          </div>

          <div className="flex items-center gap-3 px-5 py-3 rounded-xl shadow-md" style={{ background: brandColors.primary.gold + '15' }}>
            <Sparkles className="w-6 h-6" style={{ color: brandColors.primary.gold }} />
            <div className="text-right">
              <p className="text-xs font-bold" style={{ color: brandColors.text.secondary }}>الحد الأقصى</p>
              <p className="text-xl font-black" style={{ color: brandColors.primary.gold }}>
                {MAX_VARIETIES} صنف
              </p>
            </div>
          </div>
        </div>
      </div>

      {step === 'data' && (
        <div className="max-w-2xl mx-auto px-6 py-16">
          <div
            className="rounded-3xl p-10 shadow-2xl"
            style={{
              background: 'linear-gradient(135deg, rgba(255,255,255,0.98) 0%, rgba(245,240,230,0.98) 100%)',
              border: `3px solid ${brandColors.primary.gold}50`,
            }}
          >
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full mb-4" style={{ background: brandGradients.gold }}>
                <User className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-black mb-2" style={{ color: brandColors.text.primary }}>
                بيانات المستثمر
              </h2>
              <p className="text-lg" style={{ color: brandColors.text.secondary }}>
                الرجاء إدخال بياناتك لإتمام الحجز
              </p>
              <div className="mt-4 px-6 py-3 rounded-xl inline-block" style={{ background: brandColors.primary.gold + '15' }}>
                <p className="text-sm font-bold" style={{ color: brandColors.primary.gold }}>
                  تم اختيار {selectedVarietiesCount} صنف • {totalQuantity.toLocaleString('ar-SA')} شجرة
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <label className="flex items-center gap-2 text-base font-bold mb-3" style={{ color: brandColors.text.primary }}>
                  <User className="w-5 h-5" style={{ color: brandColors.primary.gold }} />
                  الاسم الكامل *
                </label>
                <input
                  type="text"
                  value={investorData.fullName}
                  onChange={(e) => setInvestorData({ ...investorData, fullName: e.target.value })}
                  placeholder="أدخل الاسم الكامل"
                  className="w-full px-6 py-5 rounded-2xl border-3 text-xl outline-none transition-all focus:scale-[1.02] shadow-md"
                  style={{
                    borderColor: errors.fullName ? ERROR_COLOR : brandColors.primary.gold + '40',
                    color: brandColors.text.primary,
                    fontWeight: 600,
                  }}
                />
                {errors.fullName && (
                  <p className="text-sm mt-3 flex items-center gap-2 font-bold" style={{ color: ERROR_COLOR }}>
                    <AlertCircle className="w-4 h-4" />
                    {errors.fullName}
                  </p>
                )}
              </div>

              <div>
                <label className="flex items-center gap-2 text-base font-bold mb-3" style={{ color: brandColors.text.primary }}>
                  <Phone className="w-5 h-5" style={{ color: brandColors.primary.gold }} />
                  رقم الجوال * (وسيلة الدخول للوحة المستثمر)
                </label>
                <input
                  type="tel"
                  value={investorData.phone}
                  onChange={(e) => setInvestorData({ ...investorData, phone: e.target.value })}
                  placeholder="+966XXXXXXXXX"
                  dir="ltr"
                  className="w-full px-6 py-5 rounded-2xl border-3 text-xl outline-none transition-all focus:scale-[1.02] shadow-md"
                  style={{
                    borderColor: errors.phone ? ERROR_COLOR : brandColors.primary.gold + '40',
                    color: brandColors.text.primary,
                    fontWeight: 600,
                  }}
                />
                {errors.phone && (
                  <p className="text-sm mt-3 flex items-center gap-2 font-bold" style={{ color: ERROR_COLOR }}>
                    <AlertCircle className="w-4 h-4" />
                    {errors.phone}
                  </p>
                )}
              </div>
            </div>

            <button
              onClick={handleConfirm}
              className="w-full mt-10 px-8 py-6 rounded-2xl font-black text-2xl text-white transition-all transform hover:scale-105 active:scale-95 shadow-2xl flex items-center justify-center gap-3"
              style={{ background: brandGradients.gold }}
            >
              <CheckCircle2 className="w-8 h-8" />
              <span>✅ تأكيد الحجز النهائي</span>
            </button>

            <button
              onClick={() => setStep('varieties')}
              className="w-full mt-4 px-8 py-4 rounded-2xl font-bold text-lg transition-all transform hover:scale-105"
              style={{
                color: brandColors.primary.gold,
                background: brandColors.primary.gold + '15',
              }}
            >
              ← العودة لتعديل الأصناف
            </button>
          </div>
        </div>
      )}

      {step === 'varieties' && (
        <>
          <div className="max-w-4xl mx-auto px-6 py-8 pb-48">
            {errors.general && (
              <div
                className="rounded-2xl p-5 mb-6 flex items-center gap-3 shadow-lg animate-pulse"
                style={{ background: ERROR_COLOR + '15', border: `3px solid ${ERROR_COLOR}` }}
              >
                <AlertCircle className="w-7 h-7 flex-shrink-0" style={{ color: ERROR_COLOR }} />
                <p className="text-xl font-black" style={{ color: ERROR_COLOR }}>{errors.general}</p>
              </div>
            )}

            {/* Selection Card */}
            <div
              className="rounded-3xl p-8 shadow-2xl mb-8"
              style={{
                background: 'rgba(255,255,255,0.98)',
                border: `3px solid ${brandColors.primary.gold}40`,
              }}
            >
              <div className="flex items-center gap-3 mb-6">
                <Sparkles className="w-8 h-8" style={{ color: brandColors.primary.gold }} />
                <h2 className="text-2xl font-black" style={{ color: brandColors.text.primary }}>
                  اختر الأصناف والكميات
                </h2>
              </div>

              {/* Variety Dropdown */}
              <div className="mb-6">
                <label className="block text-lg font-bold mb-3" style={{ color: brandColors.text.primary }}>
                  اختر الصنف
                </label>
                <div className="relative">
                  <select
                    value={selectedVarietyId}
                    onChange={(e) => setSelectedVarietyId(e.target.value)}
                    className="w-full px-6 py-4 text-xl font-bold rounded-2xl border-3 outline-none appearance-none cursor-pointer"
                    style={{
                      borderColor: brandColors.primary.gold + '60',
                      color: brandColors.text.primary,
                      background: 'white',
                    }}
                  >
                    <option value="">-- اختر صنف --</option>
                    {availableVarieties.map(variety => (
                      <option key={variety.id} value={variety.id}>
                        {variety.variety_name} ({variety.price_per_tree.toLocaleString('ar-SA')} ر.س)
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"
                    style={{ color: brandColors.primary.gold }}
                  />
                </div>
              </div>

              {/* Selected Variety Info */}
              {selectedVarietyId && getSelectedVariety() && (
                <div
                  className="p-6 rounded-2xl mb-6"
                  style={{ background: brandColors.primary.gold + '10', border: `2px solid ${brandColors.primary.gold}30` }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-base font-bold" style={{ color: brandColors.text.secondary }}>
                      السعر لكل شجرة:
                    </span>
                    <span className="text-2xl font-black" style={{ color: brandColors.primary.gold }}>
                      {getSelectedVariety()!.price_per_tree.toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-base font-bold" style={{ color: brandColors.text.secondary }}>
                      العدد المتاح:
                    </span>
                    <span className="text-xl font-black" style={{ color: brandColors.text.primary }}>
                      {getSelectedVariety()!.available_quantity.toLocaleString('ar-SA')} شجرة
                    </span>
                  </div>
                </div>
              )}

              {/* Quantity Input */}
              <div className="mb-6">
                <label className="block text-lg font-bold mb-3" style={{ color: brandColors.text.primary }}>
                  الكمية
                </label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setSelectedQuantity(Math.max(0, selectedQuantity - 1))}
                    disabled={selectedQuantity === 0}
                    className="w-16 h-16 rounded-2xl font-bold text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:scale-110 active:scale-90 flex items-center justify-center shadow-lg"
                    style={{ background: brandGradients.gold }}
                  >
                    <Minus className="w-8 h-8" />
                  </button>

                  <input
                    type="number"
                    value={selectedQuantity || ''}
                    onChange={(e) => setSelectedQuantity(parseInt(e.target.value) || 0)}
                    placeholder="0"
                    min="0"
                    max={getSelectedVariety()?.available_quantity || 0}
                    className="flex-1 text-center text-3xl font-black px-6 py-4 rounded-2xl border-3 outline-none transition-all focus:scale-105 shadow-md"
                    style={{
                      borderColor: brandColors.primary.gold,
                      color: brandColors.text.primary,
                      background: 'white',
                    }}
                  />

                  <button
                    onClick={() => {
                      const max = getSelectedVariety()?.available_quantity || 0;
                      setSelectedQuantity(Math.min(max, selectedQuantity + 1));
                    }}
                    disabled={!selectedVarietyId || selectedQuantity >= (getSelectedVariety()?.available_quantity || 0)}
                    className="w-16 h-16 rounded-2xl font-bold text-white transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:scale-110 active:scale-90 flex items-center justify-center shadow-lg"
                    style={{ background: brandGradients.gold }}
                  >
                    <Plus className="w-8 h-8" />
                  </button>
                </div>
              </div>

              {/* Subtotal */}
              {selectedVarietyId && selectedQuantity > 0 && (
                <div
                  className="p-6 rounded-2xl text-center mb-6"
                  style={{ background: brandColors.primary.gold + '15', border: `2px solid ${brandColors.primary.gold}` }}
                >
                  <p className="text-lg font-bold mb-2" style={{ color: brandColors.text.secondary }}>
                    المجموع الجزئي
                  </p>
                  <p className="text-3xl font-black" style={{ color: brandColors.primary.gold }}>
                    {(selectedQuantity * (getSelectedVariety()?.price_per_tree || 0)).toLocaleString('ar-SA')} ر.س
                  </p>
                </div>
              )}

              {/* Add Button */}
              <button
                onClick={addVariety}
                disabled={!selectedVarietyId || selectedQuantity === 0}
                className="w-full px-8 py-5 rounded-2xl font-black text-2xl text-white transition-all hover:scale-105 active:scale-95 shadow-xl disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                style={{ background: brandGradients.gold }}
              >
                <Plus className="w-7 h-7" />
                إضافة الصنف
              </button>
            </div>

            {/* Added Varieties List */}
            {addedVarieties.length > 0 && (
              <div>
                <h3 className="text-2xl font-black mb-4 flex items-center gap-3" style={{ color: brandColors.text.primary }}>
                  <CheckCircle2 className="w-7 h-7" style={{ color: brandColors.primary.gold }} />
                  الأصناف المضافة ({addedVarieties.length})
                </h3>

                <div className="space-y-4">
                  {addedVarieties.map((addedVariety) => (
                    <div
                      key={addedVariety.id}
                      className="rounded-2xl p-6 shadow-lg flex items-center gap-6"
                      style={{
                        background: 'linear-gradient(135deg, rgba(155,173,117,0.12) 0%, rgba(255,255,255,0.98) 100%)',
                        border: `2px solid ${brandColors.primary.gold}`,
                      }}
                    >
                      <span className="text-3xl">
                        {addedVariety.variety.tree_type?.toLowerCase().includes('نخيل') ? '🌴' : '🫒'}
                      </span>

                      <div className="flex-1">
                        <h4 className="text-xl font-black mb-2" style={{ color: brandColors.text.primary }}>
                          {addedVariety.variety.variety_name}
                        </h4>
                        <div className="flex items-center gap-4">
                          <span className="text-base font-bold" style={{ color: brandColors.text.secondary }}>
                            {addedVariety.quantity} شجرة × {addedVariety.variety.price_per_tree.toLocaleString('ar-SA')} ر.س
                          </span>
                          <span className="text-2xl font-black" style={{ color: brandColors.primary.gold }}>
                            = {addedVariety.subtotal.toLocaleString('ar-SA')} ر.س
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => removeVariety(addedVariety.id)}
                        className="w-12 h-12 rounded-xl flex items-center justify-center transition-all hover:scale-110 active:scale-90 shadow-md"
                        style={{ background: ERROR_COLOR, color: 'white' }}
                        title="حذف"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div
            className="fixed bottom-0 left-0 right-0 border-t backdrop-blur-lg z-50 shadow-2xl"
            style={{
              background: 'linear-gradient(135deg, rgba(212,175,55,0.98) 0%, rgba(194,155,46,0.98) 100%)',
              borderColor: brandColors.primary.gold,
            }}
          >
            <div className="max-w-7xl mx-auto px-6 py-8">
              <div className="flex items-center justify-between gap-8">
                <div className="flex-1 flex items-center gap-10">
                  <div>
                    <p className="text-sm mb-1 font-bold text-white/80">عدد الأصناف المضافة</p>
                    <p className="text-4xl font-black text-white">
                      {addedVarieties.length} / {MAX_VARIETIES}
                    </p>
                  </div>

                  <div className="h-16 w-px bg-white/30"></div>

                  <div>
                    <p className="text-sm mb-1 font-bold text-white/80">إجمالي الأشجار</p>
                    <p className="text-4xl font-black text-white">
                      {getTotalQuantity().toLocaleString('ar-SA')}
                    </p>
                  </div>

                  <div className="h-16 w-px bg-white/30"></div>

                  <div>
                    <p className="text-sm mb-1 font-bold text-white/80">💰 الإجمالي الكلي</p>
                    <p className="text-5xl font-black text-white drop-shadow-lg">
                      {getTotalPrice().toLocaleString('ar-SA')} ر.س
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleContinueToData}
                  disabled={addedVarieties.length === 0}
                  className="px-16 py-7 rounded-3xl font-black text-3xl transition-all transform hover:scale-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center gap-4 shadow-2xl"
                  style={{
                    background: addedVarieties.length > 0
                      ? 'linear-gradient(135deg, #ffffff 0%, #f5f0e6 100%)'
                      : 'rgba(255,255,255,0.3)',
                    color: addedVarieties.length > 0 ? brandColors.primary.gold : 'rgba(255,255,255,0.5)',
                    border: addedVarieties.length > 0 ? `3px solid white` : '3px solid rgba(255,255,255,0.3)',
                  }}
                >
                  <ArrowRight className="w-10 h-10" />
                  <span>المتابعة لإدخال البيانات</span>
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
