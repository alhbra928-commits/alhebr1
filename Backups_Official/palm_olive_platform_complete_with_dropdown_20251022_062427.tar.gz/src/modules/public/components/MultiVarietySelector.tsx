import { useState, useEffect } from 'react';
import { Plus, Minus, Check, AlertCircle, Trees } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';

interface Variety {
  id: string;
  tree_type: string;
  variety_name: string;
  variety_name_en: string;
  price_per_tree: number;
  available_quantity: number;
  total_trees: number;
  description_ar?: string;
}

interface SelectedVariety {
  variety_id: string;
  quantity: number;
  price_per_tree: number;
  subtotal: number;
  variety_name: string;
}

interface MultiVarietySelectorProps {
  varieties: Variety[];
  farmType: string;
  onSelectionChange: (selectedVarieties: SelectedVariety[], totalAmount: number, totalTrees: number) => void;
  maxVarieties?: number;
}

export function MultiVarietySelector({
  varieties,
  farmType,
  onSelectionChange,
  maxVarieties = 20
}: MultiVarietySelectorProps) {
  const [selectedVarieties, setSelectedVarieties] = useState<Map<string, SelectedVariety>>(new Map());
  const [activeTab, setActiveTab] = useState<'palm' | 'olive'>('palm');
  const [errors, setErrors] = useState<Map<string, string>>(new Map());

  const palmVarieties = varieties.filter(v => v.tree_type?.toLowerCase().includes('نخيل'));
  const oliveVarieties = varieties.filter(v => v.tree_type?.toLowerCase().includes('زيتون'));
  const isMixed = farmType?.toLowerCase().includes('مختلط') || (palmVarieties.length > 0 && oliveVarieties.length > 0);

  const displayVarieties = isMixed
    ? (activeTab === 'palm' ? palmVarieties : oliveVarieties)
    : varieties;

  useEffect(() => {
    const selected = Array.from(selectedVarieties.values());
    const totalAmount = selected.reduce((sum, item) => sum + item.subtotal, 0);
    const totalTrees = selected.reduce((sum, item) => sum + item.quantity, 0);
    onSelectionChange(selected, totalAmount, totalTrees);
  }, [selectedVarieties]);

  const handleQuantityChange = (variety: Variety, newQuantity: number) => {
    const newErrors = new Map(errors);

    if (newQuantity < 0) {
      newErrors.set(variety.id, 'العدد يجب أن يكون موجباً');
      setErrors(newErrors);
      return;
    }

    if (newQuantity > variety.available_quantity) {
      newErrors.set(variety.id, `الحد الأقصى المتاح: ${variety.available_quantity.toLocaleString('ar-SA')} شجرة`);
      setErrors(newErrors);
      return;
    }

    newErrors.delete(variety.id);
    setErrors(newErrors);

    const newSelected = new Map(selectedVarieties);

    if (newQuantity === 0) {
      newSelected.delete(variety.id);
    } else {
      newSelected.set(variety.id, {
        variety_id: variety.id,
        quantity: newQuantity,
        price_per_tree: variety.price_per_tree,
        subtotal: newQuantity * variety.price_per_tree,
        variety_name: variety.variety_name
      });
    }

    setSelectedVarieties(newSelected);
  };

  const handleCheckboxChange = (variety: Variety, checked: boolean) => {
    if (checked) {
      if (selectedVarieties.size >= maxVarieties) {
        const newErrors = new Map(errors);
        newErrors.set(variety.id, `الحد الأقصى ${maxVarieties} صنف فقط`);
        setErrors(newErrors);
        return;
      }
      handleQuantityChange(variety, 1);
    } else {
      handleQuantityChange(variety, 0);
    }
  };

  const incrementQuantity = (variety: Variety) => {
    const current = selectedVarieties.get(variety.id);
    const currentQty = current ? current.quantity : 0;
    handleQuantityChange(variety, currentQty + 1);
  };

  const decrementQuantity = (variety: Variety) => {
    const current = selectedVarieties.get(variety.id);
    const currentQty = current ? current.quantity : 0;
    if (currentQty > 0) {
      handleQuantityChange(variety, currentQty - 1);
    }
  };

  const totalAmount = Array.from(selectedVarieties.values()).reduce((sum, item) => sum + item.subtotal, 0);
  const totalTrees = Array.from(selectedVarieties.values()).reduce((sum, item) => sum + item.quantity, 0);
  const selectedCount = selectedVarieties.size;

  return (
    <div className="space-y-6" dir="rtl">
      {isMixed && (
        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('palm')}
            className={`flex-1 px-6 py-4 rounded-xl font-bold text-lg transition-all ${
              activeTab === 'palm'
                ? 'text-white shadow-lg'
                : 'bg-white/50 hover:bg-white/70'
            }`}
            style={activeTab === 'palm' ? { background: brandGradients.gold } : {}}
          >
            🌴 أصناف النخيل ({palmVarieties.length})
          </button>
          <button
            onClick={() => setActiveTab('olive')}
            className={`flex-1 px-6 py-4 rounded-xl font-bold text-lg transition-all ${
              activeTab === 'olive'
                ? 'text-white shadow-lg'
                : 'bg-white/50 hover:bg-white/70'
            }`}
            style={activeTab === 'olive' ? { background: brandGradients.olive } : {}}
          >
            🫒 أصناف الزيتون ({oliveVarieties.length})
          </button>
        </div>
      )}

      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 border-2" style={{ borderColor: brandColors.primary.gold }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Trees className="h-6 w-6" style={{ color: brandColors.primary.olive }} />
            <div>
              <h3 className="text-xl font-black" style={{ color: brandColors.text.primary }}>
                اختر الأصناف المطلوبة
              </h3>
              <p className="text-sm" style={{ color: brandColors.text.secondary }}>
                يمكنك اختيار حتى {maxVarieties} صنفاً من المزرعة
              </p>
            </div>
          </div>
          <div className="text-left">
            <div className="text-3xl font-black" style={{ color: brandColors.primary.gold }}>
              {selectedCount}/{maxVarieties}
            </div>
            <div className="text-xs" style={{ color: brandColors.text.secondary }}>
              صنف مختار
            </div>
          </div>
        </div>

        {displayVarieties.length === 0 ? (
          <div className="text-center py-12">
            <AlertCircle className="h-12 w-12 mx-auto mb-4" style={{ color: brandColors.text.secondary }} />
            <p className="text-lg font-bold" style={{ color: brandColors.text.secondary }}>
              لا توجد أصناف متاحة حالياً
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[600px] overflow-y-auto pr-2">
            {displayVarieties.map((variety) => {
              const selected = selectedVarieties.get(variety.id);
              const isSelected = !!selected;
              const currentQuantity = selected ? selected.quantity : 0;
              const error = errors.get(variety.id);

              return (
                <div
                  key={variety.id}
                  className={`relative rounded-xl p-5 border-2 transition-all duration-300 ${
                    isSelected
                      ? 'shadow-lg scale-[1.02]'
                      : 'bg-white/80 hover:bg-white hover:shadow-md'
                  }`}
                  style={{
                    borderColor: isSelected ? brandColors.primary.gold : '#e5e7eb',
                    background: isSelected ? brandGradients.lightGold : undefined
                  }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-3 flex-1">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => handleCheckboxChange(variety, e.target.checked)}
                        className="mt-1 w-5 h-5 rounded"
                        style={{ accentColor: brandColors.primary.gold }}
                      />
                      <div className="flex-1">
                        <h4 className="text-lg font-bold mb-1" style={{ color: brandColors.text.primary }}>
                          {variety.variety_name}
                        </h4>
                        {variety.description_ar && (
                          <p className="text-sm mb-2" style={{ color: brandColors.text.secondary }}>
                            {variety.description_ar}
                          </p>
                        )}
                        <div className="flex items-center gap-4 text-sm">
                          <span style={{ color: brandColors.primary.gold }} className="font-bold">
                            {variety.price_per_tree.toLocaleString('ar-SA')} ر.س / شجرة
                          </span>
                          <span style={{ color: brandColors.text.secondary }}>
                            متاح: {variety.available_quantity.toLocaleString('ar-SA')}
                          </span>
                        </div>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="flex items-center justify-center w-8 h-8 rounded-full" style={{ background: brandColors.primary.gold }}>
                        <Check className="h-5 w-5 text-white" />
                      </div>
                    )}
                  </div>

                  {isSelected && (
                    <div className="space-y-3 animate-fadeIn">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => decrementQuantity(variety)}
                          className="w-10 h-10 rounded-lg text-white font-black text-xl transition-all hover:scale-110 active:scale-95 shadow-md"
                          style={{ background: brandGradients.olive }}
                          disabled={currentQuantity <= 0}
                        >
                          <Minus className="h-5 w-5 mx-auto" />
                        </button>
                        <input
                          type="number"
                          value={currentQuantity}
                          onChange={(e) => handleQuantityChange(variety, parseInt(e.target.value) || 0)}
                          className="flex-1 text-center text-2xl font-black px-4 py-3 rounded-lg border-2"
                          style={{
                            borderColor: error ? '#ef4444' : brandColors.primary.gold,
                            color: brandColors.text.primary
                          }}
                          min="0"
                          max={variety.available_quantity}
                        />
                        <button
                          onClick={() => incrementQuantity(variety)}
                          className="w-10 h-10 rounded-lg text-white font-black text-xl transition-all hover:scale-110 active:scale-95 shadow-md"
                          style={{ background: brandGradients.gold }}
                          disabled={currentQuantity >= variety.available_quantity}
                        >
                          <Plus className="h-5 w-5 mx-auto" />
                        </button>
                      </div>

                      {error && (
                        <div className="flex items-center gap-2 p-2 bg-red-50 border border-red-300 rounded-lg">
                          <AlertCircle className="h-4 w-4 text-red-500" />
                          <span className="text-sm text-red-700 font-medium">{error}</span>
                        </div>
                      )}

                      <div className="p-3 rounded-lg" style={{ background: brandGradients.lightGold }}>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium" style={{ color: brandColors.text.secondary }}>
                            المجموع الجزئي:
                          </span>
                          <span className="text-xl font-black" style={{ color: brandColors.primary.gold }}>
                            {(currentQuantity * variety.price_per_tree).toLocaleString('ar-SA')} ر.س
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {selectedCount > 0 && (
        <div
          className="sticky bottom-0 p-6 rounded-2xl shadow-2xl border-2 animate-slideUp"
          style={{
            background: brandGradients.gold,
            borderColor: brandColors.primary.gold
          }}
        >
          <div className="grid grid-cols-3 gap-6 text-white">
            <div className="text-center">
              <div className="text-sm opacity-90 mb-2">عدد الأصناف</div>
              <div className="text-3xl font-black">{selectedCount}</div>
              <div className="text-xs opacity-75">صنف</div>
            </div>
            <div className="text-center">
              <div className="text-sm opacity-90 mb-2">إجمالي الأشجار</div>
              <div className="text-3xl font-black">{totalTrees.toLocaleString('ar-SA')}</div>
              <div className="text-xs opacity-75">شجرة</div>
            </div>
            <div className="text-center">
              <div className="text-sm opacity-90 mb-2">المجموع الكلي</div>
              <div className="text-4xl font-black">{totalAmount.toLocaleString('ar-SA')}</div>
              <div className="text-xs opacity-75">ريال سعودي</div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }

        .animate-slideUp {
          animation: slideUp 0.4s ease-out;
        }

        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }

        input[type="number"] {
          -moz-appearance: textfield;
        }
      `}</style>
    </div>
  );
}
