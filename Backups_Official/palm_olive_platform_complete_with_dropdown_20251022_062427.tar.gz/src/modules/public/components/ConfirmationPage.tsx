import { CheckCircle2, Home, User, MessageCircle } from 'lucide-react';
import { brandColors, brandGradients } from '../../finance/styles/brandColors';

interface ConfirmationPageProps {
  farmName: string;
  farmType: string;
  totalQuantity: number;
  totalPrice: number;
  investorPhone: string;
  onGoHome: () => void;
  onGoToInvestorPanel: () => void;
  onContactSales: () => void;
}

export function ConfirmationPage({
  farmName,
  farmType,
  totalQuantity,
  totalPrice,
  investorPhone,
  onGoHome,
  onGoToInvestorPanel,
  onContactSales,
}: ConfirmationPageProps) {
  const isOlive = farmType?.toLowerCase().includes('زيتون');

  return (
    <div
      className="min-h-screen flex items-center justify-center p-6"
      style={{
        background: 'linear-gradient(135deg, #2d3436 0%, #1e272e 100%)',
      }}
      dir="rtl"
    >
      <div className="max-w-2xl w-full">
        <div
          className="rounded-3xl p-12 text-center relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(212,175,55,0.1) 0%, rgba(255,255,255,0.05) 100%)',
            border: `2px solid ${brandColors.primary.gold}40`,
            boxShadow: '0 30px 80px rgba(0,0,0,0.5)',
          }}
        >
          <div
            className="absolute inset-0 opacity-10"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(212,175,55,0.3) 0%, transparent 70%)',
            }}
          />

          <div className="relative z-10">
            <div
              className="w-32 h-32 rounded-full mx-auto mb-8 flex items-center justify-center animate-bounce"
              style={{
                background: brandGradients.gold,
                boxShadow: '0 20px 60px rgba(212,175,55,0.5)',
              }}
            >
              <CheckCircle2 className="w-20 h-20 text-white" />
            </div>

            <div className="mb-8">
              <div
                className="w-3 h-3 rounded-full mx-auto mb-4 animate-pulse"
                style={{ background: brandGradients.gold }}
              />
              <h1
                className="text-5xl font-black mb-4"
                style={{
                  background: brandGradients.gold,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                تم تأكيد حجز تملك أشجارك بنجاح
              </h1>
              <p className="text-2xl font-bold text-white opacity-90 mb-2">
                {isOlive ? '🫒' : '🌴'} {farmName}
              </p>
            </div>

            <div
              className="rounded-2xl p-8 mb-8"
              style={{
                background: 'rgba(212,175,55,0.1)',
                border: `1px solid ${brandColors.primary.gold}30`,
              }}
            >
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <p className="text-sm text-gray-400 mb-2">عدد الأشجار</p>
                  <p className="text-4xl font-black" style={{ color: brandColors.primary.gold }}>
                    {totalQuantity.toLocaleString('ar-SA')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-2">المبلغ الإجمالي</p>
                  <p className="text-4xl font-black" style={{ color: brandColors.primary.gold }}>
                    {totalPrice.toLocaleString('ar-SA')} ر.س
                  </p>
                </div>
              </div>

              <div
                className="p-4 rounded-xl"
                style={{ background: 'rgba(0,0,0,0.2)' }}
              >
                <p className="text-sm text-gray-400 mb-2">رقم الجوال المسجل</p>
                <p className="text-xl font-bold text-white">{investorPhone}</p>
              </div>
            </div>

            <div
              className="rounded-2xl p-6 mb-8"
              style={{
                background: 'rgba(74,222,128,0.1)',
                border: '1px solid rgba(74,222,128,0.3)',
              }}
            >
              <p className="text-lg font-bold text-white leading-relaxed">
                سيتم التواصل معك فور اكتمال الحجز للمزرعة
              </p>
            </div>

            <div
              className="rounded-xl p-4 mb-8"
              style={{ background: 'rgba(212,175,55,0.05)' }}
            >
              <p className="text-sm text-gray-400">
                💡 رقم جوالك هو وسيلة دخولك إلى لوحة المستثمر
              </p>
            </div>

            <div className="space-y-4">
              <button
                onClick={onGoHome}
                className="w-full py-5 rounded-2xl font-bold text-xl text-white transition-all hover:scale-[1.02] flex items-center justify-center gap-3"
                style={{
                  background: brandGradients.gold,
                  boxShadow: '0 10px 40px rgba(212,175,55,0.3)',
                }}
              >
                <Home className="w-6 h-6" />
                <span>العودة للواجهة الرئيسية</span>
              </button>

              <button
                onClick={onGoToInvestorPanel}
                className="w-full py-5 rounded-2xl font-bold text-xl transition-all hover:scale-[1.02] flex items-center justify-center gap-3"
                style={{
                  background: 'rgba(255,255,255,0.1)',
                  color: 'white',
                  border: '2px solid rgba(255,255,255,0.2)',
                }}
              >
                <User className="w-6 h-6" />
                <span>الدخول إلى لوحة المستثمر</span>
              </button>

              <button
                onClick={onContactSales}
                className="w-full py-5 rounded-2xl font-bold text-xl transition-all hover:scale-[1.02] flex items-center justify-center gap-3"
                style={{
                  background: 'rgba(37,211,102,0.15)',
                  color: '#25D366',
                  border: '2px solid rgba(37,211,102,0.3)',
                }}
              >
                <MessageCircle className="w-6 h-6" />
                <span>التواصل مع المبيعات</span>
              </button>
            </div>
          </div>

          <div
            className="absolute -top-20 -left-20 w-40 h-40 rounded-full opacity-20 blur-3xl"
            style={{ background: brandColors.primary.gold }}
          />
          <div
            className="absolute -bottom-20 -right-20 w-40 h-40 rounded-full opacity-20 blur-3xl"
            style={{ background: brandColors.primary.gold }}
          />
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            © 2025 منصة النخيل والزيتون - جميع الحقوق محفوظة
          </p>
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-20px); }
        }
      `}</style>
    </div>
  );
}
