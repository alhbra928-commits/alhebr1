import { supabase } from '../../../lib/supabase';

export interface FarmVariety {
  id: string;
  farm_id: string;
  tree_type: string;
  variety_name: string;
  variety_name_en: string;
  price_per_tree: number;
  available_quantity: number;
  max_booking_per_investor: number;
  total_trees: number;
  description_ar?: string;
  description_en?: string;
}

export interface FarmDetail {
  id: string;
  farm_code: string;
  name_ar: string;
  name_en: string;
  farm_type: string;
  city: string;
  region: string;
  total_area: number;
  total_trees: number;
  available_trees: number;
  price_per_tree: number;
  description_ar?: string;
  description_en?: string;
  aerial_map_url?: string;
  google_map_link?: string;
  latitude?: number;
  longitude?: number;
  status: string;
  varieties: FarmVariety[];
}

export interface ReservationVariety {
  variety_id: string;
  tree_count: number;
  price_per_tree: number;
}

export interface CreateReservationData {
  farm_id: string;
  investor_name: string;
  investor_phone: string;
  varieties: ReservationVariety[];
  total_trees: number;
  total_amount: number;
}

export class FarmDetailService {
  static async getFarmById(farmId: string): Promise<FarmDetail | null> {
    try {
      let farm = null;

      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(farmId);

      if (isUUID) {
        const { data, error } = await supabase
          .from('farms')
          .select('*')
          .eq('id', farmId)
          .maybeSingle();

        if (error) throw error;
        farm = data;
      } else {
        const { data, error } = await supabase
          .from('farms')
          .select('*')
          .eq('farm_code', farmId)
          .maybeSingle();

        if (error) throw error;
        farm = data;
      }

      if (!farm) return null;

      console.log('🔍 Querying farm_tree_varieties for farm_id:', farm.id);

      const { data: varieties, error: varietiesError } = await supabase
        .from('farm_tree_varieties')
        .select('*')
        .eq('farm_id', farm.id)
        .is('deleted_at', null)
        .gt('available_quantity', 0)
        .order('tree_type', { ascending: true })
        .order('variety_name', { ascending: true });

      console.log('📊 Query result:', {
        varietiesCount: varieties?.length || 0,
        error: varietiesError,
        varieties: varieties
      });

      if (varietiesError) {
        console.error('❌ Error loading varieties:', varietiesError);
        throw varietiesError;
      }

      console.log(`✅ Loaded ${varieties?.length || 0} varieties for farm ${farm.name_ar}`);

      return {
        id: farm.id,
        farm_code: farm.farm_code || `FARM-${farm.id.slice(0, 8)}`,
        name_ar: farm.name_ar,
        name_en: farm.name_en,
        farm_type: farm.farm_type,
        city: farm.city,
        region: farm.region,
        total_area: farm.total_area || 0,
        total_trees: farm.total_trees || 0,
        available_trees: farm.available_trees || 0,
        price_per_tree: farm.price_per_tree || 0,
        description_ar: farm.description_ar,
        description_en: farm.description_en,
        aerial_map_url: farm.aerial_map_url,
        google_map_link: farm.google_map_link,
        latitude: farm.latitude,
        longitude: farm.longitude,
        status: farm.status,
        varieties: varieties || []
      };
    } catch (error) {
      console.error('Error fetching farm details:', error);
      throw error;
    }
  }

  static async createReservation(data: CreateReservationData): Promise<any> {
    try {
      console.log('🔄 Creating reservation with data:', data);

      if (!data.varieties || data.varieties.length === 0) {
        throw new Error('يجب اختيار صنف واحد على الأقل');
      }

      if (data.varieties.length > 20) {
        throw new Error('الحد الأقصى 20 صنف في الحجز الواحد');
      }

      const avgPricePerTree = data.total_trees > 0
        ? data.total_amount / data.total_trees
        : 0;

      const reservation = {
        farm_id: data.farm_id,
        customer_name: data.investor_name,
        customer_phone: data.investor_phone,
        number_of_trees: data.total_trees,
        price_per_tree: avgPricePerTree,
        total_amount: data.total_amount,
        status: 'pending',
        booking_status: 'temporary',
        payment_status: 'pending',
        reservation_date: new Date().toISOString()
      };

      console.log('�� Reservation object:', reservation);

      const { data: reservationData, error: reservationError } = await supabase
        .from('reservations')
        .insert([reservation])
        .select()
        .single();

      if (reservationError) {
        console.error('❌ Reservation error:', reservationError);
        throw reservationError;
      }

      console.log('✅ Reservation created:', reservationData.id);

      const reservationId = reservationData.id;
      const bookingItems = data.varieties.map(v => ({
        reservation_id: reservationId,
        variety_id: v.variety_id,
        quantity: v.tree_count,
        price_per_tree: v.price_per_tree,
        subtotal: v.tree_count * v.price_per_tree
      }));

      console.log(`📋 Creating ${bookingItems.length} booking items for ${data.varieties.length} varieties...`);

      const { data: itemsData, error: itemsError } = await supabase
        .from('booking_items')
        .insert(bookingItems)
        .select();

      if (itemsError) {
        console.error('❌ Booking items error:', itemsError);
        await supabase.from('reservations').delete().eq('id', reservationId);
        throw itemsError;
      }

      console.log(`✅ Created ${itemsData.length} booking items successfully`);

      return {
        ...reservationData,
        booking_items: itemsData
      };
    } catch (error) {
      console.error('❌ Error creating reservation:', error);
      throw error;
    }
  }

  static async getAvailableTreesCount(farmId: string): Promise<number> {
    try {
      const { data, error } = await supabase
        .from('farm_tree_varieties')
        .select('available_quantity')
        .eq('farm_id', farmId);

      if (error) throw error;

      return data.reduce((sum, variety) => sum + (variety.available_quantity || 0), 0);
    } catch (error) {
      console.error('Error fetching available trees:', error);
      return 0;
    }
  }
}
