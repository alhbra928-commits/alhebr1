import { supabase } from '../../../lib/supabase';
import { PublicFarm, FarmSuggestion } from '../types/farm.types';

export class PublicFarmService {
  static async getAllFarms(): Promise<PublicFarm[]> {
    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .is('deleted_at', null)
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching farms:', error);
      throw error;
    }

    console.log('Fetched farms from database:', data);
    console.log('Number of farms:', data?.length || 0);

    return data.map((farm: any) => this.mapToPublicFarm(farm));
  }

  static async getFarmByBarcode(barcode: string): Promise<PublicFarm | null> {
    console.log('getFarmByBarcode called with:', barcode);

    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .or(`farm_barcode.eq.${barcode},farm_code.eq.${barcode}`)
      .is('deleted_at', null)
      .maybeSingle();

    console.log('getFarmByBarcode result:', { data, error });

    if (error) {
      console.error('Error fetching farm by barcode:', error);
      throw error;
    }
    if (!data) {
      console.warn('No farm found with barcode:', barcode);
      return null;
    }

    const mappedFarm = this.mapToPublicFarm(data);
    console.log('Mapped farm data:', mappedFarm);
    return mappedFarm;
  }

  static async getSuggestedFarms(limit: number = 3): Promise<FarmSuggestion[]> {
    const { data, error } = await supabase
      .from('farms')
      .select('farm_barcode, farm_code, name_ar, name_en')
      .is('deleted_at', null)
      .eq('status', 'active')
      .limit(limit);

    if (error) throw error;

    return data.map((farm: any, index: number) => ({
      barcode: farm.farm_barcode || farm.farm_code || `FARM-${index}`,
      farm_name: farm.name_ar || farm.name_en || 'مزرعة',
      reason: index === 0 ? 'most_booked' : index === 1 ? 'highest_return' : 'new_opening',
      badge: index === 0 ? 'الأكثر حجزاً' : index === 1 ? 'الأعلى عائداً' : 'افتتح حديثاً',
    }));
  }

  static async getSimilarFarms(barcode: string, limit: number = 3): Promise<PublicFarm[]> {
    const currentFarm = await this.getFarmByBarcode(barcode);
    if (!currentFarm) return [];

    const { data, error } = await supabase
      .from('farms')
      .select('*')
      .eq('city', currentFarm.location_city)
      .not('farm_barcode', 'eq', barcode)
      .not('farm_code', 'eq', barcode)
      .is('deleted_at', null)
      .limit(limit);

    if (error) throw error;

    return data.map((farm: any) => this.mapToPublicFarm(farm));
  }

  private static mapToPublicFarm(farm: any): PublicFarm {
    const availableTrees = farm.available_trees || farm.total_trees || 0;
    const completionPercentage = farm.total_trees > 0
      ? Math.round(((farm.total_trees - availableTrees) / farm.total_trees) * 100)
      : 0;

    let status: 'open' | 'almost_full' | 'full' = 'open';
    if (completionPercentage >= 100) status = 'full';
    else if (completionPercentage >= 80) status = 'almost_full';

    let aerialImage = farm.aerial_map_url;
    let groundImages: string[] = [];

    if (farm.images && Array.isArray(farm.images) && farm.images.length > 0) {
      aerialImage = farm.images[0];
      groundImages = farm.images.length > 1 ? farm.images.slice(1) : [];
    }

    return {
      id: farm.id,
      barcode: farm.farm_barcode || farm.farm_code || `FARM-${farm.id?.slice(0, 8)}`,
      farm_name: farm.name_ar || farm.name_en || 'مزرعة',
      total_trees: farm.total_trees || 0,
      available_trees: availableTrees,
      base_price: farm.price_per_tree || farm.marketing_price || farm.actual_price || 0,
      tree_type: farm.tree_type || 'palm',
      location_city: farm.city || 'المدينة',
      location_region: farm.region || 'المنطقة',
      description: farm.description_ar || farm.description_en,
      aerial_image: aerialImage,
      ground_images: groundImages,
      video_url: null,
      google_map_link: farm.google_map_link || null,
      status,
      completion_percentage: completionPercentage,
      latitude: farm.latitude,
      longitude: farm.longitude,
      harvest_duration: 'سنوياً',
      soil_type: 'تربة زراعية خصبة',
      services_available: ['ري', 'صيانة', 'حصاد'],
      created_at: farm.created_at,
    };
  }
}
